"""Tests for CELL-address diagnostics (rtf.canonical.cell_diag)."""

import unittest

from rtf.canonical.cell_diag import (LookupMetrics, arm_streams, cell_id_for,
                                     cell_key, cell_lookup_diagnostics,
                                     extract_cell_and_value, format_lookup,
                                     stream_is_cell_preserved, verdict)


class ArgRows:
    """Tiny record stand-in with attribute access, like EncodedPair."""
    def __init__(self, tag, row, value, loss_start, ids):
        self.tag = tag
        self.row = row
        self.value = value
        self.loss_start = loss_start
        self.ids = ids


class EncLike:
    def __init__(self, symbols):
        self.itos = ["<pad>", "<unk>", "<sep>", "<eos>"] + sorted(symbols)
        self.stoi = {s: i for i, s in enumerate(self.itos)}


class CellIdTests(unittest.TestCase):
    def test_composition_no_arithmetic(self):
        a = cell_id_for("PYTHON", "MEANING")
        b = cell_id_for("PYTHON", "MEANING")
        c = cell_id_for("MEANING", "PYTHON")         # order matters
        self.assertEqual(a, b)
        self.assertNotEqual(a, c)
        self.assertEqual(a, "CELL:PYTHON@MEANING")
        self.assertEqual(cell_key(a), "PYTHON@MEANING")

    def test_registry_mode_ids_unique(self):
        from rtf.canonical.registry import Registry
        reg = Registry("cell", "CELL")  # isolated; never pollute CELLS
        n1 = cell_id_for("PYTHON", "USED_FOR", registry=reg)
        n2 = cell_id_for("PYTHON", "USED_FOR", registry=reg)
        n3 = cell_id_for("JAVA", "USED_FOR", registry=reg)
        self.assertEqual(n1, n2)
        self.assertNotEqual(n1, n3)


class ArmStreamTests(unittest.TestCase):
    def test_arm_a_no_cell(self):
        s = arm_streams("PYTHON", "MEANING", "the language", arm="A")
        self.assertEqual(s, ["T:", "PYTHON", "R:", "MEANING", "V:", "the language"])

    def test_arm_b_cell_after_row(self):
        s = arm_streams("PYTHON", "MEANING", "v", arm="B")
        self.assertEqual(s[0:2], ["T:", "PYTHON"])
        self.assertIn("C:", s)
        self.assertIn("CELL:PYTHON@MEANING", s)
        self.assertIn("V:", s)

    def test_arm_c_cell_first(self):
        s = arm_streams("PYTHON", "MEANING", "v", arm="C")
        self.assertEqual(s[0:2], ["C:", "CELL:PYTHON@MEANING"])
        self.assertEqual(s[2:4], ["T:", "PYTHON"])

    def test_additive_rule_always_preserved(self):
        for arm in ("A", "B", "C"):
            s = arm_streams("PYTHON", "MEANING", "v", arm=arm)
            self.assertTrue(
                stream_is_cell_preserved(s, "PYTHON", "MEANING", "v", arm), arm)

    def test_invalid_arm(self):
        with self.assertRaises(ValueError):
            arm_streams("a", "b", "c", arm="Z")


class ExtractTests(unittest.TestCase):
    def test_extracts_first_cell_and_value(self):
        s = ["C:", "CELL:A@1", "T:", "A", "R:", "1", "V:", "print"]
        c, v = extract_cell_and_value(s)
        self.assertEqual(c, "CELL:A@1")
        self.assertEqual(v, "print")

    def test_no_cell_or_value(self):
        c, v = extract_cell_and_value(["T:", "A"])
        self.assertIsNone(c)
        self.assertIsNone(v)

    def test_nonprefixed_skipped(self):
        c, v = extract_cell_and_value(["A", "B", "C"])
        self.assertIsNone(c)
        self.assertIsNone(v)


class VerdictTests(unittest.TestCase):
    def _lm(self, cell=0.0, ret=0.0, direct=0.0):
        return LookupMetrics(n_pairs=100, cell_selection_hits=int(cell * 100),
                             retrieval_hits=int(ret * 100),
                             retrieval_denominator=100, direct_hits=int(direct * 100),
                             n_cells=10, n_values=50, n_values_per_cell=2)

    def test_pathway_bottleneck(self):
        m = self._lm(cell=0.98, ret=0.95, direct=0.47)
        self.assertIn("pathway bottleneck", verdict(m))

    def test_cell_addressing_bottleneck(self):
        m = self._lm(cell=0.50, ret=0.95, direct=0.47)
        self.assertIn("CELL", verdict(m))

    def test_representation_bottleneck_deeper(self):
        m = self._lm(cell=0.50, ret=0.40, direct=0.30)
        self.assertIn("representation bottleneck", verdict(m))

    def test_no_single_bottleneck(self):
        # everything strong and aligned -> no clear single gap
        m = self._lm(cell=0.97, ret=0.96, direct=0.94)
        self.assertIn("no clear single bottleneck", verdict(m))

    def test_empty(self):
        m = LookupMetrics(0, 0, 0, 0, 0, 0, 0, 0)
        self.assertEqual(verdict(m), "no data")


class GainTests(unittest.TestCase):
    def test_gains(self):
        m = LookupMetrics(100, 50, 10, 100, 30, 10, 50, 2)
        # cell: 0.5 acc, chance .1 -> (0.5-0.1)/0.9 = 0.4444
        self.assertEqual(m.gain_over_chance("cell"), 0.4444)
        # direct: 0.3 acc, chance .02 -> (0.3-0.02)/0.98 = 0.2857
        self.assertEqual(m.gain_over_chance("direct"), 0.2857)
        # retrieval: 0.1 acc chance 0.5 -> (0.1-0.5)/0.5 = -0.8
        self.assertEqual(m.gain_over_chance("retrieval"), -0.8)


class HookTests(unittest.TestCase):
    def _setup(self):
        pairs = [ArgRows(f"T{i % 3}", "ROW1", f"v{i % 3}", 1, [])
                 for i in range(9)]
        tags = {f"T{i}" for i in range(3)}
        vals = {f"v{i}" for i in range(3)}
        cells = {f"CELL:T{i}@ROW1" for i in range(3)}
        symbols = {"T:", "R:", "V:", "C:", "ROW1"} | tags | vals | cells
        return pairs, EncLike(symbols)

    def test_tag_row_value_mandatory(self):
        pairs, enc = self._setup()
        preds = [[] for _ in pairs]
        with self.assertRaises(ValueError):
            cell_lookup_diagnostics(pairs, preds, enc, arm="A")

    def test_perfect_oracle_direct(self):
        pairs, enc = self._setup()
        pred_atoms = [["T:", f"T{i % 3}", "R:", "ROW1",
                       "V:", f"v{i % 3}"] for i in range(9)]
        pred_ids = [[enc.stoi[x] for x in atoms] for atoms in pred_atoms]
        m = cell_lookup_diagnostics(pairs, pred_ids, enc,
                                    tag_of=lambda p: p.tag,
                                    row_of=lambda p: p.row,
                                    value_of=lambda p: p.value,
                                    arm="A")
        self.assertEqual(m.direct_hits, 9)
        self.assertEqual(m.direct_acc, 1.0)

    def test_cell_arm_counts_selection(self):
        pairs, enc = self._setup()
        pred_atoms = [["T:", f"T{i % 3}", "R:", "ROW1", "C:",
                       f"CELL:T{i % 3}@ROW1", "V:", f"v{i % 3}"]
                      for i in range(9)]
        pred_ids = [[enc.stoi[x] for x in atoms] for atoms in pred_atoms]
        m = cell_lookup_diagnostics(pairs, pred_ids, enc,
                                    tag_of=lambda p: p.tag,
                                    row_of=lambda p: p.row,
                                    value_of=lambda p: p.value,
                                    arm="B")
        self.assertEqual(m.cell_selection_hits, 9)
        self.assertEqual(m.retrieval_denominator, 9)
        self.assertEqual(m.retrieval_hits, 9)
        self.assertEqual(m.retrieval_acc, 1.0)

    def test_wrong_cell_keeps_direct_but_blocks_retrieval(self):
        pairs, enc = self._setup()
        pred_atoms = [["T:", f"T{i % 3}", "R:", "ROW1", "C:",
                       "CELL:T0@ROW1",   # always the WRONG cell unless T0
                       "V:", f"v{i % 3}"] for i in range(9)]
        pred_ids = [[enc.stoi[x] for x in atoms] for atoms in pred_atoms]
        m = cell_lookup_diagnostics(pairs, pred_ids, enc,
                                    tag_of=lambda p: p.tag,
                                    row_of=lambda p: p.row,
                                    value_of=lambda p: p.value,
                                    arm="B")
        self.assertEqual(m.cell_selection_hits, 3)   # i%3==0 -> 3 pairs
        self.assertEqual(m.retrieval_denominator, 3)
        self.assertEqual(m.direct_acc, 1.0)
        self.assertEqual(m.retrieval_acc, 1.0)

    def test_format_lookup_outputs_three_steps(self):
        m = LookupMetrics(n_pairs=100, cell_selection_hits=98,
                          retrieval_hits=95, retrieval_denominator=100,
                          direct_hits=47, n_cells=10, n_values=50,
                          n_values_per_cell=2)
        text = format_lookup(m)
        for needle in ("CELL", "retrieval", "direct", "verdict"):
            self.assertIn(needle, text)


if __name__ == "__main__":
    unittest.main()