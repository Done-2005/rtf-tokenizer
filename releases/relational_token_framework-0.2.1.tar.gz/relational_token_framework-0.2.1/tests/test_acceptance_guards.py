"""T-D1-07: schema guards (frozen D1 spec).

Pinned behavior:

- portable guards V01-V05 all PASS on a fitted atoms vocabulary, and
  report exactly the frozen codes.
- canonical guards C01-C07 all PASS on a fitted canonical tokenizer
  (specials incl. <sep>; contiguity; bijection; grammar round-trip;
  schema guard row length 6; collision audit 0; parameter parity).
- the guards FAIL on seeded violations: a short row raises
  ValueError (schema guard); a seeded input->two-answers collision
  raises SystemExit (abort before training); a parameter mismatch
  with require_equal raises SystemExit.
"""
import pytest

from rtf import RTFTokenizer
from rtf.canonical import CanonicalTokenizer
from rtf.canonical.validation import (
    assert_row_len,
    audit_collisions,
    guard_records,
    verify_parity,
)


def _atoms_tok():
    return RTFTokenizer(kind="atoms").fit_texts(
        ["def add(a, b): return a + b", "10 + 32 = 42",
         "The quick brown fox.", "get_weather(city=Chennai)"],
        ["python", "math", "english", None])


def test_portable_guards_v01_to_v05_all_pass():
    findings = _atoms_tok().validate()
    assert [f["code"] for f in findings] == \
        ["V01", "V02", "V03", "V04", "V05"]
    assert all(f["status"] == "PASS" for f in findings)


def test_canonical_guards_c01_to_c07_all_pass():
    ct = CanonicalTokenizer().fit_texts(
        ["10 plus 5", "def add(a, b): return a + b", "photosynthesis"],
        ["math", "python", "english"])
    findings = ct.validate()
    assert [f["code"] for f in findings] == \
        ["C01", "C02", "C03", "C04", "C05", "C06", "C07"]
    assert all(f["status"] == "PASS" for f in findings)


def test_canonical_guards_all_pass_on_default_fit():
    findings = CanonicalTokenizer().fit().validate()
    assert all(f["status"] == "PASS" for f in findings)


# --- seeded violations fail closed ------------------------------------

def test_schema_guard_rejects_short_row():
    with pytest.raises(ValueError):
        assert_row_len(("T", "c", "in", "out", "stream"))  # 5 fields


def test_guard_records_built_records_pass_and_missing_field_raises():
    ct = CanonicalTokenizer().fit()
    guard_records(ct.records)                 # built records keep shape
    proc = next(r for r in ct.records
                if r["category"] not in ("definition", "relation"))
    bad = dict(proc)
    del bad["text_out"]                       # seeded violation
    with pytest.raises(KeyError):
        guard_records([bad])


def test_collision_audit_raises_on_seeded_violation():
    records = [
        {"rtf_in": ["Q", "same"], "rtf_out": ["A", "one"]},
        {"rtf_in": ["Q", "same"], "rtf_out": ["A", "two"]},
    ]
    with pytest.raises(SystemExit):
        audit_collisions(records, lambda r: r["rtf_in"],
                         lambda r: r["rtf_out"], "seeded")


def test_collision_audit_counts_without_raising_when_disabled():
    records = [
        {"rtf_in": ["Q", "same"], "rtf_out": ["A", "one"]},
        {"rtf_in": ["Q", "same"], "rtf_out": ["A", "two"]},
        {"rtf_in": ["Q", "other"], "rtf_out": ["A", "three"]},
    ]
    n = audit_collisions(records, lambda r: r["rtf_in"],
                         lambda r: r["rtf_out"], "counted",
                         raise_on_fail=False)
    assert n == 1


def test_parameter_parity_requires_equality():
    assert verify_parity(100, 100, require_equal=True) is True
    with pytest.raises(SystemExit):
        verify_parity(100, 101, require_equal=True)
    assert verify_parity(100, 101, require_equal=False) is False
