"""Tests for the VALUE Diagnosis Report framework (rtf.canonical.value_diag)."""

import unittest

from rtf.canonical import Enc, build_encoder, build_records, make_pair
from rtf.canonical.value_diag import (VALUE_TYPES, aggregate_diagnoses,
                                      classify_value_type, confusion_kind,
                                      context_source, counter_split,
                                      diagnose_values, frequency_bucket,
                                      position_bucket, seen_unseen,
                                      value_report_on_pairs)


class ClassifyTypeTests(unittest.TestCase):
    def test_numbers(self):
        for v in ["10", "3.14", "0"]:
            self.assertEqual(classify_value_type(v), "number", v)

    def test_strings(self):
        self.assertEqual(classify_value_type('"x"'), "string")
        self.assertEqual(classify_value_type("'y'"), "string")

    def test_keywords_win_over_lexical(self):
        self.assertEqual(classify_value_type("if", "python"), "keyword")
        self.assertEqual(classify_value_type("def", "python"), "keyword")
        self.assertEqual(classify_value_type("new", "java"), "keyword")

    def test_operators(self):
        for v in ["+", "==", "&&", "//"]:
            self.assertEqual(classify_value_type(v), "operator", v)

    def test_punctuation(self):
        for v in ["(", ",", ";", "[", "}"]:
            self.assertEqual(classify_value_type(v), "punctuation", v)

    def test_identifiers(self):
        self.assertEqual(classify_value_type("foo_bar2", "python"), "identifier")
        self.assertEqual(classify_value_type("MyClass", "java"), "identifier")
        self.assertEqual(classify_value_type("x", "python"), "identifier")

    def test_natural_words_in_english(self):
        self.assertEqual(classify_value_type("run", "english"), "natural_word")
        self.assertEqual(classify_value_type("fast", "english"), "natural_word")

    def test_other_literals(self):
        self.assertEqual(classify_value_type("", "python"), "other_literal")
        self.assertEqual(classify_value_type("#", "python"), "other_literal")

    def test_constant_types_set(self):
        self.assertEqual(len(VALUE_TYPES), 9)
        self.assertIn("identifier", VALUE_TYPES)


class FrequencyBucketTests(unittest.TestCase):
    def test_bands(self):
        self.assertEqual(frequency_bucket(0), "singleton")
        self.assertEqual(frequency_bucket(1), "singleton")
        self.assertEqual(frequency_bucket(2), "rare")
        self.assertEqual(frequency_bucket(8), "medium")
        self.assertEqual(frequency_bucket(25), "frequent")
        self.assertEqual(frequency_bucket(100), "very_frequent")
        self.assertEqual(frequency_bucket(500), "very_frequent")

    def test_bucket_values(self):
        freq = {"a": 1, "b": 100, "c": 5}
        vals = [("V:", "a"), ("V:", "b"), ("V:", "c"), ("V:", "zzz")]
        out = __import__("rtf.canonical.value_diag",
                         fromlist=["bucket_values"]).bucket_values(vals, freq)
        self.assertEqual(out["singleton"], 2)
        self.assertEqual(out["very_frequent"], 1)
        self.assertEqual(out["rare"], 1)


class SeenUnseenTests(unittest.TestCase):
    def test_rates(self):
        gold = [("V:", "a"), ("V:", "b"), ("V:", "c")]
        out = seen_unseen(gold, {"a", "c"})
        self.assertEqual(out["seen"], 2)
        self.assertEqual(out["unseen"], 1)
        self.assertEqual(out["seen_rate"], 0.6667)


class ContextTests(unittest.TestCase):
    def test_nearby(self):
        ctx = ["a", "b", "c", "TARGET", "d", "e", "f"]
        self.assertEqual(context_source("TARGET", ctx), "nearby")

    def test_earlier(self):
        ctx = ["TARGET", "x", "y"] + ["pad"] * 10
        self.assertEqual(context_source("TARGET", ctx), "earlier")

    def test_elsewhere(self):
        ctx = ["p", "q"]
        self.assertEqual(context_source("manhattan", ctx,
                                        doc_values={"manhattan"}), "elsewhere")

    def test_inferable_and_absent(self):
        self.assertEqual(context_source("x", ["p", "q"]), "inferable")
        self.assertEqual(context_source("x", []), "absent")


class PositionBucketTests(unittest.TestCase):
    def test_buckets(self):
        self.assertEqual(position_bucket(0, 10), "start")
        self.assertEqual(position_bucket(5, 10), "middle")
        self.assertEqual(position_bucket(9, 10), "end")


class ConfusionKindTests(unittest.TestCase):
    def test_truth_table(self):
        types = {"dog": "natural_word", "cat": "natural_word"}
        freq = {"the": 500}
        self.assertEqual(confusion_kind("dog", "cat", types, freq, []),
                         "same_type")
        self.assertEqual(confusion_kind("dog", "the", types, freq, []),
                         "frequent_value")
        self.assertEqual(confusion_kind("dog", "7", types, freq, ["7"]),
                         "contextual_value")
        self.assertEqual(confusion_kind("dog", "7", types, freq, []),
                         "random_value")


class DiagnoseTests(unittest.TestCase):
    def test_full_diagnosis(self):
        gold = [("V:", "Print"), ("V:", "a"), ("V:", "car"),
                ("V:", "Print"), ("V:", "cat"), ("V:", "b")]
        pred = [("V:", "print"), ("V:", "a"), ("V:", "car"),
                ("V:", "Print"), ("V:", "print"), ("V:", "b")]
        freq = {"Print": 200, "cat": 2, "car": 1, "a": 30}
        ctx = ["Print", "a", "car"]
        d = diagnose_values(gold, pred, freq=freq,
                            context_symbols=ctx, domain="english")
        self.assertEqual(d.lenses["n_values"], 6)
        self.assertEqual(d.lenses["correct"], 4)
        self.assertEqual(d.lenses["accuracy"], 0.6667)
        # case-only error: Print -> print
        self.assertEqual(d.case["case_only"], 1)
        # copy vs learn: Print/a/car in ctx, cat/b not
        self.assertEqual(d.copy_vs_learn["copy_correct"], 3)
        self.assertEqual(d.copy_vs_learn["inference_correct"], 1)
        f = d.by_frequency
        self.assertEqual(f["very_frequent"], 2)   # Print(200) x2
        self.assertEqual(f["frequent"], 1)        # a(30)
        self.assertEqual(f["rare"], 1)            # cat(2)
        self.assertEqual(f["singleton"], 2)       # car, b(OOV)
        self.assertEqual(d.by_position["start"], 2)
        t = d.by_type
        # "a" is an english DETERMINER keyword; the rest are natural words
        self.assertEqual(t["natural_word"], 5)
        self.assertEqual(t["keyword"], 1)

    def test_position_and_confusion(self):
        gold = [("V:", "a"), ("V:", "b"), ("V:", "c"), ("V:", "d"),
                ("V:", "e"), ("V:", "f")]
        pred = [("V:", "z"), ("V:", "b"), ("V:", "z"), ("V:", "the"),
                ("V:", "e"), ("V:", "f")]
        d = diagnose_values(gold, pred, freq={"the": 500, "z": 1},
                            domain="english")
        self.assertEqual(d.lenses["correct"], 3)
        self.assertEqual(d.lenses["errors"], 3)
        self.assertEqual(d.confusion["same_type"], 1)   # z vs c natural_word
        self.assertEqual(d.confusion["frequent_value"], 1)  # the vs d
        self.assertEqual(d.confusion["random_value"], 1)  # z vs a? -> OOV pred
        self.assertEqual(d.by_position["middle"], 2)
        self.assertEqual(d.by_position["start"], 2)
        self.assertEqual(d.by_position["end"], 2)


class AggregateTests(unittest.TestCase):
    def test_aggregate(self):
        diags = []
        for i in range(3):
            g = [("V:", "a"), ("V:", "b")]
            p = [("V:", "a"), ("V:", "b")] if i < 2 else [("V:", "a"),
                                                          ("V:", "x")]
            diags.append(diagnose_values(g, p, domain="python"))
        agg = aggregate_diagnoses(diags)
        self.assertEqual(agg["n_values"], 6)
        self.assertEqual(agg["correct"], 5)
        self.assertEqual(agg["accuracy"], 0.8333)


class IntegrationHookTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from rtf.canonical import DEFS, PROCEDURAL, RELATIONS
        records = build_records(DEFS, RELATIONS, PROCEDURAL)
        cls.enc = build_encoder(records, None)
        cls.pairs = [make_pair(cls.enc, r["rtf_in"], r["rtf_out"],
                               pair_id=r["id"], solution_domain=r["domain"])
                     for r in records]

    def test_hook_produces_diagnosis(self):
        pairs = self.pairs[:2]
        preds = [list(p.ids) for p in pairs]
        d = value_report_on_pairs(pairs, preds, enc_vocab=self.enc)
        self.assertIsInstance(d.lenses["accuracy"], float)
        self.assertEqual(d.lenses["accuracy"], 1.0)  # exact replay
        self.assertGreaterEqual(d.lenses["n_values"], 2)
        self.assertIn("case", d.__dict__)
        self.assertIn("by_frequency", d.__dict__)

    def test_hook_requires_vocab(self):
        pairs = self.pairs[:1]
        preds = [list(p.ids) for p in pairs]
        with self.assertRaises(ValueError):
            value_report_on_pairs(pairs, preds, enc_vocab=None)


if __name__ == "__main__":
    unittest.main()