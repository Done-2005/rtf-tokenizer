"""Behavioral coverage for the canonical tokenizer registry (Step 1).

Authorized scope item 6: get_or_register must cover existing-row retrieval,
new-row creation, and stable / sequential registry behavior. The final class
mirrors the repository acceptance flow (TestCellBuilderDiscriminator) so the
suite demonstrates that the canonical source (pkg\\src\\rtf) is exercised
end to end by the same flow the Step-0 conflict was about.
"""
from __future__ import annotations

import pytest

from rtf.cells.builder import CellBuilder
from rtf.registries import RowRegistry, TagRegistry, ValueRegistry


@pytest.fixture()
def conn(tmp_path):
    import rtf.core.schema as schema

    c = schema.connect(str(tmp_path / "t.db"))
    yield c
    c.close()


def _fresh(conn) -> RowRegistry:
    return RowRegistry(conn)


class TestGetOrRegisterBehavior:
    def test_existing_row_retrieval_returns_same_id_without_growth(self, conn):
        rows = _fresh(conn)
        seed = sorted(rows.all_rows(), key=lambda r: r["row_id"])[0]
        before = rows.count()
        first = rows.get_or_register(seed["canonical_name"])
        second = rows.get_or_register(seed["canonical_name"])
        assert first == second == seed["row_id"]
        assert rows.count() == before  # retrieval must not create a side row

    def test_new_row_creation_is_auto_and_stores_empty_definition(self, conn):
        rows = _fresh(conn)
        before = rows.count()
        new_id = rows.get_or_register("ZZ_REL1_NOT_A_SEED_CONCEPT")
        row = rows.get(new_id)
        assert row["canonical_name"] == "ZZ_REL1_NOT_A_SEED_CONCEPT"
        assert row["origin"] == "AUTO"
        assert row["definition"] == ""
        assert rows.count() == before + 1

    def test_ids_are_sequential_and_stable_across_instances(self, conn):
        rows = _fresh(conn)
        a = rows.get_or_register("ZZ_REL1_SEQUENCE_A")
        b = rows.get_or_register("ZZ_REL1_SEQUENCE_B")
        assert b == a + 1  # sequential: every insert is max(id) + 1
        # a second registry instance sees the same permanent ids
        rows_b = RowRegistry(conn)
        assert rows_b.get_or_register("ZZ_REL1_SEQUENCE_A") == a
        assert rows_b.get_or_register("ZZ_REL1_SEQUENCE_B") == b
        assert rows_b.get_or_register("ZZ_REL1_SEQUENCE_C") == b + 1

    def test_row_code_roundtrip_format_is_assigned_at_creation(self, conn):
        rows = _fresh(conn)
        new_id = rows.get_or_register("ZZ_REL1_ROWCODE_CHECK")
        row = rows.get(new_id)
        assert row["row_code"] and isinstance(row["row_code"], str)
        assert row["row_code"] != ""


class TestCellBuilderDiscriminatorEcho:
    """The repository acceptance flow, exercised against the canonical source."""

    def test_build_records_discriminator(self, conn):
        tag_id, _ = TagRegistry(conn).get_or_register("d", "n", "x")
        rows = RowRegistry(conn)
        values = ValueRegistry(conn)
        builder = CellBuilder(conn, values)

        row_id = rows.get_or_register("VARIABLE_BINDING")

        outcome = builder.build(tag_id, row_id, "LOCAL_BINDING", "ans")
        assert outcome.status == "created"
        assert builder.get(outcome.cell_id)["discriminator"] == "LOCAL_BINDING"

    def test_build_allows_absent_discriminator_and_dedupes(self, conn):
        tag_id, _ = TagRegistry(conn).get_or_register("d", "n", "x")
        rows = RowRegistry(conn)
        values = ValueRegistry(conn)
        builder = CellBuilder(conn, values)

        row_id = rows.get_or_register("VARIABLE_BINDING")
        first = builder.build(tag_id, row_id, None, "dim")
        second = builder.build(tag_id, row_id, None, "dim")
        assert first.status == "created"
        assert second.status == "duplicate"
        assert second.cell_id == first.cell_id
