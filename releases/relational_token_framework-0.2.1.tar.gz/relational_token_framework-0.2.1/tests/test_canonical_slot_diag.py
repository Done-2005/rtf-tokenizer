"""Tests for slot-level T/R/V diagnosis (rtf.canonical.slot_diag)."""

import unittest

from rtf.canonical import (DEFS, PROCEDURAL, RELATIONS, build_encoder,
                           build_records, make_pair)
from rtf.canonical.slot_diag import (ROW, SLOTS, TAG, VALUE, analyze_positions,
                                     canonical_slots, chance_baselines,
                                     format_three_way, largest_gap,
                                     slot_report_on_pairs)

RECORDS = build_records(DEFS, RELATIONS, PROCEDURAL)
ENC = build_encoder(RECORDS, None)
PAIRS = [make_pair(ENC, r["rtf_in"], r["rtf_out"],
                   pair_id=r["id"], solution_domain=r["domain"])
         for r in RECORDS]


def _task_of(pair):
    cat = pair.pair_id.split("_")[0]
    return {"DEF": "definition", "REL": "relation",
            "PROC": "arithmetic"}[cat]


class CanonicalSlotsTests(unittest.TestCase):
    def test_definition(self):
        # DEF answer: [TAG, VALUE, VALUE, ...]
        self.assertEqual(canonical_slots("definition", 5),
                         ["TAG", "VALUE", "VALUE", "VALUE", "VALUE"])
        self.assertEqual(canonical_slots("definition", 0), [])

    def test_relation(self):
        # REL answer: [TAG, ROW, TAG, ROW, ROW, ROW, ROW]
        self.assertEqual(canonical_slots("relation", 7),
                         ["TAG", "ROW", "TAG"] + ["ROW"] * 4)
        self.assertEqual(canonical_slots("relation", 2),
                         ["TAG", "ROW"])

    def test_arithmetic(self):
        self.assertEqual(canonical_slots("arithmetic", 3),
                         ["VALUE", "VALUE", "VALUE"])

    def test_unknown_category_is_value(self):
        self.assertEqual(canonical_slots("poem", 2), ["VALUE", "VALUE"])


class SlotStatsTests(unittest.TestCase):
    def test_accuracy_and_top5(self):
        positions = [
            type("P", (), {"slot": TAG, "gold": "PYTHON",
                           "pred": "PYTHON", "top5_hit": True, "ce": 0.1})(),
            type("P", (), {"slot": TAG, "gold": "JAVA",
                           "pred": "PYTHON", "top5_hit": True, "ce": 2.0})(),
            type("P", (), {"slot": VALUE, "gold": "mean",
                           "pred": "mean", "top5_hit": True, "ce": 0.3})(),
        ]
        stats = analyze_positions(positions)
        t = stats[TAG]
        self.assertEqual(t.n, 2)
        self.assertEqual(t.top1_hits, 1)
        self.assertEqual(t.top1_acc, 0.5)
        self.assertEqual(t.top5_acc, 1.0)
        self.assertEqual(t.mean_ce, 1.05)
        self.assertEqual(t.vocab_size, 2)
        self.assertEqual(t.chance_top1, 0.5)
        self.assertEqual(t.gain_over_chance, 0.0)  # (0.5-0.5)/(1-0.5)
        v = stats[VALUE]
        self.assertEqual(v.top1_acc, 1.0)
        self.assertEqual(v.vocab_size, 1)
        # N=1 slot: chance is 1.0, gain-over-chance is undefined
        self.assertNotEqual(v.gain_over_chance, v.gain_over_chance)

    def test_top5_unknown_returns_nan(self):
        positions = [type("P", (), {"slot": ROW, "gold": "a", "pred": "a",
                                    "top5_hit": None, "ce": None})()]
        s = analyze_positions(positions)[ROW]
        self.assertNotEqual(s.top5_acc, s.top5_acc)  # NaN

    def test_chance_baselines(self):
        out = chance_baselines({TAG: 8, ROW: 12, VALUE: 200})
        self.assertEqual(out[TAG], round(1 / 8, 6))
        self.assertEqual(out[ROW], round(1 / 12, 6))
        self.assertEqual(out[VALUE], round(1 / 200, 6))
        self.assertEqual(chance_baselines({"X": 0}), {})

    def test_largest_gap(self):
        prof = {
            TAG: {"gain_over_chance": 0.95},
            ROW: {"gain_over_chance": 0.80},
            VALUE: {"gain_over_chance": 0.10},
        }
        w, b, g = largest_gap(prof)
        self.assertEqual(w, VALUE)
        self.assertEqual(b, TAG)
        self.assertEqual(g, 0.10)

    def test_largest_gap_all_equal_returns_none(self):
        prof = {TAG: {"gain_over_chance": 1.0},
                ROW: {"gain_over_chance": 1.0},
                VALUE: {"gain_over_chance": 1.0}}
        self.assertIsNone(largest_gap(prof))

    def test_largest_gap_needs_two_slots(self):
        self.assertIsNone(largest_gap({TAG: {"gain_over_chance": 0.9}}))


class HookTests(unittest.TestCase):
    def test_oracle_replay_perfect(self):
        preds = [list(p.ids) for p in PAIRS]
        r = slot_report_on_pairs(PAIRS, preds, ENC, task_of=_task_of)
        self.assertEqual(r["n_answer_positions"],
                         sum(len(p.ids[p.loss_start - 1:]) for p in PAIRS))
        for s in SLOTS:
            d = r["profile"][s]
            self.assertEqual(d["n"], len([pp for pp in r["positions"]
                                          if pp.slot == s]))
            self.assertEqual(d["top1_acc"], 1.0)

    def test_relation_rows_and_tags_populated(self):
        preds = [list(p.ids) for p in PAIRS]
        r = slot_report_on_pairs(PAIRS, preds, ENC, task_of=_task_of)
        rel = [p for p in r["positions"] if p.slot == ROW]
        self.assertTrue(rel)
        tags = [p for p in r["positions"] if p.slot == TAG]
        # DEF has 1 TAG each (23) + REL has 2 TAGs each (24) = 47 TAG pos
        self.assertEqual(len(tags), 23 + 24)

    def test_weak_value_model_larger_gap(self):
        """Synthetic model that gets T/R right but V wrong ~half the time."""
        # a wrong numeric token guaranteed present in the union vocab
        wrong_value = [r["rtf_out"][0] for r in RECORDS
                       if r["category"] == "arithmetic" and r["rtf_out"]
                       and r["rtf_out"][0] != "4"]
        wrong_value = wrong_value[0] if wrong_value else "1"
        preds = []
        for pair in PAIRS:
            ids = list(pair.ids)
            cat = _task_of(pair)
            atoms = [ENC.itos[i] for i in ids[pair.loss_start - 1:]]
            for j, atom in enumerate(atoms):
                pos_ab = pair.loss_start - 1 + j
                slots = canonical_slots(cat, len(atoms))
                if slots[j] == VALUE and pair.pair_id.startswith("PROC"):
                    ids[pos_ab] = ENC.stoi[wrong_value] if atom != wrong_value \
                        else ENC.stoi["4"]
            preds.append(ids)
        r = slot_report_on_pairs(PAIRS, preds, ENC, task_of=_task_of)
        p = r["profile"]
        self.assertLess(p[VALUE]["top1_acc"], p[TAG]["top1_acc"])
        self.assertLess(p[VALUE]["gain_over_chance"], p[TAG]["gain_over_chance"])
        self.assertEqual(r["largest_gap"][0], VALUE)

    def test_chance_baseline_in_report(self):
        preds = [list(p.ids) for p in PAIRS]
        r = slot_report_on_pairs(PAIRS, preds, ENC, task_of=_task_of)
        cb = r["chance_baselines"]
        self.assertEqual(set(cb), {TAG, ROW, VALUE})
        for c in cb.values():
            self.assertGreater(c, 0)
            self.assertLess(c, 1)

    def test_custom_slot_of_supported(self):
        preds = [list(p.ids) for p in PAIRS]
        r = slot_report_on_pairs(PAIRS, preds, ENC, task_of=_task_of,
                                 slot_of=lambda pi, cat, atoms: [VALUE] * len(atoms))
        self.assertEqual(set(r["profile"]), {VALUE})

    def test_top5_and_ce_plus_guard(self):
        preds = [list(p.ids) for p in PAIRS]
        n = len(PAIRS)
        top5 = [[[ENC.itos[x] for x in (pair.ids[pair.loss_start - 1 + j],
                                        ENC.stoi["<pad>"])]
                 for j in range(len(pair.ids[pair.loss_start - 1:]))]
                for pair in PAIRS]
        ces = [[0.5] * len(pair.ids[pair.loss_start - 1:]) for pair in PAIRS]
        r = slot_report_on_pairs(PAIRS, preds, ENC, task_of=_task_of,
                                 top5_id_lists=top5, ce_lists=ces)
        p = r["profile"]
        self.assertEqual(p[TAG]["top5_acc"], 1.0)
        self.assertEqual(p[VALUE]["mean_ce"], 0.5)

    def test_format_contains_three_slots(self):
        preds = [list(p.ids) for p in PAIRS]
        r = slot_report_on_pairs(PAIRS, preds, ENC, task_of=_task_of)
        text = format_three_way(r)
        for s in ("TAG", "ROW", "VALUE"):
            self.assertIn(s, text)
        self.assertNotIn("largest measured learning gap", text)  # all equal

    def test_format_shows_gap_for_weak_value(self):
        wrong_value = next(r["rtf_out"][0] for r in RECORDS
                           if r["category"] == "arithmetic" and r["rtf_out"]
                           and r["rtf_out"][0] != "4") or "1"
        preds = [list(p.ids) for p in PAIRS]
        for pair, ids in zip(PAIRS, preds):
            atoms = [ENC.itos[i] for i in ids[pair.loss_start - 1:]]
            cat = _task_of(pair)
            for j, atom in enumerate(atoms):
                if (canonical_slots(cat, len(atoms))[j] == VALUE
                        and pair.pair_id.startswith("PROC")):
                    ids[pair.loss_start - 1 + j] = ENC.stoi[wrong_value]
        r = slot_report_on_pairs(PAIRS, preds, ENC, task_of=_task_of)
        self.assertIn("largest measured learning gap", format_three_way(r))


if __name__ == "__main__":
    unittest.main()