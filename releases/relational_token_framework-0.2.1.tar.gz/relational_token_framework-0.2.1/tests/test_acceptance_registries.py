"""T-D1-04: registries and the permanent identity layer (frozen D1 spec).

Pinned behavior:

- canonical Registry (TAG-/ROW-/COL-/CELL- kinds): idempotent
  registration by key (the same object always gets the same number),
  metadata stored on first registration and never silently replaced,
  TAG-000001-style labels, to_dict/from_dict round-trips with the
  next-number preserved, audit_unique clean.
- Registration (global monotonic identity): one counter across
  TAG/ROW/VALUE/CELL, deduplicated names, strictly increasing ids,
  load continuation NEVER reuses ids (the monotonic guard adopts max
  seen, even from a tampered/rewound file), corrupt files fail
  closed.
- RowRegistry.get_or_register: find-or-create with AUTO origin and
  empty definition - the canonical rows.py addition documented in
  CANONICAL_SOURCE.md and committed to documentation in this release.
"""
import pytest

from rtf import Registration
from rtf.canonical.registry import Registry, audit_unique
from rtf.registries import RowRegistry


def _reg_with_content():
    reg = Registration()
    reg.cell("PYTHON", "FUNCTION_DECLARATION", "add")
    return reg


# --- canonical per-kind Registry --------------------------------------

def test_registry_idempotent_register_and_labels():
    reg = Registry("tag", "TAG")
    first = reg.register("PYTHON", domain="PYTHON")
    again = reg.register("PYTHON")
    assert first == again == 1
    assert reg.label(first) == "TAG-000001"
    assert reg.key(first) == "PYTHON"
    assert reg.number("PYTHON") == 1


def test_registry_metadata_stored_once_never_replaced():
    reg = Registry("row", "ROW")
    n = reg.register("INTEGER_LITERAL", domain="PYTHON")
    reg.register("INTEGER_LITERAL", domain="MATH")
    assert reg.object(n) == {"key": "INTEGER_LITERAL", "domain": "PYTHON"}


def test_registry_to_dict_from_dict_round_trip():
    reg = Registry("cell", "CELL")
    a = reg.register("A@B", row="ROW-000001", col="COL-000001")
    reg.register("C@D")
    clone = Registry("cell", "CELL").from_dict(reg.to_dict())
    assert clone.number("A@B") == a
    nxt = clone.register("E@F")
    assert nxt == 3                                  # _next preserved
    assert clone.object(1)["row"] == "ROW-000001"


def test_audit_unique_clean_after_registrations():
    reg = Registry("tag", "TAG")
    for name in ("PYTHON", "JAVA", "RUST"):
        reg.register(name)
    report = audit_unique()
    assert report["TAG"]["numbers_unique"]
    assert report["TAG"]["keys_unique"]
    assert report["TAG"]["numbers_contiguous"]


# --- global Registration identity layer -------------------------------

def test_registration_ids_global_monotonic_and_deduplicated():
    reg = Registration()
    t = reg.tag_id("PYTHON")
    r = reg.row_id("INTEGER_LITERAL")
    v = reg.value_id("x")
    c = reg.cell_id(t, r, v)
    assert reg.row_id("INTEGER_LITERAL") == r        # deduplicated
    assert reg.tag_id("PYTHON") == t
    assert 0 < t < r < v < c                         # one shared sequence
    assert reg.cell("JAVA", "CLASS_DECLARATION", "Main")[3] > c


def test_registration_round_trip_identity(tmp_path):
    reg = _reg_with_content()
    path = tmp_path / "reg.json"
    reg.save(path)
    loaded = Registration.load(path)
    assert loaded.tags == reg.tags
    assert loaded.rows == reg.rows
    assert loaded.values == reg.values
    assert loaded.cells == reg.cells
    assert loaded.max_id == reg.max_id


def test_registration_load_continues_without_id_reuse(tmp_path):
    reg = _reg_with_content()
    path = tmp_path / "reg.json"
    reg.save(path)
    loaded = Registration.load(path)
    before = loaded.max_id
    assert before == reg.max_id
    nxt = loaded.value_id("brand-new-value")
    assert nxt == before + 1                         # never restarted
    assert loaded.max_id == nxt                      # counter advanced


def test_registration_rewound_counter_guard_adopts_max(tmp_path):
    reg = _reg_with_content()
    path = tmp_path / "reg.json"
    reg.save(path)
    import json
    data = json.loads(path.read_text(encoding="utf-8"))
    data["counter"] = 1                               # tampered rewind
    path.write_text(json.dumps(data), encoding="utf-8")
    loaded = Registration.load(path)
    assert loaded.max_id == 4                         # guard adopts max seen
    assert loaded.value_id("after-guard") == 5        # no id reuse


def test_registration_corrupt_file_fails_closed(tmp_path):
    bad = tmp_path / "bad.json"
    bad.write_text("{not json", encoding="utf-8")
    with pytest.raises(Exception):
        Registration.load(bad)


# --- RowRegistry.get_or_register (canonical rows.py addition) ---------

def test_get_or_register_finds_existing_row_without_growth(tmp_path):
    import rtf.core.schema as schema
    conn = schema.connect(str(tmp_path / "t.db"))
    rr = RowRegistry(conn)
    before = rr.count()
    row_id = rr.get_or_register("NEW_CONCEPT_X")
    assert rr.get_or_register("NEW_CONCEPT_X") == row_id
    assert rr.count() == before + 1                   # created once
    entry = rr.get(row_id)
    assert entry["canonical_name"] == "NEW_CONCEPT_X"
    assert entry["origin"] == "AUTO"                  # AUTO origin
    assert entry["definition"] == ""                  # empty definition


def test_get_or_register_returns_seed_ids_unchanged(tmp_path):
    import rtf.core.schema as schema
    conn = schema.connect(str(tmp_path / "t.db"))
    rr = RowRegistry(conn)
    seed_id = rr.get_or_register("INTEGER_LITERAL")   # seeded concept
    assert seed_id == rr.find_exact("INTEGER_LITERAL")
    assert rr.get(seed_id)["origin"] == "SEED"        # origin untouched
