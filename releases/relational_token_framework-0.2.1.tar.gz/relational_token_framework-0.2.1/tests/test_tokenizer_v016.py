"""15-check tokenizer test suite (0.1.6, Copy-3 campaign gate).

MUST all pass BEFORE any Kaggle ~10M-param training starts. It pins the
five-domain [T,R,V] tokenizer, registration, cross-domain, schema guards,
tool-call representation, persistence and determinism against the
verified Copy-3 semantics.

    python -m unittest test_tokenizer_v016
"""

import json
import tempfile
import unittest
from pathlib import Path

from rtf import RTF, RTFTokenizer, Registration, detect_domain
from rtf import tool_call_atoms, tokenize_text
from rtf.cross_domain import DeterministicExecutor
from rtf.tokenization.tokens import EOS, PAD, UNK

PY = "def f(x):\n    return x + 1"
PROSE = "the cat sat on the mat 42."


class TokenizerChecks(unittest.TestCase):
    def test_1_specials_vocab_and_contiguity(self):
        tok = RTFTokenizer("atoms").fit_texts([PY, PROSE])
        for special in (PAD, UNK, EOS):
            self.assertIn(special, tok.stoi)
            self.assertIn(special, tok.itos)
        self.assertEqual(tok.vocab_size, len(tok.itos))
        self.assertEqual(len(tok.vocab()), len(tok.itos))
        self.assertEqual(sorted(set(tok.stoi.values())),
                         list(range(tok.vocab_size)))

    def test_2_oov_unknown_maps_to_unk(self):
        tok = RTFTokenizer("atoms").fit_texts(["x = 1"])
        unk = tok.stoi[UNK]
        self.assertEqual(tok.token_to_id("T:NOT_IN_VOCAB"), unk)
        ids = tok.encode_text("qqqqq zzzzz", language="english")
        self.assertIn(UNK, tok.decode(ids))

    def test_3_encode_decode_round_trip_preserves_atoms(self):
        text = "x = 2 + 3"
        tok = RTFTokenizer("atoms").fit_texts([text], languages="python")
        ids = tok.encode_text(text, language="python")
        atoms = tok.decode_atoms(ids)
        self.assertEqual(atoms[0][0], "PYTHON")
        self.assertEqual([a[1] for a in atoms],
                         ["VARIABLE_BINDING", "RELATIONAL_OPERATOR",
                          "INTEGER_LITERAL", "ARITHMETIC_OPERATOR",
                          "INTEGER_LITERAL"])
        self.assertEqual([a[2] for a in atoms], ["x", "=", "2", "+", "3"])

    def test_4_specials_round_trip_decode(self):
        tok = RTFTokenizer("atoms").fit_texts(["hello"])
        self.assertEqual(tok.decode([tok.stoi[PAD], tok.stoi[UNK],
                                     tok.stoi[EOS]]), [PAD, UNK, EOS])

    def test_5_token_to_id_id_to_token_bijective(self):
        tok = RTFTokenizer("atoms").fit_texts([PY, PROSE])
        for symbol in tok.itos:
            self.assertEqual(tok.id_to_token(tok.token_to_id(symbol)), symbol)
            self.assertEqual(tok.itos[tok.token_to_id(symbol)], symbol)

    def test_6_save_load_round_trip(self):
        tok = RTFTokenizer("atoms").fit_texts([PY, "y = 2 + 3"])
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / "vocab.json")
            tok.save(path)
            data = json.loads(Path(path).read_text(encoding="utf-8"))
            self.assertEqual(data["kind"], "atoms")
            tok2 = RTFTokenizer.load(path)
            self.assertEqual(tok2.kind, "atoms")
            self.assertEqual(tok2.vocab_size, tok.vocab_size)
            self.assertEqual(tok2.decode([0, 1, 2]), tok.decode([0, 1, 2]))
            self.assertEqual(tok2.domains,
                             ["python", "java", "math", "tool", "english"])


class CrossDomainChecks(unittest.TestCase):
    def test_7_cross_domain_exists_none_no_invention(self):
        v = DeterministicExecutor().check(subj="PYTHON", rel="USED_FOR",
                                          obj="STATISTICS")
        self.assertEqual(v.state, "EXISTS")
        v2 = DeterministicExecutor().check(subj="PYTHON", rel="IS_A",
                                           obj="STATISTICS")
        self.assertEqual(v2.state, "NONE")
        tok = RTFTokenizer("atoms").fit_texts(["x = 1"])
        self.assertIn(("USED_FOR", "STATISTICS"), tok.relationships("PYTHON"))
        self.assertEqual(tok.relationships("NOT_A_REAL_TAG"), [])
        # campaign stems resolve to canonical tags so the declared graph
        # applies (SPEC_COPY3 component 5: independent main tags first,
        # then Cross-Domain connects them).
        self.assertIn(("SUPPORTS", "STATISTICS"),
                      tok.relationships("math"))
        self.assertIn(("RELATED_TO", "MATHEMATICS"),
                      tok.relationships("python"))
        # verified verdict + routing on the resolved graph
        verdict = tok.cross_domain("python", "used_for", "statistics")
        self.assertEqual((verdict.state, verdict.confidence, verdict.action),
                         ("EXISTS", "HIGH", "EXECUTE"))
        self.assertEqual(tok.cross_domain("statistics", "uses", "python").state,
                         "NONE")
        # canonical answer stream (benchmark format)
        self.assertEqual(
            tok.respond_relation("python", "used_for", "statistics"),
            ["PYTHON", "USED_FOR", "STATISTICS",
             "CONF", "HIGH", "ACTION", "EXECUTE"])


class RegistrationChecks(unittest.TestCase):
    def test_8_registration_global_monotonic_dedupe(self):
        reg = Registration()
        self.assertEqual(reg.tag_id("PYTHON"), 1)
        self.assertEqual(reg.tag_id("MATH"), 2)
        self.assertEqual(reg.row_id("INTEGER_LITERAL"), 3)
        self.assertEqual(reg.row_id("INTEGER_LITERAL"), 3)
        self.assertEqual(reg.value_id("x"), 4)
        self.assertEqual(reg.value_id("x"), 4)
        self.assertEqual(reg.cell("PYTHON", "INTEGER_LITERAL", "x"),
                         (1, 3, 4, 5))
        self.assertEqual(reg.cell("PYTHON", "INTEGER_LITERAL", "x")[3], 5)
        self.assertGreater(reg.tag_id("ENGLISH"), 5)
        self.assertEqual(reg.max_id, 6)
        self.assertEqual(reg.tag_name(1), "PYTHON")
        self.assertEqual(reg.value_text(4), "x")

    def test_9_registration_save_load_persists_no_reuse(self):
        reg = Registration()
        reg.tag_id("PYTHON")
        reg.row_id("INTEGER_LITERAL")
        reg.value_id("x")
        reg.cell("PYTHON", "INTEGER_LITERAL", "x")
        previous = {reg.max_id}
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / "registration.json")
            reg.save(path)
            reg2 = Registration.load(path)
            self.assertEqual(reg2.tag_id("PYTHON"), reg.tag_id("PYTHON"))
            self.assertEqual(reg2.value_id("x"), reg.value_id("x"))
            self.assertEqual(reg2.row_id("INTEGER_LITERAL"),
                             reg.row_id("INTEGER_LITERAL"))
            fresh = reg2.tag_id("JAVA")
            self.assertGreater(fresh, reg.max_id)
            self.assertNotIn(fresh, previous)


class FiveDomainChecks(unittest.TestCase):
    def test_10_domain_detection_five_domains(self):
        self.assertEqual(detect_domain(
            "def add(a, b):\n    return a + b"), "python")
        self.assertEqual(detect_domain("public class Main { }"), "java")
        self.assertEqual(detect_domain("2 + 3 = 5"), "math")
        self.assertEqual(detect_domain(
            {"function": "get_weather", "arguments": {"city": "Chennai"}}),
            "tool")
        self.assertEqual(detect_domain(
            "The quick brown fox jumps over the lazy dog"), "english")
        lang, atoms = tokenize_text("the cat sits.", language="english")
        self.assertEqual(lang, "english")
        self.assertEqual(atoms[0][0], "DETERMINER")
        self.assertEqual(atoms[0][1], "the")

    def test_11_tool_call_representation_round_trip(self):
        calls = [{"function": "get_weather", "arguments": {"city": "Chennai"}},
                 {"function": "a", "arguments": {"x": "1"}},
                 {"function": "b", "arguments": {"y": "2"}}]
        tok = RTFTokenizer("atoms").fit_tool_examples(calls)
        ids = tok.encode_tool_call(calls[0])
        atoms = tok.decode_atoms(ids)
        self.assertEqual(atoms, [
            ("TOOL_CALL", "FUNCTION_NAME", "get_weather"),
            ("TOOL_CALL", "ARGUMENT_NAME", "city"),
            ("TOOL_CALL", "ARGUMENT_VALUE", "Chennai"),
        ])
        multi = tok.decode_atoms(tok.encode_tool_call(calls[1:]))
        self.assertEqual([a[2] for a in multi],
                         ["a", "x", "1", "b", "y", "2"])
        raw = tool_call_atoms({"function": "get_weather",
                               "arguments": {"city": "Chennai"}})
        self.assertEqual(raw[0], ("TOOL_CALL", "FUNCTION_NAME",
                                  "get_weather"))

    def test_12_validate_guards_pass(self):
        tok = RTFTokenizer("atoms").fit_texts([PY, PROSE])
        findings = tok.validate()
        self.assertTrue(findings)
        for finding in findings:
            self.assertEqual(finding["status"], "PASS", finding)
        codes = [f["code"] for f in findings]
        self.assertIn("V01", codes)
        self.assertIn("V03", codes)
        self.assertIn("V04", codes)

    def test_13_python_java_math_atoms(self):
        tok = RTFTokenizer("atoms").fit_texts(
            [PY, "public class Foo { }", "2 + 3 = 5"])
        py_atoms = tok.decode_atoms(tok.encode_text(PY, language="python"))
        self.assertIn(("PYTHON", "FUNCTION_DECLARATION", "def"), py_atoms)
        self.assertIn(("PYTHON", "RETURN_STATEMENT", "return"), py_atoms)
        java_atoms = tok.decode_atoms(
            tok.encode_text("public class Foo { }", language="java"))
        self.assertIn(("JAVA", "CLASS_DECLARATION", "class"), java_atoms)
        math_atoms = tok.decode_atoms(
            tok.encode_text("2 + 3 = 5", language="math"))
        rows = [a[1] for a in math_atoms]
        self.assertIn("ARITHMETIC_OPERATOR", rows)
        self.assertIn("RELATIONAL_OPERATOR", rows)

    def test_14_english_atoms_no_info_loss(self):
        tok = RTFTokenizer("atoms").fit_texts(
            [PROSE, "the quick brown fox", "caf\u00e9 \u00e9l\u00e8ve"])
        ids = tok.encode_text(PROSE, language="english")
        atoms = tok.decode_atoms(ids)
        self.assertEqual(atoms[0][0], "ENGLISH")
        self.assertEqual([a[2] for a in atoms],
                         ["the", "cat", "sat", "on", "the", "mat", "42", "."])
        self.assertEqual([a[1] for a in atoms],
                         ["DETERMINER", "WORD", "WORD", "PREPOSITION",
                          "DETERMINER", "WORD", "INTEGER_LITERAL",
                          "DELIMITER"])
        words = "the quick brown fox"
        watoms = tok.decode_atoms(tok.encode_text(words, language="english"))
        self.assertEqual([a[2] for a in watoms],
                         ["the", "quick", "brown", "fox"])
        self.assertEqual([a[1] for a in watoms],
                         ["DETERMINER", "WORD", "WORD", "WORD"])
        u = "caf\u00e9 na\u00efve"
        uids = tok.encode_text(u, language="english")
        values = [s[2:] for s in tok.decode(uids) if s.startswith("V:")]
        self.assertGreaterEqual(len(values), 2)
        self.assertIn("caf", values)

    def test_15_deterministic_repeatable_fit(self):
        corpus = [PY, PROSE, "y = 2 + 3", "public class Foo { }"]
        t1 = RTFTokenizer("atoms").fit_texts(corpus)
        t2 = RTFTokenizer("atoms").fit_texts(corpus)
        self.assertEqual(t1.itos, t2.itos)
        self.assertEqual(t1.stoi, t2.stoi)
        probe = "def g(y):\n    return y * 2"
        self.assertEqual(t1.encode_text(probe, language="python"),
                         t2.encode_text(probe, language="python"))


class BackwardCompatibilityChecks(unittest.TestCase):
    def test_db_kinds_and_structured_validate_still_work(self):
        m = RTF()
        try:
            m.add_text("def f(x):\n    return x + 1\n", language="python")
            m.add_text(PROSE, language="text")
            tok = m.fit_tokenizer("structured")
            ids = tok.encode_document(1)
            self.assertGreater(len(ids), 3)
            self.assertTrue(tok.decode(ids)[0].startswith("T:"))
            findings = tok.validate()
            for finding in findings:
                self.assertEqual(finding["status"], "PASS", finding)
            with tempfile.TemporaryDirectory() as tmp:
                path = str(Path(tmp) / "vocab.json")
                tok.save(path)
                tok2 = RTFTokenizer.load(path)
                self.assertEqual(tok2.kind, "structured")
                self.assertEqual(tok2.vocab_size, tok.vocab_size)
        finally:
            m.close()


if __name__ == "__main__":
    unittest.main()