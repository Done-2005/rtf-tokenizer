"""T-D1-01: exact reconstruction and determinism (frozen D1 spec).

Contract pinned by this suite (probed empirically against the
canonical source during the 2026-11-15 build):

- kind='char': decode(encode(x)) minus the trailing <eos> equals x
  EXACTLY - whitespace and Unicode included - for fitted content;
  unseen characters map to <unk> (id 1) and are reported as such.
- kind='atoms': decode_atoms(encode_text(x)) equals the canonical
  atom projection of tokenize_text(x) for the five domains and for
  tool-call specs; encoding is deterministic; rejoining the V values
  reproduces the whitespace-collapsed text (inter-token whitespace is
  layout, not content - the documented atoms contract).
- canonical (Copy-3 typed-atom streams): decode_triples(encode(s))
  preserves the content atoms; encoding is deterministic.
"""
import pytest

from rtf import RTFTokenizer
from rtf.canonical import CanonicalTokenizer
from rtf.tokenization.domains import tokenize_text

UNICODE_CORPUS = [
    "def add(a, b):\n    return a + b\n",
    "café naïve — résumé Straße\n",
    "日本語のテキストと漢字\n",
    "مرحبا بالعالم\n",
    "emoji: \U0001F680\U0001F525 \U0001F468\u200D\U0001F469\u200D\U0001F467\n",
    "combining: e\u0301 vs \u00e9\n",
    "tabs\tand   spaces   kept?\n",
]

DOMAIN_TEXTS = [
    ("def add(a, b):\n    return a + b", "python"),
    ("public class Main { public static void main(String[] a) {} }",
     "java"),
    ("10 + 32 = 42", "math"),
    ("The quick brown fox jumps over the lazy dog.", "english"),
]

TOOL_SPEC = {"function": "get_weather", "arguments": {"city": "Chennai"}}


def _fitted_atoms():
    tok = RTFTokenizer(kind="atoms").fit_texts(
        [t for t, _ in DOMAIN_TEXTS] + [TOOL_SPEC],
        [l for _, l in DOMAIN_TEXTS] + [None])
    return tok


# --- char kind: exact string round-trip ------------------------------

def test_char_exact_reconstruction_over_unicode_corpus():
    tok = RTFTokenizer(kind="char").fit_texts(UNICODE_CORPUS)
    for text in UNICODE_CORPUS:
        ids = tok.encode_text(text)
        assert "".join(tok.decode(ids)[:-1]) == text


def test_char_reconstruction_is_deterministic():
    tok = RTFTokenizer(kind="char").fit_texts(UNICODE_CORPUS)
    for text in UNICODE_CORPUS:
        assert tok.encode_text(text) == tok.encode_text(text)


def test_char_unseen_characters_map_to_unk():
    tok = RTFTokenizer(kind="char").fit_texts(UNICODE_CORPUS)
    ids = tok.encode_text("\u0007\u0007")
    assert ids[0] == 1 and ids[1] == 1      # both chars -> <unk>
    assert tok.decode(ids)[-1] == "<eos>"


# --- atoms kind: atom-sequence round trip ----------------------------

def test_atoms_round_trip_identity_all_domains():
    tok = _fitted_atoms()
    for text, lang in DOMAIN_TEXTS:
        ids = tok.encode_text(text, lang)
        direct = tokenize_text(text, lang)
        expected = [(direct[0].upper(), concept, value)
                    for concept, value in direct[1]]
        assert tok.decode_atoms(ids) == expected


def test_atoms_rejoin_reproduces_whitespace_collapsed_text():
    tok = _fitted_atoms()
    for text, lang in DOMAIN_TEXTS:
        ids = tok.encode_text(text, lang)
        rejoined = "".join(value for _tag, _row, value
                           in tok.decode_atoms(ids))
        assert rejoined == "".join(text.split())


def test_atoms_encoding_deterministic():
    tok = _fitted_atoms()
    for text, lang in DOMAIN_TEXTS:
        assert tok.encode_text(text, lang) == tok.encode_text(text, lang)


def test_tool_call_round_trip():
    tok = _fitted_atoms()
    ids = tok.encode_tool_call(TOOL_SPEC)
    assert ids == tok.encode_tool_call(TOOL_SPEC)
    assert tok.decode_atoms(ids) == [
        ("TOOL_CALL", "FUNCTION_NAME", "get_weather"),
        ("TOOL_CALL", "ARGUMENT_NAME", "city"),
        ("TOOL_CALL", "ARGUMENT_VALUE", "Chennai"),
    ]


# --- canonical streams -----------------------------------------------

def test_canonical_content_identity_and_determinism():
    ct = CanonicalTokenizer().fit_texts(
        ["10 plus 5", "def add(a, b): return a + b", "photosynthesis"],
        ["math", "python", "english"])
    for record in ct.records:
        stream = record["rtf_in"]
        ids = ct.encode(stream)
        assert ids == ct.encode(stream)
        triples = ct.decode_triples(ids)
        # symbol-level round trip is lossless (bijective vocab, C03):
        assert ct.decode(ids) == stream + ["<eos>"]
        # split-prefix grammar: the symbol AFTER each N:/R:/V: is the value
        # (value symbols equal to the bare punctuation symbol ':' are
        # collapsed by the decode_triples projection - documented finding;
        # the id stream and symbol decode are lossless)
        content_in = [stream[i + 1] for i, s in enumerate(stream)
                      if s in ("N:", "R:", "V:")
                      and stream[i + 1] != ":"]
        # decoded triples reproduce the same (prefix, value) sequence
        content_out = [triples[i + 1][1]
                       for i, t in enumerate(triples[:-1])
                       if t[0] in ("N:", "R:", "V:")
                       and triples[i + 1][0] == ""]
        assert content_in == content_out


def test_canonical_stream_kinds_round_trip():
    ct = CanonicalTokenizer().fit()
    probes = [
        ct.definition_stream("PYTHON"),
        ct.relation_stream("PYTHON", "USED_FOR", "STATISTICS"),
        ct.procedural_stream("ARITHMETIC", "arithmetic",
                             [("N:", "10"), ("R:", "TIMES"), ("N:", "5")]),
    ]
    for stream in probes:
        assert len(ct.decode_triples(ct.encode(stream))) >= 3
