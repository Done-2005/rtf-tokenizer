"""T-D1-06: serialization round-trips (frozen D1 spec).

Pinned behavior:

- RTFTokenizer save/load: vocabulary round-trips byte-exactly as a
  semantic map (stoi/itos identity), and a loaded tokenizer encodes
  identically to the original.
- CanonicalTokenizer save/load: vocabulary AND records round-trip
  (records deep-equal), encoding identical after load.
- Registration save/load: full identity round-trip; truncated and
  corrupt files fail closed; the monotonic guard on load never lets
  ids be reused (documented rewind-adoption behavior).
- canonical Registry to_dict/from_dict round-trips with the next
  number preserved.
"""
import json

import pytest

from rtf import RTFTokenizer, Registration
from rtf.canonical import CanonicalTokenizer


def _atoms_tok():
    return RTFTokenizer(kind="atoms").fit_texts(
        ["def add(a, b): return a + b", "10 + 32 = 42",
         "The quick brown fox.", "get_weather(city=Chennai)"],
        ["python", "math", "english", None])


def test_rtf_tokenizer_save_load_round_trip(tmp_path):
    tok = _atoms_tok()
    path = tmp_path / "tok.json"
    tok.save(path)
    loaded = RTFTokenizer.load(path)
    assert loaded.stoi == tok.stoi
    assert loaded.itos == tok.itos
    text = "def add(a, b): return a + b"
    assert loaded.encode_text(text, "python") == \
        tok.encode_text(text, "python")
    assert all(f["status"] == "PASS" for f in loaded.validate())


def test_canonical_save_load_round_trip(tmp_path):
    ct = CanonicalTokenizer().fit_texts(
        ["10 plus 5", "def add(a, b): return a + b", "photosynthesis"],
        ["math", "python", "english"])
    path = tmp_path / "ct.json"
    ct.save(path)
    loaded = CanonicalTokenizer.load(path)
    assert loaded.vocab() == ct.vocab()
    assert loaded.records == ct.records
    for record in loaded.records:
        assert loaded.encode(record["rtf_in"]) == \
            ct.encode(record["rtf_in"])


def test_registration_full_round_trip(tmp_path):
    reg = Registration()
    reg.cell("PYTHON", "FUNCTION_DECLARATION", "add")
    reg.cell("MATH", "ARITHMETIC_OPERATOR", "+")
    path = tmp_path / "reg.json"
    reg.save(path)
    loaded = Registration.load(path)
    assert loaded.tags == reg.tags and loaded.rows == reg.rows
    assert loaded.values == reg.values and loaded.cells == reg.cells
    assert loaded.max_id == reg.max_id


def test_registration_truncated_file_fails_closed(tmp_path):
    reg = Registration()
    reg.cell("PYTHON", "ROW", "v")
    path = tmp_path / "reg.json"
    reg.save(path)
    bad = tmp_path / "trunc.json"
    bad.write_bytes(path.read_bytes()[:25])
    with pytest.raises(Exception):
        Registration.load(bad)


def test_registration_tampered_payload_fails_or_guards(tmp_path):
    reg = Registration()
    reg.cell("PYTHON", "ROW", "v")            # ids 1..4
    path = tmp_path / "reg.json"
    reg.save(path)
    data = json.loads(path.read_text(encoding="utf-8"))
    data["counter"] = 2                        # rewind tamper
    path.write_text(json.dumps(data), encoding="utf-8")
    loaded = Registration.load(path)
    assert loaded.max_id == 4                  # monotonic guard adopts
    assert loaded.value_id("post-tamper") == 5  # no id reuse


def test_registry_instance_round_trip_preserves_next():
    from rtf.canonical.registry import Registry
    reg = Registry("col", "COL")
    reg.register("TAG")
    reg.register("ROW")
    clone = Registry("col", "COL").from_dict(reg.to_dict())
    assert clone.number("TAG") == 1 and clone.number("ROW") == 2
    assert clone.register("CELL") == 3         # _next preserved
