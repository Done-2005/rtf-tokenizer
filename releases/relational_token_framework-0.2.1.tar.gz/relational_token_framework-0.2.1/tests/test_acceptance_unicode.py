"""T-D1-02: Unicode handling (frozen D1 spec; U-UNI policy).

User decision U-UNI (2026-11-15): PRESERVE EXACT INPUT - no
normalization anywhere in the tokenizer path; NFC and NFD forms remain
distinct token sequences; round-trip is byte-faithful at the atom
level. These tests pin that policy:

- NFC and NFD renderings of the same word produce DIFFERENT atom
  sequences and DIFFERENT id sequences (no silent normalization).
- Each form round-trips exactly: the decomposed combining sequence is
  preserved verbatim as atom values (the combining mark appears as
  its own atom value, never merged or stripped).
- Emoji (astral plane, incl. ZWJ sequences), CJK, Arabic (RTL) and
  combining-diacritic text each survive the encode/decode round trip
  with rejoining intact and deterministic ids.
"""
import pytest

from rtf import RTFTokenizer
from rtf.tokenization.domains import tokenize_text

NFC = "caf\u00e9"          # composed: c a f é
NFD = "cafe\u0301"         # decomposed: c a f e + combining acute

UNICODE_PROBES = [
    ("emoji_astral", "ship \U0001F680 done"),
    ("emoji_zwj", "\U0001F468\u200D\U0001F469\u200D\U0001F467"),
    ("combining", "e\u0301x"),
    ("cjk", "\u65e5\u672c\u8a9e"),
    ("rtl_arabic", "\u0645\u0631\u062d\u0628\u0627"),
    ("nfc", NFC),
    ("nfd", NFD),
    ("latin1", "fa\u00e7ade stra\u00dfe"),
]


def _fitted_on_probes():
    tok = RTFTokenizer(kind="atoms").fit_texts(
        [s for _l, s in UNICODE_PROBES], ["english"] * len(UNICODE_PROBES))
    return tok


def test_nfc_and_nfd_yield_distinct_atom_sequences():
    _, atoms_nfc = tokenize_text(NFC, "english")
    _, atoms_nfd = tokenize_text(NFD, "english")
    assert atoms_nfc != atoms_nfd
    values_nfc = [v for _c, v in atoms_nfc]
    values_nfd = [v for _c, v in atoms_nfd]
    assert "caf" in values_nfc and "\u00e9" in values_nfc
    assert "cafe" in values_nfd and "\u0301" in values_nfd


def test_nfc_and_nfd_yield_distinct_id_sequences():
    tok = _fitted_on_probes()
    assert tok.encode_text(NFC, "english") != tok.encode_text(NFD, "english")


def test_decomposed_combining_mark_preserved_verbatim():
    tok = _fitted_on_probes()
    ids = tok.encode_text(NFD, "english")
    values = [value for _tag, _row, value in tok.decode_atoms(ids)]
    assert "\u0301" in values          # combining acute survives as-is
    assert "\u00e9" not in values      # no normalization to NFC


def test_every_unicode_probe_round_trips_and_is_deterministic():
    tok = _fitted_on_probes()
    for _label, text in UNICODE_PROBES:
        ids = tok.encode_text(text, "english")
        assert ids == tok.encode_text(text, "english")
        rejoined = "".join(value for _tag, _row, value
                           in tok.decode_atoms(ids))
        assert rejoined == "".join(text.split())


def test_char_kind_preserves_astral_plane_exactly():
    tok = RTFTokenizer(kind="char").fit_texts(
        [s for _l, s in UNICODE_PROBES])
    for _label, text in UNICODE_PROBES:
        assert "".join(tok.decode(tok.encode_text(text))[:-1]) == text


def test_char_kind_distinguishes_nfc_nfd():
    tok = RTFTokenizer(kind="char").fit_texts([NFC, NFD])
    assert tok.encode_text(NFC) != tok.encode_text(NFD)
    assert "".join(tok.decode(tok.encode_text(NFD))[:-1]) == NFD
