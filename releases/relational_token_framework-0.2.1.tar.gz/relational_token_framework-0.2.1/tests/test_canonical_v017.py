"""Canonical tokenizer test suite (0.1.7, Copy-3-true gate).

Pins the NEW CanonicalTokenizer (rtf.canonical) to the verified Copy-3
typed-atom pipeline: canonical specials WITH <sep>, the Q/:/T:/R:/V:/N:/E/ASK
stream grammar, Enc union vocabulary with sorted symbols, EncodedPair
loss_start/slots, schema guard, collision audit (v3 rule), parameter parity,
per-kind permanent registry, cross-domain and persistence.

    python -m unittest test_canonical_v017
"""

import json
import tempfile
import unittest
from pathlib import Path

from rtf.canonical import (
    CanonicalTokenizer,
    DEFS,
    PROCEDURAL,
    RELATIONS,
    ASK,
    COL,
    E,
    PAD,
    Q,
    R,
    SEP,
    T,
    UNK,
    V,
    Enc,
    EncodedPair,
    build_records,
    make_pair,
    serialize_plain,
    verify_parity,
)
from rtf.canonical import (
    ROWS,
    TAGS_REGISTRY,
    COLS,
    CELLS,
    audit_unique,
    register_col,
    register_cell,
)


def _fitted():
    return CanonicalTokenizer().fit()


class CanonicalStreamChecks(unittest.TestCase):
    def test_1_specials_include_sep(self):
        self.assertEqual([PAD, UNK, SEP], ["<pad>", "<unk>", "<sep>"])
        tok = _fitted()
        for special in ("<pad>", "<unk>", "<sep>", "<eos>"):
            self.assertIn(special, tok.vocab())
            self.assertIn(special, tok.specials)
        self.assertEqual(tok.specials, ["<pad>", "<unk>", "<sep>", "<eos>"])

    def test_2_definition_atoms_grammar(self):
        tok = _fitted()
        stream = tok.definition_stream("PYTHON")
        self.assertEqual(stream, [Q, COL, "T:", "PYTHON", "V:", "PYTHON",
                                  E, ASK, "MEANING"])

    def test_3_relation_atoms_grammar(self):
        tok = _fitted()
        stream = tok.relation_stream("PYTHON", "USED_FOR", "STATISTICS")
        self.assertEqual(stream, [Q, COL, "T:", "PYTHON", "R:", "USED_FOR",
                                  "T:", "STATISTICS", E, ASK, "RELATION"])

    def test_4_procedural_atoms_grammar_v3_content(self):
        tok = _fitted()
        content = [("N:", "10"), ("R:", "TIMES"), ("N:", "5")]
        stream = tok.procedural_stream("ARITHMETIC", "arithmetic", content)
        self.assertEqual(stream, [Q, COL, "T:", "ARITHMETIC", E,
                                  "N:", "10", "R:", "TIMES", "N:", "5",
                                  ASK, "ARITHMETIC"])

    def test_5_two_questions_do_not_collapse(self):
        """v3 rule: 10x5 and 15x8 produce DISTINCT inputs."""
        q1 = CanonicalTokenizer().procedural_stream(
            "ARITHMETIC", "arithmetic", [("N:", "10"), ("R:", "TIMES"),
                                         ("N:", "5")])
        q2 = CanonicalTokenizer().procedural_stream(
            "ARITHMETIC", "arithmetic", [("N:", "15"), ("R:", "TIMES"),
                                         ("N:", "8")])
        self.assertNotEqual(q1, q2)

    def test_6_serialize_plain_and_deserialize(self):
        tok = _fitted()
        stream = tok.serialize("what is 10 times 5 ?", "ARITHMETIC",
                               "arithmetic")
        self.assertEqual(stream, [Q, COL, "T:", "ARITHMETIC", E,
                                  "N:", "10", "N:", "5", "R:", "TIMES",
                                  ASK, "ARITHMETIC"])
        text = tok.deserialize(stream)
        self.assertEqual(text, "Q : T: ARITHMETIC E N: 10 N: 5 R: TIMES "
                               "ASK ARITHMETIC")
        self.assertEqual(serialize_plain("what is 2 plus 2 ?",
                                         "ARITHMETIC", "arithmetic"),
                         [Q, COL, "T:", "ARITHMETIC", E, "N:", "2",
                          "N:", "2", "R:", "PLUS", ASK, "ARITHMETIC"])


class EncoderChecks(unittest.TestCase):
    def test_7_enc_union_vocab_sorted_after_specials(self):
        enc = Enc(["N:5", "T:ARITHMETIC", "N:10", "R:TIMES"])
        self.assertEqual(enc.itos[:4], ["<pad>", "<unk>", "<sep>", "<eos>"])
        tail = enc.itos[4:]
        self.assertEqual(tail, sorted(enc.itos[4:]))
        self.assertEqual(enc.vocab_size, len(enc.itos))

    def test_8_make_pair_sep_loss_start_slots(self):
        tok = _fitted()
        pair = tok.make_pair(
            tok.definition_stream("PYTHON"),
            tok.definition_answer_stream("PYTHON"), pair_id="DEF_PYTHON")
        self.assertIsInstance(pair, EncodedPair)
        sep_i = pair.ids.index(tok.token_to_id(SEP))
        self.assertEqual(pair.loss_start, sep_i + 1)
        self.assertEqual(pair.slots[-1][1], "EOS")
        self.assertEqual(pair.slots[-1][0], len(pair.ids) - 1)
        # solution region: every index at/after loss_start is the answer
        self.assertEqual(len(pair.ids) - pair.loss_start,
                         len(tok.definition_answer_stream("PYTHON")) + 1)


class FitChecks(unittest.TestCase):
    def test_9_fit_builds_canonical_records(self):
        tok = _fitted()
        n_defs = len(DEFS)
        n_rels = len(RELATIONS)
        n_proc = len(PROCEDURAL)
        self.assertEqual(len(tok.records), n_defs + n_rels + n_proc)
        ids = {r["id"] for r in tok.records}
        self.assertEqual(len(ids), len(tok.records))

    def test_10_canonical_records_preserve_cross_domain(self):
        rek = build_records(DEFS, RELATIONS, PROCEDURAL)
        rels = [r for r in rek if r["category"] == "relation"]
        self.assertEqual(len(rels), len(RELATIONS))
        cross = [r for r in rels if r["cross"]]
        self.assertEqual(len(cross), 6)
        py = next(r for r in rels if r["id"] == "REL_PYTHON_USED_FOR_STATISTICS")
        self.assertEqual(py["domain"], "PYTHON")
        self.assertTrue(py["cross"])
        self.assertEqual(py["rtf_out"],
                         ["PYTHON", "USED_FOR", "STATISTICS",
                          "CONF", "HIGH", "ACTION", "EXECUTE"])


class ValidationChecks(unittest.TestCase):
    def test_11_validate_all_pass(self):
        tok = _fitted()
        findings = tok.validate()
        self.assertTrue(findings)
        for finding in findings:
            self.assertEqual(finding["status"], "PASS", finding)
        codes = [f["code"] for f in findings]
        for code in ("C01", "C02", "C03", "C04", "C05", "C06", "C07"):
            self.assertIn(code, codes)

    def test_12_collision_audit_aborts_colliding_inputs(self):
        """identical input -> different answers MUST abort (v3 rule)."""
        from rtf.canonical.validation import audit_collisions
        colliding = [
            {"rtf_in": [Q, COL, "T:ARITHMETIC"], "rtf_out": ["4"]},
            {"rtf_in": [Q, COL, "T:ARITHMETIC"], "rtf_out": ["50"]},
        ]
        with self.assertRaises(SystemExit):
            audit_collisions(colliding,
                             lambda r: r["rtf_in"],
                             lambda r: r["rtf_out"],
                             "collision-test")
        clean = [
            {"rtf_in": [Q, COL, "T:ARITHMETIC", "N:10", "R:TIMES", "N:5"],
             "rtf_out": ["50"]},
            {"rtf_in": [Q, COL, "T:ARITHMETIC", "N:15", "R:TIMES", "N:8"],
             "rtf_out": ["120"]},
        ]
        self.assertEqual(audit_collisions(clean,
                                          lambda r: r["rtf_in"],
                                          lambda r: r["rtf_out"],
                                          "clean-test"), 0)

    def test_13_verify_parity_requires_equal(self):
        self.assertTrue(verify_parity(105136, 105136))
        with self.assertRaises(SystemExit):
            verify_parity(105136, 0)


class CrossDomainChecks(unittest.TestCase):
    def test_14_canonical_tokenizer_cross_domain(self):
        tok = _fitted()
        self.assertIn(("USED_FOR", "STATISTICS"),
                      tok.relationships("PYTHON"))
        v = tok.cross_domain("PYTHON", "USED_FOR", "STATISTICS")
        self.assertEqual((v.state, v.confidence, v.action),
                         ("EXISTS", "HIGH", "EXECUTE"))
        self.assertEqual(tok.respond_relation("PYTHON", "USED_FOR",
                                              "STATISTICS"),
                         ["PYTHON", "USED_FOR", "STATISTICS",
                          "CONF", "HIGH", "ACTION", "EXECUTE"])


class RegistryChecks(unittest.TestCase):
    def test_15_registry_per_kind_labels_contiguous(self):
        # fresh registries per test (canonical module-level regs)
        regs = [TAGS_REGISTRY, ROWS, COLS, CELLS]
        for reg in regs:
            self.assertEqual(len(reg), 0)
        c1 = register_col("meaning")
        c2 = register_col("relationship")
        self.assertEqual(COLS.label(c1), "COL-000001")
        self.assertEqual(c2, c1 + 1)
        t1 = TAGS_REGISTRY.register("PYTHON", domain="PYTHON")
        t2 = TAGS_REGISTRY.register("MATHEMATICS", domain="MATHEMATICS")
        self.assertEqual(TAGS_REGISTRY.label(t1), "TAG-000001")
        # idempotent by key; never reused
        self.assertEqual(TAGS_REGISTRY.register("PYTHON"), t1)
        r1 = ROWS.register("DEF_PYTHON", domain="PYTHON")
        self.assertEqual(ROWS.label(r1), "ROW-000001")
        cell = register_cell(r1, c1, "the python programming language")
        self.assertGreaterEqual(CELLS.label(cell), "CELL-000001")
        audit = audit_unique()
        for kind, result in audit.items():
            self.assertTrue(result["numbers_unique"], kind)
            self.assertTrue(result["keys_unique"], kind)
            self.assertTrue(result["numbers_contiguous"], kind)

    def test_16_registry_save_load_round_trip(self):
        TAGS_REGISTRY.register("JAVA", domain="JAVA")
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / "registry.json")
            from rtf.canonical.registry import save_json, load_json
            n_before = len(TAGS_REGISTRY)
            save_json(path)
            load_json(path)
            self.assertEqual(len(TAGS_REGISTRY), n_before)
            self.assertEqual(TAGS_REGISTRY.number("JAVA"),
                             TAGS_REGISTRY.number("JAVA"))


class PersistenceChecks(unittest.TestCase):
    def test_17_save_load_round_trip(self):
        tok = _fitted()
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / "canonical.json")
            tok.save(path)
            data = json.loads(Path(path).read_text(encoding="utf-8"))
            self.assertEqual(data["kind"], "canonical")
            tok2 = CanonicalTokenizer.load(path)
            self.assertEqual(tok2.kind, "canonical")
            self.assertEqual(tok2.vocab_size, tok.vocab_size)
            self.assertEqual(tok2.itos, tok.itos)
            stream = tok.definition_stream("PYTHON")
            self.assertEqual(tok2.encode(stream), tok.encode(stream))
            self.assertEqual(tok2.decode(tok2.encode(stream)),
                             tok.decode(tok.encode(stream)))


if __name__ == "__main__":
    unittest.main()