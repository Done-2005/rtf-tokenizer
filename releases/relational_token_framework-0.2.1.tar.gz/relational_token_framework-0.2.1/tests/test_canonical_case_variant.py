"""Tests for the case diagnostic (case_diag) and the additive RTF-CASE
variant (case_variant). Frozen canonical builders are NOT modified."""

import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(os.path.dirname(HERE), "src")
if SRC not in sys.path:
    sys.path.insert(0, SRC)

EP = sys.executable

from rtf.canonical import (  # noqa: E402
    CanonicalTokenizer, V_CASE, apply_case_meta_to_records,
    build_case_variant_pairs, case_kind, classify, extract_values,
    summarize, value_report, value_report_streams, with_case_meta,
    strip_case_meta, case_meta_atom, case_summary,
)


def _fitted():
    return CanonicalTokenizer().fit()


class CaseKindTests(unittest.TestCase):
    def test_upper_lower_title_mixed(self):
        self.assertEqual(case_kind("PRINT"), "UPPER")
        self.assertEqual(case_kind("print"), "LOWER")
        self.assertEqual(case_kind("Print"), "TITLE")
        self.assertEqual(case_kind("printX"), "MIXED")

    def test_none_for_nonalpha(self):
        self.assertEqual(case_kind("("), "NONE")
        self.assertEqual(case_kind("10"), "NONE")
        self.assertEqual(case_kind("-"), "NONE")

    def test_title_first_only(self):
        self.assertEqual(case_kind("getValue"), "MIXED")
        self.assertEqual(case_kind("get_value"), "LOWER")


class ExtractValuesTests(unittest.TestCase):
    def test_extract_from_stream(self):
        stream = ["Q", ":", "T:", "ARITHMETIC", "E",
                  "V:", "Print", "R:", "PLUS", "ASK", "ARITHMETIC"]
        vals = extract_values(stream)
        self.assertEqual(vals, [("V:", "Print")])

    def test_multiple_values(self):
        stream = ["Q", ":", "T:", "ARITHMETIC", "E",
                  "N:", "10", "R:", "TIMES", "N:", "5",
                  "ASK", "ARITHMETIC"]
        # default extracts V: only; explicit prefixes pull all value slots
        self.assertEqual(extract_values(stream), [])
        self.assertEqual(extract_values(stream, prefixes=("N:", "R:", "V:")),
                         [("N:", "10"), ("R:", "TIMES"), ("N:", "5")])

    def test_definition_answer_bare_words(self):
        ans = ["PYTHON", "a", "programming", "language"]
        self.assertEqual(extract_values(ans), [])


class ClassifyTests(unittest.TestCase):
    def test_buckets(self):
        self.assertEqual(classify("Print", "Print"), "exact")
        self.assertEqual(classify("Print", "print"), "case_only")
        self.assertEqual(classify("Print", "PRINT"), "case_only")
        self.assertEqual(classify("Print", "Car"), "different")
        self.assertEqual(classify("Print", None), "missing")
        self.assertEqual(classify(None, "print"), "extra")


class ValueReportTests(unittest.TestCase):
    def test_all_exact(self):
        r = value_report(["print", "a"], ["print", "a"])
        self.assertEqual(r["exact"], 2)
        self.assertEqual(r["value_exact_accuracy"], 1.0)

    def test_case_only_error_fraction(self):
        r = value_report(["Print", "x"], ["print", "y"])
        self.assertEqual(r["case_only"], 1)
        self.assertEqual(r["different"], 1)
        self.assertEqual(r["case_only_fraction_of_errors"], 0.5)

    def test_missing(self):
        r = value_report(["a", "b", "c"], ["a"])
        self.assertEqual(r["missing"], 2)
        self.assertEqual(r["value_exact_accuracy"], round(1 / 3, 4))

    def test_case_insensitive_accuracy(self):
        r = value_report(["Print", "Car"], ["print", "cat"])
        self.assertEqual(r["value_case_insensitive_accuracy"], 0.5)

    def test_summarize(self):
        s = summarize([value_report(["Print"], ["print"]),
                       value_report(["x"], ["x"])])
        self.assertEqual(s["n_pairs"], 2)
        self.assertEqual(s["n_gold_values"], 2)
        self.assertEqual(s["value_exact_accuracy"], 0.5)
        self.assertEqual(s["case_only_fraction_of_errors"], 1.0)


class CaseVariantTests(unittest.TestCase):
    def test_with_case_meta_inserts_before_v(self):
        stream = ["Q", ":", "T:", "ARITHMETIC", "E",
                  "V:", "Print", "R:", "PLUS", "ASK", "ARITHMETIC"]
        out = with_case_meta(stream)
        self.assertEqual(out, ["Q", ":", "T:", "ARITHMETIC", "E",
                               V_CASE + "TITLE", "V:", "Print",
                               "R:", "PLUS", "ASK", "ARITHMETIC"])

    def test_strip_restores_baseline(self):
        stream = ["Q", ":", "T:", "ARITHMETIC", "E",
                  "V:", "print", "ASK", "ARITHMETIC"]
        out = with_case_meta(stream)
        self.assertEqual(strip_case_meta(out), stream)

    def test_v_values_get_exact_value_preserved(self):
        # V:PRINT / V:print / V:Print remain distinct; only atoms added.
        s = ["Q", ":", "T:", "CODE", "E", "V:", "PRINT", "ASK", "CODE"]
        out = with_case_meta(s)
        self.assertIn("V:", out)
        self.assertIn("PRINT", out)
        self.assertEqual([t for t in out if t == "PRINT"], ["PRINT"])
        self.assertEqual([t for t in out if t == V_CASE + "UPPER"],
                         [V_CASE + "UPPER"])

    def test_case_meta_atom_kinds(self):
        self.assertEqual(case_meta_atom("Print"), "V_CASE:TITLE")
        self.assertEqual(case_meta_atom("PRINT"), "V_CASE:UPPER")
        self.assertEqual(case_meta_atom("10"), "V_CASE:NONE")

    def test_build_case_variant_pairs(self):
        tok = _fitted()
        pairs = build_case_variant_pairs(tok.records)
        self.assertEqual(len(pairs), len(tok.records))
        # every V_CASE atom is in the union vocab
        syms = set()
        for r in apply_case_meta_to_records(tok.records):
            syms.update(r["rtf_in"])
        enc = pairs[0].ids
        self.assertTrue(len(enc) > 0)
        case_syms = {s for s in syms if s.startswith(V_CASE)}
        self.assertGreater(len(case_syms), 0)
        # pair structure preserved
        self.assertGreaterEqual(pairs[0].loss_start, 1)
        self.assertTrue(pairs[0].slots)

    def test_case_summary_counts_v_values(self):
        tok = _fitted()
        s = case_summary(tok.records)
        self.assertEqual(s["v_without_value"], 0)
        self.assertGreater(s["v_values"], 0)

    def test_collision_audit_still_clean_on_variant(self):
        tok = _fitted()
        variant = apply_case_meta_to_records(tok.records)
        inp2ans = {}
        import itertools
        for r in variant:
            key = tuple(r["rtf_in"])
            inp2ans.setdefault(key, set()).add(tuple(r["rtf_out"]))
        collisions = {k: v for k, v in inp2ans.items() if len(v) > 1}
        self.assertEqual(collisions, {})

    def test_frozen_baseline_vocab_has_no_v_case(self):
        # The additive variant must NOT leak into the frozen tokenizer.
        tok = _fitted()
        self.assertFalse(any(s.startswith(V_CASE) for s in tok.stoi))

    def test_variant_encoder_includes_case_atoms(self):
        # The variant's own union encoder carries the new atoms, so the
        # RTF-CASE arm is trainable with identical parameter count.
        tok = _fitted()
        pairs = build_case_variant_pairs(tok.records)
        syms = set()
        for r in apply_case_meta_to_records(tok.records):
            syms.update(r["rtf_in"])
            syms.update(r["rtf_out"])
        self.assertTrue(any(s.startswith(V_CASE) for s in syms))
        self.assertEqual(len(pairs), len(tok.records))


if __name__ == "__main__":
    unittest.main(verbosity=2)