"""DTK-001 regression: atoms encode_text() must accept dict tool specs.

S5.5 includes dict items in the portable atoms vocabulary contract, and
S7.3 requires the T/R/V/EOS stream shape. The same triples are already
handled by fit_texts() and encode_tool_call(); encode_text() must agree.
"""
from __future__ import annotations

from rtf import RTFTokenizer, tool_call_atoms

CALLS = [
    {"function": "get_weather", "arguments": {"city": "Chennai"}},
    {"function": "f"},
    {"name": "g", "arguments": [1, "two", None]},
]


def test_atoms_encode_text_matches_encode_tool_call_for_dict_specs():
    tok = RTFTokenizer(kind="atoms").fit_texts(CALLS)

    for call in CALLS:
        via_text = tok.encode_text(call)
        via_tool = tok.encode_tool_call(call)
        assert via_text == via_tool
        assert via_text[-1] == tok.stoi["<eos>"]

        decoded = tok.decode(via_text)
        assert decoded[0] == "T:TOOL_CALL"
        assert all(s.startswith(("R:", "V:")) for s in decoded[1:-1])
        assert decoded[-1] == "<eos>"

        expected_pairs = [(concept, value)
                          for _tag, concept, value in tool_call_atoms(call)]
        assert tok.decode_atoms(via_text) == list(tool_call_atoms(call))
        assert expected_pairs  # non-empty for each fixture
