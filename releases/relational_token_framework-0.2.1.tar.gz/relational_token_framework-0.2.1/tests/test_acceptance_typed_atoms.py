"""T-D1-05: typed atoms and the canonical grammar (frozen D1 spec).

Pinned behavior:

- canonical grammar: Q : T: R: V: N: E ASK punctuation, specials
  [<pad>, <unk>, <sep>, <eos>] (with <sep> present), definition /
  relation / procedural streams encode and decode_triples exactly.
- the portable [T,R,V] grammar: every vocabulary symbol is a typed
  symbol (T:/R:/V: prefixes) or a special - guard V04.
- UNK-guard: unknown stream symbols map to the <unk> id, and decode
  reports them as '<unk>' (never silently dropped, never invented).
- serialize/deserialize: deterministic typed stream per question and
  a readable rendering.
"""
import pytest

from rtf import RTFTokenizer
from rtf.canonical import CanonicalTokenizer

SPECIALS = ["<pad>", "<unk>", "<sep>", "<eos>"]


def _fitted():
    ct = CanonicalTokenizer().fit_texts(
        ["10 plus 5", "def add(a, b): return a + b", "photosynthesis"],
        ["math", "python", "english"])
    return ct


# --- canonical grammar ------------------------------------------------

def test_canonical_specials_present_including_sep():
    ct = _fitted()
    vocab = ct.vocab()
    for special in SPECIALS:
        assert special in vocab


def test_definition_stream_shape_and_round_trip():
    ct = CanonicalTokenizer().fit()
    stream = ct.definition_stream("PYTHON")
    assert stream[0] == "Q" and ":" in stream
    assert stream[stream.index("T:") + 1] == "PYTHON"   # split T: prefix
    assert "E" in stream and "ASK" in stream
    triples = ct.decode_triples(ct.encode(stream))
    assert any(value == "PYTHON" and kind in ("TAG", "ANSWER")
               for _p, value, kind in triples)


def test_relation_stream_shape_and_round_trip():
    ct = CanonicalTokenizer().fit()
    stream = ct.relation_stream("PYTHON", "USED_FOR", "STATISTICS")
    assert "R:" in stream and "USED_FOR" in stream     # split R: prefix
    assert "STATISTICS" in stream and "ASK" in stream
    triples = ct.decode_triples(ct.encode(stream))
    values = [value for _p, value, kind in triples
              if kind in ("CONTENT", "ANSWER") and value]
    assert "USED_FOR" in values and "STATISTICS" in values


def test_procedural_stream_numbers_use_n_prefix():
    ct = CanonicalTokenizer().fit()
    stream = ct.procedural_stream("ARITHMETIC", "arithmetic",
                                  [("N:", "10"), ("R:", "TIMES"),
                                   ("N:", "5")])
    assert "N:" in stream and "10" in stream           # split N: prefix
    assert "TIMES" in stream and "5" in stream
    assert "ASK" in stream and "ARITHMETIC" in stream


def test_serialize_deterministic_and_deserialize_readable():
    ct = CanonicalTokenizer().fit()
    q = "What is 10 times 5?"
    first = ct.serialize(q, "ARITHMETIC", "arithmetic")
    assert first == ct.serialize(q, "ARITHMETIC", "arithmetic")
    assert ct.deserialize(first) == " ".join(first)


def test_unk_guard_maps_unknown_symbols():
    ct = _fitted()
    unk_id = ct.stoi["<unk>"]
    ids = ct.encode(["T:PYTHON", "R:NEVER_SEEN_BEFORE"])
    assert ids[1] == unk_id
    assert ct.decode(ids)[1] == "<unk>"
    eos = ct.stoi["<eos>"]
    assert ids[-1] == eos                       # encode appends <eos>


# --- portable [T,R,V] grammar -----------------------------------------

def test_atoms_vocabulary_symbols_all_typed_or_special():
    tok = RTFTokenizer(kind="atoms").fit_texts(
        ["def add(a, b): return a + b", "The cat sat."],
        ["python", "english"])
    specials = {"<pad>", "<unk>", "<eos>"}
    bad = [s for s in tok.itos
           if not (s.startswith(("T:", "R:", "V:")) or s in specials)]
    assert bad == []


def test_atoms_head_tag_and_pairing():
    tok = RTFTokenizer(kind="atoms").fit_texts(
        ["def add(a, b): return a + b"], ["python"])
    ids = tok.encode_text("def add(a, b): return a + b", "python")
    symbols = tok.decode(ids)
    assert symbols[0].startswith("T:")          # single T: head
    assert symbols[-1] == "<eos>"
    rest = symbols[1:-1]
    assert all(sym.startswith(("R:", "V:")) for sym in rest)
    assert len(rest) % 2 == 0                   # (R, V) pairs
