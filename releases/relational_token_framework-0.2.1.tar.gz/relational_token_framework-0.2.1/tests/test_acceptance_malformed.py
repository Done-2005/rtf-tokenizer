"""T-D1-03: malformed and edge inputs (frozen D1 spec).

Pinned behavior (probed empirically against the canonical source,
2026-11-15; deviations from the frozen fail-closed wording are
RECORDED FINDINGS in the chain-45 build record, not silent fixes):

- Unfitted tokenizers fail CLOSED (ValueError) on every entry point.
- Empty and whitespace-only inputs produce the documented degenerate
  but deterministic stream (T head + <eos>) - no corruption, no
  invented content.
- NUL bytes are preserved as atom values (content-preserving catch-
  all), never silently dropped.
- Invalid language codes: DOCUMENTED DETERMINISTIC FALLBACK to the
  english domain (tokenize_text falls back; nothing is invented).
  The frozen spec asked for fail-closed exceptions here; the sealed
  lineage behavior is fallback, and changing it would alter the
  behavior the sealed Step-6 evidence was produced with - so the
  fallback is pinned by test and flagged as a finding for the user.
- Malformed tool specs (non-dict) yield the documented degenerate
  T:TOOL_CALL + <eos> stream (tool_call_atoms skips non-dicts).
- Truncated/corrupt persistence files fail CLOSED (JSONDecodeError).
- There is no line-length cap in the tokenizer path; an oversized
  line encodes deterministically.
"""
import pytest

from rtf import RTFTokenizer
from rtf.tokenization.domains import tokenize_text


def _fitted_atoms():
    texts = ["def add(a, b): return a + b", "10 + 32 = 42",
             "The quick brown fox.", "a\x00b",
             {"function": "get_weather", "arguments": {"city": "Chennai"}}]
    langs = ["python", "math", "english", "english", None]
    return RTFTokenizer(kind="atoms").fit_texts(texts, langs)


# --- fail-closed entry points ----------------------------------------

def test_unfitted_tokenizer_fails_closed():
    tok = RTFTokenizer(kind="atoms")
    with pytest.raises(ValueError):
        tok.encode_text("hello", "english")
    with pytest.raises(ValueError):
        tok.encode_tool_call({"function": "f", "arguments": {}})
    with pytest.raises(ValueError):
        tok.decode([0, 1])


def test_wrong_kind_entry_points_fail_closed():
    char_tok = RTFTokenizer(kind="char").fit_texts(["abc"])
    with pytest.raises(ValueError):
        char_tok.encode_tool_call({"function": "f", "arguments": {}})
    with pytest.raises(ValueError):
        RTFTokenizer(kind="structured").fit_texts(["abc"])


# --- degenerate but deterministic inputs ------------------------------

def test_empty_text_gives_documented_degenerate_stream():
    tok = _fitted_atoms()
    ids = tok.encode_text("", "english")
    assert len(ids) == 2                       # T head + <eos>
    assert ids[0] == tok.stoi["T:ENGLISH"]
    assert ids[-1] == tok.stoi["<eos>"]
    assert ids == tok.encode_text("", "english")
    assert tok.decode_atoms(ids) == []         # no invented content


def test_whitespace_only_text_gives_degenerate_stream():
    tok = _fitted_atoms()
    ids = tok.encode_text("   \n\t  ", "english")
    assert len(ids) == 2
    assert ids == tok.encode_text(" \t\n ", "english")
    assert tok.decode_atoms(ids) == []


def test_nul_byte_preserved_as_atom_value():
    tok = _fitted_atoms()
    ids = tok.encode_text("a\x00b", "english")
    values = [value for _tag, _row, value in tok.decode_atoms(ids)]
    assert "\x00" in values                    # never silently dropped
    # stream-level preservation is vocabulary-independent:
    _lang, atoms = tokenize_text("a\x00b", "english")
    assert "\x00" in [v for _c, v in atoms]


def test_oversized_line_encodes_deterministically():
    tok = _fitted_atoms()
    big = "word " * 20000
    ids = tok.encode_text(big, "english")
    assert ids == tok.encode_text(big, "english")
    assert len(ids) > 20000


# --- documented fallbacks (findings, pinned as behavior) --------------

def test_invalid_language_documented_english_fallback():
    tok = _fitted_atoms()
    ids = tok.encode_text("hello", "klingon")
    tag = tok.decode_atoms(ids)[0][0]
    assert tag == "ENGLISH"                    # deterministic fallback


def test_non_dict_tool_spec_documented_degenerate_stream():
    tok = _fitted_atoms()
    ids = tok.encode_tool_call("not-a-dict")
    assert len(ids) == 2                       # T:TOOL_CALL + <eos>
    assert ids[0] == tok.stoi["T:TOOL_CALL"]
    assert ids[-1] == tok.stoi["<eos>"]
    assert tok.decode_atoms(ids) == []


# --- persistence fails closed ----------------------------------------

def test_truncated_tokenizer_file_fails_closed(tmp_path):
    tok = _fitted_atoms()
    path = tmp_path / "tok.json"
    tok.save(path)
    bad = tmp_path / "trunc.json"
    bad.write_bytes(path.read_bytes()[:40])
    with pytest.raises(Exception):
        RTFTokenizer.load(bad)


def test_corrupt_tokenizer_file_fails_closed(tmp_path):
    bad = tmp_path / "corrupt.json"
    bad.write_text("{not json", encoding="utf-8")
    with pytest.raises(Exception):
        RTFTokenizer.load(bad)


def test_char_kind_non_string_input_is_deterministic_edge():
    # documented edge: a dict is not a valid text; the char path
    # encodes its keys as text deterministically (finding recorded).
    tok = RTFTokenizer(kind="char").fit_texts(["abc"])
    ids = tok.encode_text({"a": 1})
    assert ids == tok.encode_text({"a": 1})
