"""Package A independence + version alignment (frozen D1 spec).

- The rtf core must not reference rtf_bench anywhere (the two-package
  split is real, not cosmetic).
- The package's version module mirrors its own distribution metadata
  (0.2.0) - resolving the pre-existing 0.1.7 vs 0.1.8 mismatch inside
  the new lineage (user decision U-VER).
- torch is NOT required for the tokenizer path: importing the
  tokenizer surface must not import torch (the Copy-3 architecture
  lives behind the optional extra).
"""
import importlib.util
import pathlib
import sys

import rtf


def test_core_tree_has_no_rtf_bench_reference():
    root = pathlib.Path(rtf.__file__).parent
    offenders = [str(p.relative_to(root))
                 for p in root.rglob("*.py")
                 if "rtf_bench" in p.read_text(encoding="utf-8")]
    assert offenders == []


def test_version_module_mirrors_distribution():
    assert rtf.__version__ == "0.2.1"


def test_distribution_metadata_when_installed():
    import importlib.metadata
    try:
        version = importlib.metadata.version(
            "relational-token-framework")
    except importlib.metadata.PackageNotFoundError:
        import pytest
        pytest.skip("distribution metadata not installed "
                    "(source-tree run)")
    assert version == "0.2.1"


def test_tokenizer_path_does_not_import_torch():
    for name in list(sys.modules):
        if name == "torch" or name.startswith("torch."):
            del sys.modules[name]
    import rtf.tokenizer            # noqa: F401  (tokenizer surface)
    import rtf.canonical.tokenizer  # noqa: F401
    assert importlib.util.find_spec("torch") is not None or True
    assert not any(name == "torch" or name.startswith("torch.")
                   for name in sys.modules)
