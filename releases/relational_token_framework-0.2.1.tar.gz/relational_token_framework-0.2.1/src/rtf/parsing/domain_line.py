"""Generic line-based domain parser for the science/medical/english/
history domains.

Line-based like the math parser; every token resolves through the
per-language curated keyword table (DOMAIN_KEYWORD_MAPS) - unknown words
become VARIABLE_BINDING proposals (honest), unknown symbols are
rejected. Each non-empty line becomes an EXPRESSION root covering its
atoms; a top-level relation ('=' or 'is') splits LHS/RHS like the math
parser.
"""

from __future__ import annotations

import re

from ..core.model import Extraction, ParseResult, Rejection, StructureNode
from ..semantics import concepts as C
from ..semantics.concepts import resolve_keyword
from .base import Parser, line_starts, position_of

_TOKEN = re.compile(r"\d+\.\d+|\d+|[A-Za-z_]\w*|[^\s]")


class DomainLineParser(Parser):
    """Parameterized line parser; `language` selects the keyword table."""

    def __init__(self, language: str) -> None:
        super().__init__()
        self.language = language

    def parse(self, source: str) -> ParseResult:
        result = ParseResult()
        starts = line_starts(source)
        for line_match in re.finditer(r"[^\n]+", source):
            raw_line = line_match.group(0)
            if not raw_line.strip():
                continue
            self._parse_line(raw_line, line_match.start(), starts, result)
        return result

    def _parse_line(self, raw_line: str, line_offset: int,
                    starts: list[int], result: ParseResult) -> None:
        leaves: list[int] = []
        relation_position: int | None = None
        for match in _TOKEN.finditer(raw_line):
            token = match.group(0)
            line_no, col = position_of(starts, line_offset + match.start())
            if token == "=":
                if relation_position is None:
                    relation_position = len(leaves)
                leaves.append(self._emit(result, C.RELATIONAL_OPERATOR,
                                         token, line_no, col))
                continue
            concept = resolve_keyword(self.language, token)
            if concept is not None:
                leaves.append(self._emit(result, concept, token,
                                         line_no, col))
                continue
            if re.fullmatch(r"\d+\.\d+", token):
                leaves.append(self._emit(result, C.FLOAT_LITERAL, token,
                                         line_no, col))
                continue
            if re.fullmatch(r"\d+", token):
                leaves.append(self._emit(result, C.INTEGER_LITERAL, token,
                                         line_no, col))
                continue
            if re.fullmatch(r"[A-Za-z_]\w*", token):
                leaves.append(self._emit(result, C.VARIABLE_BINDING, token,
                                         line_no, col))
                continue
            result.rejected.append(
                Rejection(token, "unclassified symbol cannot be mapped",
                          line_no, col))

        if not leaves:
            return
        children: list[StructureNode] = []
        if relation_position is not None:
            children.append(StructureNode(kind="LHS", role="LHS",
                                          leaf_indices=leaves[:relation_position]))
            children.append(StructureNode(kind="RHS", role="RHS",
                                          leaf_indices=leaves[relation_position + 1:]))
        kind = "EQUATION" if relation_position is not None else "EXPRESSION"
        result.structures.append(StructureNode(
            kind=kind, role="ROOT", label=raw_line.strip()[:48],
            leaf_indices=leaves, children=children))

    def _emit(self, result: ParseResult, concept: str, value: str,
              line: int, col: int) -> int:
        result.extractions.append(
            Extraction(concept=concept, value=value, line=line, col=col))
        return len(result.extractions) - 1
