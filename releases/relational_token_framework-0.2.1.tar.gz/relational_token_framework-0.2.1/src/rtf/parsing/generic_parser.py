"""Generic prose / arbitrary-text parser (TEXT domain).

Registered through the frozen architecture's sanctioned extension rule
("new domain = new TAG + keyword table + parser registration"). It makes
the RTF-V5 ingestion layer able to pipeline ANY text: words become
VARIABLE_BINDING proposals, numbers become integer/float literals, mapped
operators and delimiters stay structural - so every source token survives
as an ordered occurrence (content-preserving, nothing is dropped).

Per non-empty line a PARAGRAPH root structure covers the atoms in source
order with exact line/column provenance.
"""

from __future__ import annotations

import re

from ..core.model import Extraction, ParseResult, StructureNode
from ..semantics import concepts as C
from ..semantics.concepts import resolve_keyword
from .base import Parser, line_starts, position_of

_WORD = re.compile(r"[A-Za-z_][A-Za-z0-9_]*(?:'[A-Za-z0-9_]+)*")
_FLOAT = re.compile(r"\d+\.\d+")
_INT = re.compile(r"\d+")
_TOKEN = re.compile(r"[A-Za-z_][A-Za-z0-9_]*(?:'[A-Za-z0-9_]+)*|\d+\.\d+|\d+|[^\s]")


class GenericProseParser(Parser):
    language = "text"

    def parse(self, source: str) -> ParseResult:
        result = ParseResult()
        starts = line_starts(source)
        for line_match in re.finditer(r"[^\n]+", source):
            raw_line = line_match.group(0)
            if not raw_line.strip():
                continue
            leaves: list[int] = []
            for m in _TOKEN.finditer(raw_line):
                token = m.group(0)
                line_no, col = position_of(starts, line_match.start() + m.start())
                index = self._classify(result, token, line_no, col)
                if index is not None:
                    leaves.append(index)
            if leaves:
                result.structures.append(StructureNode(
                    kind="PARAGRAPH", role="ROOT",
                    label=raw_line.strip()[:48], leaf_indices=leaves))
        return result

    def _classify(self, result: ParseResult, token: str, line: int, col: int) -> int | None:
        if _FLOAT.fullmatch(token):
            return self._emit(result, C.FLOAT_LITERAL, token, line, col)
        if _INT.fullmatch(token):
            return self._emit(result, C.INTEGER_LITERAL, token, line, col)
        if _WORD.fullmatch(token):
            return self._emit(result, C.VARIABLE_BINDING, token, line, col)
        concept = resolve_keyword("math", token)
        if concept is not None:
            return self._emit(result, concept, token, line, col)
        if token.isspace():
            return None
        return self._emit(result, C.DELIMITER, token, line, col)

    @staticmethod
    def _emit(result: ParseResult, concept: str, value: str,
              line: int, col: int) -> int:
        result.extractions.append(
            Extraction(concept=concept, value=value, line=line, col=col))
        return len(result.extractions) - 1