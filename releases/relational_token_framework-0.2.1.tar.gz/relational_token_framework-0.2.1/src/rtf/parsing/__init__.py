from __future__ import annotations

from ..core.model import ParseResult
from ..semantics.concepts import DOMAIN_KEYWORD_MAPS
from .base import Parser
from .python_parser import PythonParser
from .java_parser import JavaParser
from .rust_parser import RustParser
from .math_parser import MathParser
from .sql_parser import SqlParser
from .domain_line import DomainLineParser
from .r_parser import RParser
from .generic_parser import GenericProseParser

PARSERS = {
    "python": PythonParser,
    "java": JavaParser,
    "rust": RustParser,
    "math": MathParser,
    "sql": SqlParser,
    "r": RParser,
    "text": GenericProseParser,
}

# 10-domain expansion: line-based domains sharing DomainLineParser,
# each with its own curated keyword table (no fabricated mappings)
_LINE_DOMAINS = ("physics", "chemistry", "biology", "botany", "zoology",
                 "anatomy", "medical", "english", "history")
for _language in _LINE_DOMAINS:
    PARSERS[_language] = lambda lang=_language: DomainLineParser(lang)

DOMAIN_QUALIFIERS = {
    "python": "PROGRAMMING",
    "java": "PROGRAMMING",
    "rust": "PROGRAMMING",
    "r": "PROGRAMMING",
    "sql": "QUERY",
    "math": "MATHEMATICS",
    "physics": "PHYSICS",
    "chemistry": "CHEMISTRY",
    "biology": "BIOLOGY",
    "botany": "BOTANY",
    "zoology": "ZOOLOGY",
    "anatomy": "ANATOMY",
    "medical": "MEDICAL",
    "english": "ENGLISH",
    "history": "HISTORY",
    "text": "TEXT",
}

DEFAULT_LOCAL_NAMES = {
    "python": "PYTHON",
    "java": "JAVA",
    "rust": "RUST",
    "r": "R",
    "sql": "SQL",
    "math": "CLASSICAL_NOTATION",
    "physics": "CLASSICAL_MECHANICS",
    "chemistry": "GENERAL_CHEMISTRY",
    "biology": "CELL_BIOLOGY",
    "botany": "GENERAL_BOTANY",
    "zoology": "GENERAL_ZOOLOGY",
    "anatomy": "HUMAN_ANATOMY",
    "medical": "MEDICAL_CODING",
    "english": "ENGLISH_GRAMMAR",
    "history": "GENERAL_HISTORY",
    "text": "GENERAL_TEXT",
}


def detect_domain(source: str) -> str:
    """Best-effort domain detection from source text.

    Deterministic keyword scoring; ties resolved in fixed order.
    """
    head = source[:2000]
    scores = {"python": 0, "java": 0, "rust": 0, "math": 0}
    if re_search(r"\bdef\s+\w+\s*\(", head) or re_search(r"^\s*import\s+\w+", head, True):
        scores["python"] += 3
    if re_search(r"\b(if|elif|for|while|print|range)\b", head):
        scores["python"] += 2
    if re_search(r":\s*$", head, True):
        scores["python"] += 1
    if re_search(r"\bpublic\s+(class|static)\b", head):
        scores["java"] += 4
    if re_search(r"\bSystem\.out\.print", head):
        scores["java"] += 2
    if re_search(r"\bfn\s+\w+\s*\(", head) or re_search(r"\blet\s+mut\b", head):
        scores["rust"] += 4
    if re_search(r"->\s*[iuf]\d+", head):
        scores["rust"] += 2
    if re_search(r"[\\]?(gt|leq|times|sum|int)_?", head) or re_search(r"^\s*[a-z]\s*[<>+\-=/]\s*", head, True):
        scores["math"] += 2
    # 10-domain expansion: keyword-table scoring for the line domains.
    # A domain's score = number of its curated keywords present in the
    # text (deterministic; ties resolved in fixed registration order).
    for language in _LINE_DOMAINS:
        table = DOMAIN_KEYWORD_MAPS.get(language, {})
        hits = sum(1 for keyword in table
                   if re_search(rf"\b{re_escape(keyword)}\b", head, True))
        scores[language] = hits
    if not any(scores.values()):
        # fall back: single arithmetic expression looks mathematical
        if re_search(r"^[^a-zA-Z]*$", head.strip()) or "=" in head or ">" in head:
            scores["math"] += 1
    best = max(scores.items(), key=lambda kv: (kv[1], -list(scores).index(kv[0])))
    if best[1] == 0:
        raise ValueError("cannot detect source domain; pass language explicitly")
    return best[0]


def re_search(pattern: str, text: str, multiline: bool = False) -> bool:
    import re as _re

    flags = _re.MULTILINE if multiline else 0
    return _re.search(pattern, text, flags) is not None


def re_escape(text: str) -> str:
    import re as _re

    return _re.escape(text)


def get_parser(language: str) -> Parser:
    try:
        return PARSERS[language]()
    except KeyError:
        raise ValueError(f"unsupported language {language!r}; supported: {sorted(PARSERS)}")


__all__ = ["PARSERS", "Parser", "ParseResult", "get_parser", "detect_domain",
           "DOMAIN_QUALIFIERS", "DEFAULT_LOCAL_NAMES"]
