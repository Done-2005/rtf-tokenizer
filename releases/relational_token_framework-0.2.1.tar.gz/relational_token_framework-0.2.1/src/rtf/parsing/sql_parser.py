"""SQL parser: keyword tokenizer + query-structure sketches.

Grounded grammar subset: SELECT [DISTINCT] fields FROM table
[WHERE predicate]; (case-insensitive keywords). Semantic proposals come
ONLY from the curated sql keyword table (SELECT/FROM -> QUERY_SELECT,
WHERE/HAVING -> QUERY_FILTER, operators via the shared tables);
identifiers are VARIABLE_BINDING proposals, literals are literal concepts.
Unknown tokens are rejected honestly - nothing is fabricated.
"""

from __future__ import annotations

import re

from ..core.model import Extraction, ParseResult, Rejection, StructureNode
from ..semantics import concepts as C
from ..semantics.concepts import resolve_keyword
from .base import Parser, line_starts, position_of

_TOKEN = re.compile(
    r"'(?:[^'\\\n]|\\.)*'"
    r"|\"(?:[^\"\\\n]|\\.)*\""
    r"|\d+\.\d+"
    r"|\d+"
    r"|<=|>=|<>|!=|=="
    r"|[A-Za-z_]\w*"
    r"|[<>=!+\-*/%(),.;]"
)

_CLAUSE_KEYWORDS = {"select", "from", "where", "having", "group", "order",
                    "limit", "distinct", "as", "and", "or", "not"}


class SqlParser(Parser):
    """Regex tokenizer + clause structure for the grounded SQL subset."""

    language = "sql"

    def parse(self, source: str) -> ParseResult:
        result = ParseResult()
        starts = line_starts(source)
        mask = _comment_mask(source)
        tokens = [
            (m.group(0), m.start())
            for m in _TOKEN.finditer(source)
            if not mask[m.start()]
        ]

        statement: list[tuple[str, int]] = []
        statements: list[list[tuple[str, int]]] = []
        for raw, offset in tokens:
            if raw == ";":
                if statement:
                    statements.append(statement)
                    statement = []
            else:
                statement.append((raw, offset))
        if statement:
            statements.append(statement)

        root = StructureNode(kind="PROGRAM_ELEMENT", role="ROOT",
                             label="sql-program")
        for stmt in statements:
            root.children.append(self._parse_statement(stmt, starts, result))
        result.structures.append(root)
        return result

    # -- one statement -------------------------------------------------------

    def _parse_statement(self, stmt: list[tuple[str, int]], starts,
                         result: ParseResult) -> StructureNode:
        node = StructureNode(kind=C.QUERY_SELECT, role="MEMBER",
                             label="query")
        leafs: list[int] = []
        where_leafs: list[int] | None = None
        lower_values = [raw.lower() for raw, _ in stmt]

        for index, (raw, offset) in enumerate(stmt):
            line, col = position_of(starts, offset)
            lowered = raw.lower()
            if raw.startswith("'") or raw.startswith('"'):
                inner = raw[1:-1]
                if 0 < len(inner) <= 62 and "\n" not in inner:
                    leafs.append(self._emit(result, C.STRING_LITERAL, raw,
                                            line, col))
                else:
                    result.rejected.append(
                        Rejection(raw[:40], "non-atomic string literal",
                                  line, col))
                continue
            if re.fullmatch(r"\d+\.\d+", raw):
                leafs.append(self._emit(result, C.FLOAT_LITERAL, raw, line, col))
                continue
            if re.fullmatch(r"\d+", raw):
                leafs.append(self._emit(result, C.INTEGER_LITERAL, raw, line, col))
                continue
            if re.fullmatch(r"[A-Za-z_]\w*", raw):
                concept = resolve_keyword("sql", lowered)
                if concept is None:
                    concept = C.VARIABLE_BINDING
                index_atom = self._emit(result, concept, raw, line, col)
                if lowered == "where" and where_leafs is None:
                    # close the projection leaves; start predicate clause
                    node.leaf_indices = leafs
                    where_leafs = []
                    where_leafs.append(index_atom)
                    continue
                if where_leafs is not None:
                    where_leafs.append(index_atom)
                else:
                    leafs.append(index_atom)
                continue
            concept = resolve_keyword("sql", raw)
            if concept is not None:
                atom = self._emit(result, concept, raw, line, col)
                if where_leafs is not None:
                    where_leafs.append(atom)
                else:
                    leafs.append(atom)
                continue
            result.rejected.append(
                Rejection(raw, "unclassified symbol cannot be mapped",
                          line, col))

        if where_leafs is None:
            node.leaf_indices = leafs
        else:
            node.leaf_indices = leafs
            node.children.append(StructureNode(
                kind="CONDITION", role=C.QUERY_FILTER,
                leaf_indices=where_leafs))
        return node

    @staticmethod
    def _emit(result: ParseResult, concept: str, value: str,
              line: int, col: int) -> int:
        result.extractions.append(
            Extraction(concept=concept, value=value, line=line, col=col))
        return len(result.extractions) - 1


def _comment_mask(text: str) -> list[bool]:
    mask = [False] * len(text)
    for pattern in (re.compile(r"/\*.*?\*/", re.DOTALL),
                    re.compile(r"--[^\n]*")):
        for match in pattern.finditer(text):
            for i in range(match.start(), match.end()):
                mask[i] = True
    return mask
