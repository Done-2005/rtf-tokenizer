"""Mathematics / LaTeX-line parser.

Each non-empty source line becomes an EXPRESSION or EQUATION structure.
LaTeX commands are resolved at TOKEN level against their ORIGINAL offsets,
so line/column provenance is exact - no string surgery, no shifted columns
(spec sections 20, 35).

Structure model per line (all children are REFERENCES into the same flat,
source-ordered atom stream - nothing is duplicated or reordered):
  - EQUATION root carries every atom; a top-level relation splits it into
    LHS / RHS child elements covering the atom ranges either side.
  - Outermost parenthesized spans become GROUP child elements covering their
    inner atom range.
"""

from __future__ import annotations

import re

from ..core.model import Extraction, ParseResult, Rejection, StructureNode
from ..semantics import concepts as C
from ..semantics.concepts import LATEX_ALIASES, resolve_keyword
from .base import Parser, line_starts, position_of

_LATEX_CMD = re.compile(r"\\[a-zA-Z]+")
_TOKEN = re.compile(r"\\[a-zA-Z]+|\d+\.\d+|\d+|[A-Za-z]|[^\s]")
_SKIP = {"_", ",", ".", "!", "?"}


class MathParser(Parser):
    """Per-line mathematics parser with exact provenance."""

    language = "math"

    def parse(self, source: str) -> ParseResult:
        result = ParseResult()
        starts = line_starts(source)

        for line_match in re.finditer(r"[^\n]+", source):
            raw_line = line_match.group(0)
            if not raw_line.strip():
                continue
            line_offset = line_match.start()
            tokens: list[tuple[str, int]] = []
            for m in _TOKEN.finditer(raw_line):
                token = m.group(0)
                if _LATEX_CMD.fullmatch(token):
                    mapped = LATEX_ALIASES.get(token)
                    if mapped is None:
                        line_no, col = position_of(starts, line_offset + m.start())
                        result.rejected.append(
                            Rejection(
                                token, "unsupported latex command cannot be mapped",
                                line_no, col))
                        continue
                    token = mapped
                tokens.append((token, line_offset + m.start()))
            self._parse_line(tokens, raw_line.strip()[:48], starts, result)
        return result

    # -- one line -----------------------------------------------------------

    def _parse_line(self, tokens: list[tuple[str, int]], label: str,
                    starts: list[int], result: ParseResult) -> None:
        leaves: list[int] = []            # extraction indices in source order
        group_ranges: list[tuple[int, int]] = []   # [start, end) into leaves
        relation_position: int | None = None
        depth = 0
        group_start = 0

        for token, offset in tokens:
            if token in _SKIP:
                continue
            line_no, col = position_of(starts, offset)

            if token == "(":
                index = self._emit(result, C.DELIMITER, token, line_no, col)
                depth += 1
                leaves.append(index)
                if depth == 1:
                    group_start = len(leaves)
                continue
            if token == ")":
                index = self._emit(result, C.DELIMITER, token, line_no, col)
                if depth >= 1:
                    if depth == 1:
                        group_ranges.append((group_start, len(leaves)))
                    depth -= 1
                leaves.append(index)
                continue

            concept = resolve_keyword("math", token)
            if concept is not None:
                if concept == C.RELATIONAL_OPERATOR and depth == 0 \
                        and relation_position is None:
                    relation_position = len(leaves)
                leaves.append(self._emit(result, concept, token, line_no, col))
                continue
            if re.fullmatch(r"\d+\.\d+", token):
                leaves.append(self._emit(result, C.FLOAT_LITERAL, token,
                                         line_no, col))
                continue
            if re.fullmatch(r"\d+", token):
                leaves.append(self._emit(result, C.INTEGER_LITERAL, token,
                                         line_no, col))
                continue
            if token.isalpha():
                leaves.append(self._emit(result, C.VARIABLE_BINDING, token,
                                         line_no, col))
                continue
            result.rejected.append(
                Rejection(token, "unclassified symbol cannot be mapped",
                          line_no, col))

        if not leaves:
            return

        children: list[StructureNode] = []
        for start, end in group_ranges:
            children.append(StructureNode(kind="GROUP", role="GROUP",
                                          leaf_indices=leaves[start:end]))
        if relation_position is not None:
            children.append(StructureNode(kind="LHS", role="LHS",
                                          leaf_indices=leaves[:relation_position]))
            children.append(StructureNode(kind="RHS", role="RHS",
                                          leaf_indices=leaves[relation_position + 1:]))
        kind = "EQUATION" if relation_position is not None else "EXPRESSION"
        result.structures.append(StructureNode(
            kind=kind, role="ROOT", label=label, leaf_indices=leaves,
            children=children))

    @staticmethod
    def _emit(result: ParseResult, concept: str, value: str,
              line: int, col: int) -> int:
        result.extractions.append(
            Extraction(concept=concept, value=value, line=line, col=col))
        return len(result.extractions) - 1
