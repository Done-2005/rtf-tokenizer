"""Lexical comment-region detection.

Layer 1 of the representation, and deliberately the *only* lexical fact it
contributes. Three properties matter, and each one has a failure mode that the
corpus in this repository would not otherwise catch:

1. STRING-AWARE. A `#` inside a string literal is data, not a comment start.
   `"a#b"` must not truncate. A scanner that ignores quoting would silently
   corrupt genuine string VALUES, and the corruption would look like a
   successful filter.

2. MARK, NOT DELETE. `comment_offsets` returns a set of character offsets. The
   caller still tokenizes and classifies everything; it only *labels* what came
   from a comment. Deleting comment text at the lexer would remove the very
   evidence needed to prove afterwards that the filter spared legitimate code.

3. LINE-ORIENTED for `#` languages. A comment runs to end of line. An
   unterminated string must NOT swallow the remainder of the file, so hitting a
   newline while inside a string resets to code state rather than staying in the
   string - the conservative direction, since it can only reveal more comment
   candidates for ingestion to refuse, never hide one.

There is no heuristic here, and no notion of "looks like prose". That judgement
belongs to ingestion, not to the lexer.
"""
from __future__ import annotations

# Quote characters that open a string region, and the escape character that
# lets a quote appear literally inside one. R additionally uses backticks for
# non-standard identifiers; treating them as strings is what stops
# `x <- \`weird # name\`` from being cut in half.
_HASH_QUOTES = "'\"`"


def comment_offsets(source: str, marker: str = "#",
                    quotes: str = _HASH_QUOTES) -> set[int]:
    """Character offsets of every ``marker``-initiated comment region.

    Args:
        source: full text.
        marker: the comment-initiating character (R ``#``, SQL ``--``, ...).
        quotes: characters that open a string region.

    Returns:
        The set of absolute character offsets covered by comment regions,
        including the marker itself. Empty when the language has no such marker.
    """
    out: set[int] = set()
    if not marker:
        return out
    quote = ""
    escaped = False
    i = 0
    n = len(source)
    while i < n:
        ch = source[i]
        if quote:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == quote:
                quote = ""
            elif ch == "\n":
                # Unterminated string. Do not swallow the rest of the file.
                quote = ""
            i += 1
            continue
        if ch in quotes:
            quote = ch
            i += 1
            continue
        if ch == marker:
            j = i
            while j < n and source[j] != "\n":
                out.add(j)
                j += 1
            i = j
            continue
        i += 1
    return out


def string_offsets(source: str, quotes: str = _HASH_QUOTES) -> set[int]:
    """Character offsets covered by string literals, quotes included.

    Same state machine as :func:`comment_offsets`, reported separately. This
    exists so an atom can be labelled with its lexical origin without that
    labelling implying a refusal: a string-literal atom is legitimate content
    and is already routed to its own address. The distinction matters because
    collapsing "string" into "comment" would make provenance claim something
    false - the two regions have opposite admission semantics.

    Marked as TRACKED, NOT ENFORCED. Nothing in the pipeline refuses on this
    basis; it exists so occurrence-level metrics can later distinguish
    code-origin from string-origin instead of treating both as CODE.
    """
    out: set[int] = set()
    quote = ""
    escaped = False
    i = 0
    n = len(source)
    while i < n:
        ch = source[i]
        if quote:
            out.add(i)
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == quote:
                quote = ""
            elif ch == "\n":
                quote = ""
            i += 1
            continue
        if ch in quotes:
            quote = ch
            out.add(i)
            i += 1
            continue
        i += 1
    return out


def code_offsets(source: str, marker: str = "#",
                 quotes: str = _HASH_QUOTES) -> set[int]:
    """Complement of :func:`comment_offsets` over the whole text."""
    return set(range(len(source))) - comment_offsets(source, marker, quotes)


def is_comment_line(source: str, line: int, marker: str = "#",
                    quotes: str = _HASH_QUOTES) -> bool:
    """Whether any part of 1-based ``line`` lies in a comment region.

    Provided for reporting and tests ONLY. Admitting or refusing an atom must
    never be keyed on this: an atom anywhere on a line that also carries an
    inline comment is still perfectly good code. Keying on the line is exactly
    the false-rejection rule the Layer-1 contract forbids.
    """
    starts = source.splitlines(keepends=True)
    if not 1 <= line <= len(starts):
        return False
    base = sum(len(s) for s in starts[: line - 1])
    body = starts[line - 1]
    offs = comment_offsets(source, marker, quotes)
    return any((base + k) in offs for k in range(len(body)))


def code_segment(line: str, marker: str = "#", quotes: str = _HASH_QUOTES) -> str:
    """The part of a single line that lies outside any comment region.

    Single-line form of the same test, used for the inline-comment risk analysis
    and its regression tests.
    """
    offs = comment_offsets(line, marker, quotes)
    return "".join(ch for k, ch in enumerate(line) if k not in offs)
