from __future__ import annotations

import ast
import re
import warnings

from ..core.model import Extraction, ParseResult, Rejection, StructureNode
from ..semantics import concepts as C
from .base import Parser


_CMP = {ast.Gt: ">", ast.Lt: "<", ast.GtE: ">=", ast.LtE: "<=", ast.Eq: "==", ast.NotEq: "!="}
_BIN = {
    ast.Add: "+", ast.Sub: "-", ast.Mult: "*", ast.Div: "/",
    ast.FloorDiv: "//", ast.Mod: "%", ast.Pow: "**",
}

_FRAGMENT_KEYWORDS = {
    "if": C.CONDITIONAL_LOGIC,
    "elif": C.CONDITIONAL_LOGIC,
    "while": C.LOOP_CONSTRUCT,
    "for": C.LOOP_CONSTRUCT,
}


class PythonParser(Parser):
    """AST-based Python parser.

    Emits atomic extractions in source order via a recursive visitor
    (ast.walk's BFS order does not match the source), records AST line/col
    provenance for every atom, and produces nested structure sketches for
    conditionals, loops, function definitions, assignments, calls.

    Tolerant recovery: when the source is an incomplete statement such as
    `if x > 10` (no suite), the leading structural keyword is split off and
    the remaining expression is parsed in eval mode. All atoms are real
    source tokens with real AST positions - nothing is fabricated.
    """

    language = "python"

    def parse(self, source: str) -> ParseResult:
        result = ParseResult()
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", SyntaxWarning)
                tree = ast.parse(source)
        except SyntaxError:
            recovered = self._recover_fragment(source)
            if recovered is not None:
                return recovered
            result.rejected.append(
                Rejection("<module>", f"python syntax error; fragment recovery failed"))
            return result

        state = _State(result)
        for stmt in tree.body:
            node = state.statement(stmt, role="ROOT")
            if node is not None:
                state.root_nodes.append(node)
            state.root_nodes.extend(state.take_structures())
        result.structures.extend(state.root_nodes)
        return result

    # -- tolerant fragment recovery -------------------------------------

    @staticmethod
    def _recover_fragment(source: str) -> ParseResult | None:
        match = re.match(r"\s*(\w+)\b(.*)$", source, re.DOTALL)
        if match is None:
            return None
        lead, remainder = match.group(1), match.group(2)
        concept = _FRAGMENT_KEYWORDS.get(lead)
        if concept is None:
            return None
        expr_text = remainder.strip()
        while expr_text.endswith(":"):
            expr_text = expr_text[:-1].rstrip()
        if not expr_text:
            return None
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", SyntaxWarning)
                tree = ast.parse(expr_text, mode="eval")
        except SyntaxError:
            return None

        result = ParseResult()
        state = _State(result)
        # eval-mode positions are relative to the recovered expression text;
        # re-anchor them onto the original source.
        anchor = source.find(expr_text)

        def emit(concept_name: str, value: str, node: ast.AST | None) -> int:
            line = getattr(node, "lineno", None)
            col = (getattr(node, "col_offset", 0) + anchor + 1) if line is not None else None
            result.extractions.append(
                Extraction(concept=concept_name, value=value, line=line, col=col))
            return len(result.extractions) - 1

        lead_start = match.start(1)
        lead_line = source.count("\n", 0, lead_start) + 1
        lead_col = lead_start - (source.rfind("\n", 0, lead_start) + 1) + 1
        result.extractions.append(
            Extraction(concept=concept, value=lead, line=lead_line, col=lead_col))
        lead_index = len(result.extractions) - 1
        before_calls = len(state._collected)
        body_indices = state.expression(tree.body)
        calls = state._collected[before_calls:]
        del state._collected[before_calls:]

        if concept == C.LOOP_CONSTRUCT and lead == "for":
            iterator = StructureNode(kind="ITERATOR", role="ITERATOR",
                                     leaf_indices=body_indices[:1])
            iterable = StructureNode(kind="ITERABLE", role="ITERABLE",
                                     leaf_indices=body_indices[1:])
            root = StructureNode(kind="LOOP_STRUCTURE", role="ROOT", label=f"{lead}-fragment",
                                 leaf_indices=[lead_index],
                                 children=[iterator, iterable])
        else:
            condition = StructureNode(kind="CONDITION", role="CONDITION",
                                      leaf_indices=body_indices)
            root = StructureNode(kind="CONDITIONAL_EXPRESSION" if concept == C.CONDITIONAL_LOGIC
                                 else "LOOP_STRUCTURE",
                                 role="ROOT", label=f"{lead}-fragment",
                                 leaf_indices=[lead_index], children=[condition])
        for call_node in calls:
            root.children.append(call_node)
        result.structures.append(root)
        return result


class _State:
    def __init__(self, result: ParseResult) -> None:
        self.result = result
        self.root_nodes: list[StructureNode] = []
        self._collected: list[StructureNode] = []

    def take_structures(self) -> list[StructureNode]:
        taken = self._collected
        self._collected = []
        return taken

    # -- atoms ---------------------------------------------------------------

    def _emit(self, concept: str, value: str, node: ast.AST | None) -> int:
        line = getattr(node, "lineno", None)
        col = (getattr(node, "col_offset", 0) + 1) if line is not None else None
        self.result.extractions.append(Extraction(concept=concept, value=value, line=line, col=col))
        return len(self.result.extractions) - 1

    def expression(self, node: ast.AST | None) -> list[int]:
        """Emit atomic leaves of an expression subtree in source order."""
        if node is None:
            return []
        if isinstance(node, ast.Constant):
            constant = node.value
            if isinstance(constant, bool):
                return [self._emit(C.BOOLEAN_LITERAL, "true" if constant else "false", node)]
            if isinstance(constant, int):
                return [self._emit(C.INTEGER_LITERAL, str(constant), node)]
            if isinstance(constant, float):
                return [self._emit(C.FLOAT_LITERAL, repr(constant), node)]
            if isinstance(constant, str):
                inner = constant
                if 0 < len(inner) <= 62 and "\n" not in inner:
                    return [self._emit(C.STRING_LITERAL, f'"{inner}"', node)]
                self.result.rejected.append(
                    Rejection(inner[:40], "non-atomic string literal",
                              getattr(node, "lineno", None), getattr(node, "col_offset", None)))
                return []
            return []
        if isinstance(node, ast.Name):
            return [self._emit(C.VARIABLE_BINDING, node.id, node)]
        if isinstance(node, ast.Compare):
            out = self.expression(node.left)
            for op in node.ops:
                if isinstance(op, ast.In):
                    out.append(self._emit(C.RANGE_EXPRESSION, "in", node))
                    continue
                symbol = _CMP.get(type(op))
                if symbol:
                    out.append(self._emit(C.RELATIONAL_OPERATOR, symbol, node))
            for comparator in node.comparators:
                out.extend(self.expression(comparator))
            return out
        if isinstance(node, ast.BinOp):
            symbol = _BIN.get(type(node.op))
            left = self.expression(node.left)
            middle = [self._emit(C.ARITHMETIC_OPERATOR, symbol, node)] if symbol else []
            right = self.expression(node.right)
            return left + middle + right
        if isinstance(node, ast.BoolOp):
            keyword = "and" if isinstance(node.op, ast.And) else "or"
            flat: list[int] = []
            for position, value_node in enumerate(node.values):
                flat.extend(self.expression(value_node))
                if position < len(node.values) - 1:
                    flat.append(self._emit(C.BOOLEAN_OPERATOR, keyword, node))
            return flat
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not):
            index = self._emit(C.BOOLEAN_OPERATOR, "not", node)
            return [index] + self.expression(node.operand)
        if isinstance(node, ast.Call):
            func_indices = self.expression(node.func)
            open_index = self._emit(C.DELIMITER, "(", node)
            arg_indices: list[int] = []
            for argument in node.args:
                arg_indices.extend(self.expression(argument))
            close_index = self._emit(C.DELIMITER, ")", node)
            leaf_order = func_indices + [open_index] + arg_indices + [close_index]
            call_node = StructureNode(kind=C.FUNCTION_CALL, label="invocation",
                                      role="CALL", leaf_indices=leaf_order)
            self._collected.append(call_node)
            return leaf_order
        if isinstance(node, ast.Attribute):
            return self.expression(node.value)
        if isinstance(node, ast.JoinedStr):
            self.result.rejected.append(
                Rejection("<f-string>", "compound formatted string not atomizable",
                          getattr(node, "lineno", None), getattr(node, "col_offset", None)))
            return []
        # Unknown expression type: record honestly, fabricate nothing.
        self.result.rejected.append(
            Rejection(type(node).__name__, "unsupported expression node",
                      getattr(node, "lineno", None), getattr(node, "col_offset", None)))
        return []

    # -- statements ------------------------------------------------------------

    def block(self, statements: list[ast.stmt], kind: str = "BLOCK") -> StructureNode:
        node = StructureNode(kind=kind)
        for child in statements:
            visited = self.statement(child)
            if visited is not None:
                node.children.append(visited)
        return node

    def statement(self, stmt: ast.AST, role: str = "ROOT") -> StructureNode | None:
        if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef)):
            node = StructureNode(kind=C.FUNCTION_DECLARATION, role=role, label=stmt.name)
            kw_index = self._emit(C.FUNCTION_DECLARATION, "def", stmt)
            name_index = self._emit(C.VARIABLE_BINDING, stmt.name, stmt)
            parameter_indices: list[int] = []
            for argument in stmt.args.args:
                if argument.annotation is not None:
                    parameter_indices.extend(self.expression(argument.annotation))
                parameter_indices.append(self._emit(C.VARIABLE_BINDING, argument.arg, argument))
            returns_index = self._emit(C.TYPE_ANNOTATION, "->", stmt) if stmt.returns else None
            return_indices = self.expression(stmt.returns)
            body = self.block(stmt.body)
            node.leaf_indices = ([kw_index, name_index] + parameter_indices
                                 + ([returns_index] if returns_index is not None else [])
                                 + return_indices)
            node.children = [body] if body.children else []
            return node

        if isinstance(stmt, ast.ClassDef):
            node = StructureNode(kind=C.CLASS_DECLARATION, role=role, label=stmt.name)
            name_index = self._emit(C.CLASS_DECLARATION, stmt.name, stmt)
            bases: list[int] = []
            for base in stmt.bases:
                bases.extend(self.expression(base))
            node.leaf_indices = [name_index] + bases
            node.children = [b for b in (self.statement(s, role="MEMBER") for s in stmt.body) if b]
            return node

        if isinstance(stmt, ast.Return):
            value_indices = self.expression(stmt.value)
            keyword_index = self._emit(C.RETURN_STATEMENT, "return", stmt)
            node = StructureNode(kind=C.RETURN_STATEMENT, role=role,
                                 leaf_indices=[keyword_index] + value_indices)
            return node

        if isinstance(stmt, ast.If):
            keyword_index = self._emit(C.CONDITIONAL_LOGIC, "if", stmt)
            condition_node = StructureNode(kind="CONDITION", role="CONDITION",
                                           leaf_indices=self.expression(stmt.test))
            then_node = self.block(stmt.body, kind="THEN_BRANCH")
            then_node.role = "THEN_BRANCH"
            children: list[StructureNode] = [condition_node, then_node]
            else_leafs: list[int] = []
            else_children: list[StructureNode] = []
            for child in stmt.orelse:
                if isinstance(child, ast.If):
                    nested = self.statement(child, role="ELSE_BRANCH")
                    if nested is not None:
                        else_children.append(nested)
                else:
                    before = len(self.result.extractions)
                    visited = self.statement(child, role="ELSE_BRANCH")
                    after = len(self.result.extractions)
                    else_leafs.extend(range(before, after))
                    if visited is not None:
                        else_children.append(visited)
            if else_leafs or else_children:
                else_keyword = self._emit(C.ELSE_BRANCH, "else", stmt)
                else_node = StructureNode(kind=C.ELSE_BRANCH, role="ELSE_BRANCH",
                                          leaf_indices=[else_keyword] + else_leafs,
                                          children=[c for c in else_children])
                children.append(else_node)
            node = StructureNode(kind="CONDITIONAL_EXPRESSION", role=role,
                                 leaf_indices=[keyword_index], children=children)
            return node

        if isinstance(stmt, (ast.For, ast.AsyncFor)):
            keyword_index = self._emit(C.LOOP_CONSTRUCT, "for", stmt)
            iterator_node = StructureNode(kind="ITERATOR", role="ITERATOR",
                                          leaf_indices=self.expression(stmt.target))
            in_index = self._emit(C.RANGE_EXPRESSION, "in", stmt)
            iterable_node = StructureNode(
                kind="ITERABLE", role="ITERABLE",
                leaf_indices=[in_index] + self.expression(stmt.iter))
            body_node = self.block(stmt.body)
            body_node.role = "BODY"
            node = StructureNode(kind="LOOP_STRUCTURE", role=role, label="for-loop",
                                 leaf_indices=[keyword_index],
                                 children=[iterator_node, iterable_node, body_node])
            return node

        if isinstance(stmt, ast.While):
            keyword_index = self._emit(C.LOOP_CONSTRUCT, "while", stmt)
            condition_node = StructureNode(kind="CONDITION", role="CONDITION",
                                           leaf_indices=self.expression(stmt.test))
            body_node = self.block(stmt.body)
            body_node.role = "BODY"
            node = StructureNode(kind="LOOP_STRUCTURE", role=role, label="while-loop",
                                 leaf_indices=[keyword_index],
                                 children=[condition_node, body_node])
            return node

        if isinstance(stmt, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
            targets = stmt.targets if isinstance(stmt, ast.Assign) else [stmt.target]
            target_indices: list[int] = []
            for target in targets:
                target_indices.extend(self.expression(target))
            eq_index = self._emit(C.ASSIGNMENT_STATEMENT, "=", stmt)
            value_indices = self.expression(stmt.value)
            node = StructureNode(kind=C.ASSIGNMENT_STATEMENT, role=role,
                                 leaf_indices=target_indices + [eq_index] + value_indices)
            return node

        if isinstance(stmt, (ast.Import, ast.ImportFrom)):
            indices: list[int] = []
            if isinstance(stmt, ast.Import):
                for alias in stmt.names:
                    indices.append(self._emit(C.MODULE_IMPORT, alias.name.split(".")[0], stmt))
            elif stmt.module:
                indices.append(self._emit(C.MODULE_IMPORT, stmt.module.split(".")[0], stmt))
            return StructureNode(kind=C.MODULE_IMPORT, role=role, leaf_indices=indices)

        if isinstance(stmt, ast.Expr):
            before_calls = len(self._collected)
            indices = self.expression(stmt.value)
            calls = self._collected[before_calls:]
            del self._collected[before_calls:]
            node = StructureNode(kind="EXPRESSION_STATEMENT", role=role,
                                 leaf_indices=indices, children=calls)
            return node

        # Fallback: emit child expressions without inventing semantics.
        before = len(self.result.extractions)
        for child in ast.iter_child_nodes(stmt):
            if isinstance(child, ast.expr):
                self.expression(child)
        return StructureNode(kind="STATEMENT", role=role,
                             leaf_indices=list(range(before, len(self.result.extractions))))
