"""R language parser: reuses the JavaParser brace-aware structure
builder and tokenizer; classification resolves through the curated `r`
keyword table.

Known honest limitation: R's `<-` assignment operator is recognized as an
operator token and not represented as an assignment STRUCTURE edge. The assigned
VALUE still lands correctly. Documented, not fabricated.

Lexical grammar (Layer 1 follow-on)
-----------------------------------
R's identifier syntax differs from Java's in three ways that matter, and the
Java lexer silently mis-tokenizes all three:

1. DOTTED NAMES ARE SINGLE IDENTIFIERS. `d.call` is one name. The Java lexer
   matched `[A-Za-z_$]\\w*`, which excludes `.`, so it produced the three tokens
   `d`, `.`, `call` and registered `d` and `call` as separate VARIABLE_BINDING
   values. That invented a value named `call` corresponding to nothing in the
   program, and it split one real variable into two fake ones. The residual audit
   found nine such never-standalone fragments plus the `.` delimiter itself.

2. INTEGER LITERALS CARRY AN `L` SUFFIX. `1L` is one integer literal. The Java
   lexer matched `\\d+` and then `L` as an identifier, registering `L` as a
   VARIABLE_BINDING 19 times. It is a numeric suffix and denotes nothing.

3. A LEADING DOT IS LEGAL but a lone `.` is not a name. `.5` is a float,
   `..1` is a name, `.` is the missing-argument operator. So an identifier
   alternative may only begin with `.` when a name character follows.

These are lexical facts, so they are fixed in the lexer. The parser still only
LABELS provenance; nothing here refuses anything.
"""

from __future__ import annotations

import re

from ..core.model import Rejection
from ..semantics import concepts as C
from ..semantics.concepts import resolve_keyword
from .java_parser import JavaParser

_TYPE_WORDS_R = {"numeric", "character", "logical", "list", "matrix",
                 "factor", "integer", "double", "NULL"}
_CLASS_KEYWORDS_R = {"library", "setClass"}

# R's lexical grammar. Order is significant: earlier alternatives win, so
# multi-character operators precede their single-character prefixes and
# `...`/`..1` precede every other dot rule.
_R_TOKEN = re.compile(
    # literals
    r'"(?:[^"\\\n]|\\.)*"'
    r"|'(?:[^'\\\n]|\\.)*'"
    r"|`(?:[^`\\]|\\.)*`"
    # dot-led names, ahead of the numeric rules so `..1` is not read as `.` `.1`
    r"|\.\.\.[A-Za-z0-9._]*"
    r"|\.\.[A-Za-z0-9_]"
    # bare dot runs (`..`), after the named dot forms so `..1` is not read as `..`
    r"|\.\.+"
    # numbers: exponent forms, hex, and the `L` integer suffix. The bare
    # exponent form precedes the integer form so `1e5` is one number, not `1`
    # followed by an identifier `e5`.
    r"|\d+\.\d*(?:[eE][+-]?\d+)?"
    r"|\.\d+(?:[eE][+-]?\d+)?"
    r"|\d+[eE][+-]?\d+"
    r"|0[xX][0-9a-fA-F]+"
    r"|\d+[lL]?"
    # operators, longest first
    r"|<<-|->>|->|<-|%%|\|>|<<|>>|<=|>=|==|!=|&&|\|\||\*\*|\+=|-=|\*=|/="
    r"|%[^%\s]*%"
    # identifiers, including dotted names. A leading `.` requires a name
    # character after it, so a lone `.` falls through to punctuation.
    r"|[A-Za-z_][A-Za-z0-9._]*"
    r"|\.[A-Za-z0-9_][A-Za-z0-9._]*"
    # single-character punctuation
    r"|[<>=!&|+\-*/^.\[\](){};,:?@~$]"
)

# A legal R name, which may contain interior dots: `d.call`, `all.same`,
# `x.y.z`. Deliberately excludes pure dot strings and dot-led numbers.
_R_NAME = re.compile(
    # A name starts with a letter, dot or underscore, must contain at least one
    # alphanumeric/underscore (so `.` and `...` are not names), and must not
    # begin `.` followed by a digit (that is a float, e.g. `.5`).
    r"(?!\.\d)(?=[A-Za-z0-9._]*[A-Za-z0-9_])[A-Za-z._][A-Za-z0-9._]*"
)
# R numeric literals, including the `L` suffix and exponent/hex forms.
_R_NUMBER = re.compile(
    r"0[xX][0-9a-fA-F]+"
    r"|\d+\.\d*(?:[eE][+-]?\d+)?"
    r"|\.\d+(?:[eE][+-]?\d+)?"
    r"|\d+[eE][+-]?\d+"
    r"|\d+[lL]?"
)


class RParser(JavaParser):
    """R: two-phase brace-aware parser over the curated `r` table."""

    language = "r"
    token_pattern = _R_TOKEN

    # Layer 1. R comments are `#` to end of line. Before this was declared,
    # comment text was read as ordinary tokens and classified as program
    # structure: the licence header produced `Copyright (C)`, and the
    # "identifier followed by (" rule turned it into a FUNCTION_CALL. That was
    # a missing lexical fact, not a filtering bug.
    comment_marker = "#"
    comment_quotes = "'\"`"

    def _classify(self, result, token: str, line: int, col: int,
                  previous: str, tokens, offset: int) -> int | None:
        if token[:1] in ('"', "'", "`"):
            inner = token[1:-1]
            if 0 < len(inner) <= 62 and "\n" not in inner:
                return self._emit(result, C.STRING_LITERAL, token, line, col)
            result.rejected.append(
                Rejection(token[:40], "non-atomic string literal", line, col))
            return None
        if token in "(){};":
            if token in "()":
                return self._emit(result, C.DELIMITER, token, line, col)
            return None
        if token and set(token) == {"."}:
            # `.`, `..`, `...` are pure dot syntax: the missing-argument
            # operator and the dots parameter/forwarding marker. Punctuation,
            # never a binding. Registering them as a VARIABLE_BINDING put pure
            # delimiter syntax into the value space. They are still recorded,
            # as DELIMITER, so nothing is silently dropped.
            return self._emit(result, C.DELIMITER, token, line, col)
        if _R_NUMBER.fullmatch(token):
            if re.fullmatch(r"0[xX][0-9a-fA-F]+", token):
                return self._emit(result, C.INTEGER_LITERAL, token, line, col)
            if "." in token or "e" in token or "E" in token:
                return self._emit(result, C.FLOAT_LITERAL, token, line, col)
            return self._emit(result, C.INTEGER_LITERAL, token, line, col)
        if _R_NAME.fullmatch(token):
            concept = resolve_keyword(self.language, token)
            if concept is not None:
                return self._emit(result, concept, token, line, col)
            if token in _TYPE_WORDS_R:
                return self._emit(result, C.TYPE_ANNOTATION, token, line, col)
            nxt = self._next_token(tokens, offset)
            if nxt == "(" and previous not in {"if", "for", "while", "function"}:
                return self._emit(result, C.FUNCTION_CALL, token, line, col)
            if previous == "function":
                return self._emit(result, C.FUNCTION_DECLARATION, token,
                                  line, col)
            return self._emit(result, C.VARIABLE_BINDING, token, line, col)
        concept = resolve_keyword(self.language, token)
        if concept is not None:
            return self._emit(result, concept, token, line, col)
        result.rejected.append(
            Rejection(token, "unclassified symbol cannot be mapped",
                      line, col))
        return None

    @staticmethod
    def _next_token(tokens, after_offset: int) -> str:
        for raw, start in tokens:
            if start > after_offset:
                return raw
        return ""
