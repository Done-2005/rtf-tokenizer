"""Rust parser: brace-aware recursive structure trees.

Same two-phase design as the Java parser (spec sections 8-13):
  Phase A - tokenize ORIGINAL text (comment/generic-span/lifetime masks keep
            provenance exact) and classify tokens into atomic Extractions.
  Phase B - brace-matched recursive tree build: FUNCTION_DECLARATION (+BODY),
            CLASS_DECLARATION (struct/enum/trait/impl), CONDITIONAL_EXPRESSION
            (CONDITION/THEN_BRANCH/ELSE_BRANCH), LOOP_STRUCTURE,
            ASSIGNMENT_STATEMENT (let), RETURN_STATEMENT, MATCH_STRUCTURE,
            MACRO_INVOCATION, STATEMENT.

Type positions (`x: i32`, `-> i32`) are proposed as TYPE_ANNOTATION; masked
generic spans are skipped rather than misread as comparison operators.
"""

from __future__ import annotations

import re

from ..core.model import Extraction, ParseResult, Rejection, StructureNode
from ..semantics import concepts as C
from ..semantics.concepts import resolve_keyword
from .base import Parser, line_starts, position_of

_TOKEN = re.compile(
    r'"(?:[^"\\\n]|\\.)*"'
    r"|\d+\.\d+"
    r"|\d+"
    r"|<<=|>>=|<<|>>"
    r"|<=|>=|==|!=|&&|\|\||\+=|-=|\*=|/=|%=|&="
    r"|\.\.=|\.\.|->|=>|::"
    r"|[A-Za-z_]\w*!"
    r"|[A-Za-z_]\w*"
    r"|[<>=!&|+\-*/%^.\[\](){};,:?'@#]"
)
_SKIP_RAW = {"[", "]", ",", ".", ":", "?", "@", "#", "'", "&", "|",
             "->", "=>", "::"}
_SUPPRESS_BEFORE_CALL = {"return", "if", "while", "match", "let", "in",
                         "=", "."}
_PRIMITIVE_TYPES = {
    "i8", "i16", "i32", "i64", "i128", "isize",
    "u8", "u16", "u32", "u64", "u128", "usize",
    "f32", "f64", "bool", "char", "str", "String", "Vec", "Option", "Result",
}
_CLASS_KEYWORDS = {"struct", "enum", "trait", "impl"}

# Generic/turbofish spans: Identifier<...> or ::<'..> before call/reference
# boundaries. Masked so type parameters never masquerade as operators.
_GENERIC_SPAN = re.compile(
    r"(?:\b[A-Za-z_]\w*)?\s*::?\s*<(?:[^<>]|<[^<>]{0,60}>){0,60}>"
    r"(?=\s*(?:\(|\)|::|;|\{|,\s*\w+\s*:))"
)
_LIFETIME = re.compile(r"'[a-z][a-z0-9_]*\b")


class _Tok:
    __slots__ = ("value", "line", "col", "atom")

    def __init__(self, value: str, line: int, col: int, atom: int | None) -> None:
        self.value = value
        self.line = line
        self.col = col
        self.atom = atom

    def cls_is_atom(self) -> bool:
        return self.atom is not None


class RustParser(Parser):
    """Regex tokenizer + brace-aware structure builder for Rust."""

    language = "rust"

    def parse(self, source: str) -> ParseResult:
        result = ParseResult()
        mask = _mask(source)
        starts = line_starts(source)
        tokens = [
            (m.group(0), m.start())
            for m in _TOKEN.finditer(source)
            if not mask[m.start()] and not _LIFETIME.fullmatch(m.group(0))
        ]

        stream: list[_Tok] = []
        previous = ""
        raw_values = [raw for raw, _ in tokens]
        for index, (raw, offset) in enumerate(tokens):
            line, col = position_of(starts, offset)
            nxt = raw_values[index + 1] if index + 1 < len(raw_values) else ""
            atom = self._classify(result, raw, line, col, previous, nxt)
            if atom is not None or raw in "(){};":
                stream.append(_Tok(raw, line, col, atom))
            previous = raw.rstrip("!") if raw.endswith("!") else raw

        builder = _StructureBuilder(stream)
        root = StructureNode(kind="PROGRAM_ELEMENT", role="ROOT", label="rust-program")
        root.children = builder.statements_until(in_braces=False)
        result.structures.append(root)
        return result

    # -- phase A ------------------------------------------------------------

    def _classify(self, result: ParseResult, token: str, line: int, col: int,
                  previous: str, nxt: str) -> int | None:
        if token.startswith('"'):
            inner = token[1:-1]
            if 0 < len(inner) <= 62 and "\n" not in inner:
                return self._emit(result, C.STRING_LITERAL, token, line, col)
            result.rejected.append(
                Rejection(token[:40], "non-atomic string literal", line, col))
            return None
        if token in "(){};":
            if token in "()":
                return self._emit(result, C.DELIMITER, token, line, col)
            return None
        if token.endswith("!") and len(token) > 1 and token[:-1].isidentifier():
            return self._emit(result, C.MACRO_INVOCATION, token, line, col)
        if re.fullmatch(r"\d+\.\d+", token):
            return self._emit(result, C.FLOAT_LITERAL, token, line, col)
        if re.fullmatch(r"\d+", token):
            return self._emit(result, C.INTEGER_LITERAL, token, line, col)
        if re.fullmatch(r"[A-Za-z_]\w*", token):
            concept = resolve_keyword("rust", token)
            if concept is not None:
                return self._emit(result, concept, token, line, col)
            if token in _PRIMITIVE_TYPES:
                return self._emit(result, C.TYPE_ANNOTATION, token, line, col)
            if previous in {":", "->"}:
                return self._emit(result, C.TYPE_ANNOTATION, token, line, col)
            if previous == "fn":
                return self._emit(result, C.FUNCTION_DECLARATION, token, line, col)
            if nxt == "(" and previous not in _SUPPRESS_BEFORE_CALL:
                return self._emit(result, C.FUNCTION_CALL, token, line, col)
            if previous in _CLASS_KEYWORDS:
                return self._emit(result, C.CLASS_DECLARATION, token, line, col)
            return self._emit(result, C.VARIABLE_BINDING, token, line, col)
        concept = resolve_keyword("rust", token)
        if concept is not None:
            return self._emit(result, concept, token, line, col)
        result.rejected.append(
            Rejection(token, "unclassified symbol cannot be mapped", line, col))
        return None

    @staticmethod
    def _emit(result: ParseResult, concept: str, value: str,
              line: int, col: int) -> int:
        result.extractions.append(
            Extraction(concept=concept, value=value, line=line, col=col))
        return len(result.extractions) - 1


class _StructureBuilder:
    """Phase B: brace-aware statement/block tree over classified tokens."""

    def __init__(self, tokens: list[_Tok]) -> None:
        self.tokens = tokens
        self.i = 0

    def peek(self, ahead: int = 0) -> _Tok | None:
        j = self.i + ahead
        return self.tokens[j] if j < len(self.tokens) else None

    def take(self) -> _Tok | None:
        tok = self.peek()
        if tok is not None:
            self.i += 1
        return tok

    # -- grammar ---------------------------------------------------------------

    def statements_until(self, in_braces: bool) -> list[StructureNode]:
        nodes: list[StructureNode] = []
        while True:
            tok = self.peek()
            if tok is None:
                return nodes
            if in_braces and tok.value == "}":
                self.take()
                return nodes
            nodes.extend(self.statement())

    def statement(self) -> list[StructureNode]:
        tok = self.peek()
        if tok is None:
            return []
        if tok.value == "{":
            self.take()
            children = self.statements_until(in_braces=True)
            return [StructureNode(kind="BLOCK", role="MEMBER", children=children)]
        if tok.value == "}":
            self.take()
            return []
        keyword = tok.value.rstrip("!") if tok.value.endswith("!") else tok.value
        if keyword == "if":
            return [self.if_node()]
        if keyword in {"loop", "while", "for"}:
            return [self.loop_node(keyword)]
        if keyword == "fn":
            return [self.function_node()]
        if keyword in _CLASS_KEYWORDS:
            return [self.class_node(keyword)]
        if keyword == "let":
            return [self.simple_statement("ASSIGNMENT_STATEMENT")]
        if keyword == "return":
            return [self.simple_statement(C.RETURN_STATEMENT)]
        if keyword == "match":
            return [self.match_node()]
        fn = self.function_decl_node()
        if fn is not None:
            return [fn]
        return [self.simple_statement("STATEMENT")]

    # -- constructs ---------------------------------------------------------------

    def if_node(self) -> StructureNode:
        keyword = self.take()
        children: list[StructureNode] = []
        nxt = self.peek()
        if nxt is not None and nxt.value == "(":
            children.append(StructureNode(kind="CONDITION", role="CONDITION",
                                          leaf_indices=self.paren_atoms()))
        else:
            condition_leafs: list[int] = []
            while True:
                tok = self.peek()
                if tok is None or tok.value == "{":
                    break
                taken = self.take()
                if taken.atom is not None:
                    condition_leafs.append(taken.atom)
            children.append(StructureNode(kind="CONDITION", role="CONDITION",
                                          leaf_indices=condition_leafs))
        children.append(StructureNode(kind="THEN_BRANCH", role="THEN_BRANCH",
                                      children=self.branch_children()))
        else_leafs: list[int] = []
        else_children: list[StructureNode] = []
        nxt = self.peek()
        if nxt is not None and nxt.value == "else":
            else_leafs.append(self.take().atom)
            after = self.peek()
            if after is not None and after.value == "if":
                else_children.append(self.if_node())
            else:
                else_children.extend(self.branch_children())
        children.append(StructureNode(kind=C.ELSE_BRANCH, role="ELSE_BRANCH",
                                      leaf_indices=else_leafs,
                                      children=else_children))
        return StructureNode(kind="CONDITIONAL_EXPRESSION", role="ROOT",
                             label="if", leaf_indices=[keyword.atom],
                             children=children)

    def loop_node(self, keyword_value: str) -> StructureNode:
        keyword = self.take()
        children: list[StructureNode] = []
        header_leafs: list[int] = []
        while True:
            tok = self.peek()
            if tok is None or tok.value == "{":
                break
            taken = self.take()
            if taken.atom is not None:
                header_leafs.append(taken.atom)
        role = "HEADER" if keyword_value in {"loop"} else "CONDITION"
        children.append(StructureNode(kind="HEADER" if keyword_value == "loop"
                                      else "CONDITION", role=role,
                                      leaf_indices=header_leafs))
        children.append(StructureNode(kind="BLOCK", role="BODY",
                                      children=self.branch_children()))
        return StructureNode(kind="LOOP_STRUCTURE", role="ROOT",
                             label=keyword_value, leaf_indices=[keyword.atom],
                             children=children)

    def function_node(self) -> StructureNode:
        """`fn` keyword already classified; gather signature atoms to '{'."""
        keyword = self.take()
        leafs = [keyword.atom]
        while True:
            tok = self.peek()
            if tok is None or tok.value == "{":
                break
            taken = self.take()
            if taken.atom is not None:
                leafs.append(taken.atom)
        body = self.branch_children()
        return StructureNode(kind=C.FUNCTION_DECLARATION, role="MEMBER",
                             label="fn", leaf_indices=leafs,
                             children=[StructureNode(kind="BLOCK", role="BODY",
                                                     children=body)])

    def class_node(self, keyword_value: str) -> StructureNode:
        keyword = self.take()
        leafs = [keyword.atom]
        while True:
            tok = self.peek()
            if tok is None or tok.value == "{":
                break
            taken = self.take()
            if taken.atom is not None:
                leafs.append(taken.atom)
        children = []
        nxt = self.peek()
        if nxt is not None and nxt.value == "{":
            children = [StructureNode(kind="BLOCK", role="BODY",
                                      children=self.branch_children())]
        return StructureNode(kind=C.CLASS_DECLARATION, role="ROOT",
                             label=keyword_value, leaf_indices=leafs,
                             children=children)

    def match_node(self) -> StructureNode:
        keyword = self.take()
        scrutinee_leafs: list[int] = []
        while True:
            tok = self.peek()
            if tok is None or tok.value == "{":
                break
            taken = self.take()
            if taken.atom is not None:
                scrutinee_leafs.append(taken.atom)
        arms = self.branch_children()
        return StructureNode(kind="MATCH_STRUCTURE", role="ROOT", label="match",
                             leaf_indices=[keyword.atom],
                             children=[StructureNode(kind="CONDITION",
                                                     role="SCRUTINEE",
                                                     leaf_indices=scrutinee_leafs),
                                       StructureNode(kind="BLOCK", role="ARMS",
                                                     children=arms)])

    def function_decl_node(self) -> StructureNode | None:
        """Fallback lookahead for bare `name(params) {` free functions."""
        start = self.i
        tok = self.tokens[start]
        nxt = self.tokens[start + 1].value if start + 1 < len(self.tokens) else ""
        if nxt != "(" or not tok.cls_is_atom():
            return None
        depth = 0
        k = start + 1
        while k < len(self.tokens):
            value = self.tokens[k].value
            if value == "(":
                depth += 1
            elif value == ")":
                depth -= 1
                if depth == 0:
                    break
            k += 1
        if k >= len(self.tokens):
            return None
        k += 1
        if k >= len(self.tokens) or self.tokens[k].value != "{":
            return None
        leafs = [t.atom for t in self.tokens[start:k] if t.atom is not None]
        self.i = k + 1
        body = self.statements_until(in_braces=True)
        return StructureNode(kind=C.FUNCTION_DECLARATION, role="MEMBER",
                             label=tok.value, leaf_indices=leafs,
                             children=[StructureNode(kind="BLOCK", role="BODY",
                                                     children=body)])

    def simple_statement(self, kind: str) -> StructureNode:
        leafs: list[int] = []
        children: list[StructureNode] = []
        while True:
            tok = self.peek()
            if tok is None:
                break
            if tok.value == ";":
                self.take()
                break
            if tok.value == "}":
                break
            if tok.value == "{":
                self.take()
                children.append(StructureNode(
                    kind="BLOCK", role="MEMBER",
                    children=self.statements_until(in_braces=True)))
                continue
            taken = self.take()
            if taken.atom is not None:
                leafs.append(taken.atom)
        return StructureNode(kind=kind, role="MEMBER", leaf_indices=leafs,
                             children=children)

    # -- shared fragments -----------------------------------------------------------

    def paren_atoms(self) -> list[int]:
        leafs: list[int] = []
        opening = self.take()
        if opening is not None and opening.atom is not None:
            leafs.append(opening.atom)
        depth = 1
        while depth > 0:
            tok = self.take()
            if tok is None:
                break
            if tok.value == "(":
                depth += 1
            elif tok.value == ")":
                depth -= 1
            if tok.atom is not None:
                leafs.append(tok.atom)
        return leafs

    def branch_children(self) -> list[StructureNode]:
        nxt = self.peek()
        if nxt is None:
            return []
        if nxt.value == "{":
            self.take()
            return self.statements_until(in_braces=True)
        return self.statement()


def _mask(text: str) -> list[bool]:
    mask = [False] * len(text)
    for pattern in (re.compile(r"/\*.*?\*/", re.DOTALL),
                    re.compile(r"//[^\n]*"),
                    _GENERIC_SPAN):
        for match in pattern.finditer(text):
            for i in range(match.start(), match.end()):
                mask[i] = True
    return mask
