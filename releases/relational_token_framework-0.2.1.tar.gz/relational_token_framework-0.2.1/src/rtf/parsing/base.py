from __future__ import annotations

from ..core.model import ParseResult
from .comment_span import comment_offsets, string_offsets


class Parser:
    """Parser contract: source text -> ParseResult(extractions, rejected, structures).

    Extractions are atomic (concept, value, line, col) in deterministic
    traversal order. Structures reference extractions by their index in the
    flat list, so higher-level elements never duplicate atomic values.

    Lexical provenance (Layer 1)
    ----------------------------
    `comment_marker` names this language's line-comment character, or None when
    the language has none. When set, the parser labels every atom it reads from
    a comment region with `provenance=COMMENT_ORIGIN`.

    It LABELS; it never deletes. A comment-region atom is still extracted, so
    ingestion can record an explicit, auditable refusal later. Deleting it here
    would destroy the evidence that the filter spared legitimate code - the one
    fact the Layer-1 acceptance criteria depend on. Admission is ingestion's
    decision, not the parser's.

    `comment_quotes` lists the characters that open a string region, so a
    marker appearing inside a string is never mistaken for a comment start.

    String origin is labelled separately and is TRACKED, NOT ENFORCED: no atom
    is refused because it came from a string literal. Keeping it out of
    COMMENT is deliberate, so COMMENT keeps meaning exactly one thing.
    """

    language = "abstract"
    comment_marker: str | None = None
    comment_quotes: str = "'\"`"

    def _comment_offsets(self, source: str) -> set[int]:
        """Character offsets covered by line comments in `source`."""
        if not self.comment_marker:
            return set()
        return comment_offsets(source, self.comment_marker, self.comment_quotes)

    def _string_offsets(self, source: str) -> set[int]:
        """Character offsets covered by string literals in `source`."""
        return string_offsets(source, self.comment_quotes)

    def parse(self, source: str) -> ParseResult:  # pragma: no cover - interface
        raise NotImplementedError


def line_starts(source: str) -> list[int]:
    starts = [0]
    for index, ch in enumerate(source):
        if ch == "\n":
            starts.append(index + 1)
    return starts


def position_of(starts: list[int], offset: int) -> tuple[int, int]:
    """Return 1-based (line, col) for a 0-based character offset."""
    low, high = 0, len(starts) - 1
    while low < high:
        mid = (low + high + 1) // 2
        if starts[mid] <= offset:
            low = mid
        else:
            high = mid - 1
    return low + 1, offset - starts[low] + 1
