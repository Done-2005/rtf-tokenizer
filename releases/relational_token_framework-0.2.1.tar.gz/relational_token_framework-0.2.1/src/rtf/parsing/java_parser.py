"""Java parser: brace-aware recursive structure trees.

Two phases (spec sections 8-13):
  Phase A - tokenize ORIGINAL text (comment/generic-span masks keep line/col
            provenance exact) and classify every surviving token into an
            atomic Extraction with a PARSER_RULE concept proposal.
  Phase B - walk the classified token stream with brace matching and build
            StructureNode trees: CONDITIONAL_EXPRESSION
            (CONDITION/THEN_BRANCH/ELSE_BRANCH), LOOP_STRUCTURE,
            FUNCTION_DECLARATION (with BODY), CLASS_DECLARATION, STATEMENT.

Every atom lands in exactly one structure leaf range; structures reference
atoms, never duplicate them. Tokens inside comment or generic-type spans are
masked out entirely rather than misclassified - nothing is fabricated.
"""

from __future__ import annotations

import re

from ..core.model import (COMMENT_ORIGIN, STRING_ORIGIN, Extraction,
                           ParseResult, Rejection, StructureNode)
from ..semantics import concepts as C
from ..semantics.concepts import resolve_keyword
from .base import Parser, line_starts, position_of

_TOKEN = re.compile(
    r'"(?:[^"\\\n]|\\.)*"'
    r"|\d+\.\d+"
    r"|\d+"
    r"|<=|>=|==|!=|&&|\|\||\+=|-=|\*=|/=|\+\+|--"
    r"|<<|>>"
    r"|[A-Za-z_$]\w*"
    r"|[<>=!&|+\-*/%^.\[\](){};,:?@]"
)

_TYPE_WORDS = {"void", "int", "long", "short", "byte", "double", "float",
               "boolean", "char", "String", "var"}
_TYPE_WORDS |= {"Integer", "Long", "Short", "Byte", "Double", "Float",
                "Boolean", "Character", "Object"}
_MODIFIERS = {"public", "private", "protected", "static", "final",
              "synchronized", "abstract", "native", "transient", "volatile",
              "strictfp"}
_CLASS_KEYWORDS = {"class", "interface", "enum", "record"}
_QUALIFIER_STOP = {";", "=", "{", "}", ")", "("}

# Generic type argument spans: Identifier<...> immediately preceding a call
# site, cast, reference or declaration boundary. Content bounded and nesting
# shallow; anything larger stays visible and is judged normally.
_GENERIC_SPAN = re.compile(
    r"\b[A-Za-z_$]\w*\s*<(?:[^<>]|<[^<>]{0,60}>){0,60}>"
    r"(?=\s*(?:\(|\)|::|\.|new\b|;|,|\{))"
)


class _Tok:
    __slots__ = ("value", "line", "col", "atom")

    def __init__(self, value: str, line: int, col: int, atom: int | None) -> None:
        self.value = value
        self.line = line
        self.col = col
        self.atom = atom

    def cls_is_atom(self) -> bool:
        return self.atom is not None


class JavaParser(Parser):
    """Regex tokenizer + brace-aware structure builder for Java."""

    language = "java"

    # The lexer is the only place a language's lexical grammar is expressed, so
    # it is a per-language declaration rather than a module global. A subclass
    # with a different lexical grammar (R: dotted names, literal suffixes)
    # overrides this; changing it must not affect any other language.
    token_pattern = _TOKEN

    def parse(self, source: str) -> ParseResult:
        starts = line_starts(source)
        mask = _mask(source)
        tokens = [
            (m.group(0), m.start())
            for m in self.token_pattern.finditer(source)
            if not mask[m.start()]
        ]

        # Layer 1: identify comment regions without removing anything.
        comment_offsets = self._comment_offsets(source)
        # String regions are labelled too, but nothing is refused on them: a
        # string literal is legitimate content with its own address. Keeping
        # STRING distinct from COMMENT preserves the meaning of COMMENT as
        # "ingestion may refuse this", which is the property Layer 1 relies on.
        string_offsets = self._string_offsets(source)
        # Classification must reason about the CODE stream only. If a comment
        # token stayed in this list, prose would keep steering classification -
        # `Copyright (C)` would still read as a call site. Provenance is
        # represented, and the context is correspondingly honest.
        code_tokens = [(raw, off) for raw, off in tokens
                       if off not in comment_offsets]

        result = ParseResult()
        stream: list[_Tok] = []
        previous = ""
        for raw, offset in tokens:
            line, col = position_of(starts, offset)
            token = raw
            if offset in comment_offsets:
                # Still classified, so the audit can show what the parser would
                # have made of this text, and still extracted, so ingestion can
                # record a specific refusal. Never added to the structure
                # stream: comment text is not program structure.
                atom = self._classify(result, token, line, col, previous,
                                      code_tokens, offset)
                if atom is not None:
                    result.extractions[atom].provenance = COMMENT_ORIGIN
                continue
            atom = self._classify(result, token, line, col, previous,
                                  code_tokens, offset)
            if atom is not None and offset in string_offsets:
                result.extractions[atom].provenance = STRING_ORIGIN
            if atom is not None or token in "(){};":
                stream.append(_Tok(token, line, col, atom))
            previous = token

        builder = _StructureBuilder(stream)
        root = StructureNode(kind="PROGRAM_ELEMENT", role="ROOT", label="java-program")
        root.children = builder.statements_until(in_braces=False)
        result.structures.append(root)
        return result

    # -- phase A: classification ------------------------------------------

    def _classify(self, result: ParseResult, token: str, line: int, col: int,
                  previous: str, tokens: list[tuple[str, int]], offset: int) -> int | None:
        if token.startswith('"'):
            inner = token[1:-1]
            if 0 < len(inner) <= 62 and "\n" not in inner:
                return self._emit(result, C.STRING_LITERAL, token, line, col)
            result.rejected.append(
                Rejection(token[:40], "non-atomic string literal", line, col))
            return None
        if token in "(){};":
            if token in "()":
                return self._emit(result, C.DELIMITER, token, line, col)
            return None
        if re.fullmatch(r"\d+\.\d+", token):
            return self._emit(result, C.FLOAT_LITERAL, token, line, col)
        if re.fullmatch(r"\d+", token):
            return self._emit(result, C.INTEGER_LITERAL, token, line, col)
        if re.fullmatch(r"[A-Za-z_$]\w*", token):
            concept = resolve_keyword("java", token)
            if concept is not None:
                return self._emit(result, concept, token, line, col)
            if token in _TYPE_WORDS:
                return self._emit(result, C.TYPE_ANNOTATION, token, line, col)
            nxt = self._next_token(tokens, offset)
            if nxt == "(" and (previous in _TYPE_CONTEXT_DECL or previous in _MODIFIERS):
                return self._emit(result, C.FUNCTION_DECLARATION, token, line, col)
            if nxt == "(":
                return self._emit(result, C.FUNCTION_CALL, token, line, col)
            if previous in _CLASS_KEYWORDS:
                return self._emit(result, C.CLASS_DECLARATION, token, line, col)
            return self._emit(result, C.VARIABLE_BINDING, token, line, col)
        concept = resolve_keyword("java", token)
        if concept is not None:
            return self._emit(result, concept, token, line, col)
        result.rejected.append(
            Rejection(token, "unclassified symbol cannot be mapped", line, col))
        return None

    @staticmethod
    def _next_token(tokens: list[tuple[str, int]], after_offset: int) -> str:
        for raw, start in tokens:
            if start > after_offset:
                return raw
        return ""

    @staticmethod
    def _emit(result: ParseResult, concept: str, value: str,
              line: int, col: int) -> int:
        result.extractions.append(
            Extraction(concept=concept, value=value, line=line, col=col))
        return len(result.extractions) - 1


_TYPE_CONTEXT_DECL = _TYPE_WORDS | {"void"}


class _StructureBuilder:
    """Phase B: brace-aware statement/block tree over classified tokens."""

    def __init__(self, tokens: list[_Tok]) -> None:
        self.tokens = tokens
        self.i = 0

    # -- cursor helpers -----------------------------------------------------

    def peek(self, ahead: int = 0) -> _Tok | None:
        j = self.i + ahead
        return self.tokens[j] if j < len(self.tokens) else None

    def take(self) -> _Tok | None:
        tok = self.peek()
        if tok is not None:
            self.i += 1
        return tok

    # -- grammar --------------------------------------------------------------

    def statements_until(self, in_braces: bool) -> list[StructureNode]:
        nodes: list[StructureNode] = []
        while True:
            tok = self.peek()
            if tok is None:
                return nodes
            if in_braces and tok.value == "}":
                self.take()
                return nodes
            nodes.extend(self.statement())

    def statement(self) -> list[StructureNode]:
        tok = self.peek()
        if tok is None:
            return []
        if tok.value == "{":
            return [StructureNode(kind="BLOCK", role="MEMBER",
                                  children=self.scope_children())]
        if tok.value == "}":          # stray closer: absorb defensively
            self.take()
            return []
        keyword = tok.value
        if keyword == "if":
            return [self.if_node()]
        if keyword in {"for", "while"}:
            return [self.loop_node(keyword)]
        if keyword == "do":
            return [self.do_node()]
        if self._class_keyword_ahead() is not None:
            return [self.class_node(self._class_keyword_ahead())]
        if keyword in _CLASS_KEYWORDS:
            return [self.class_node(keyword)]
        if keyword in {"try", "synchronized", "switch"}:
            return [self.labeled_block_node(keyword)]
        fn = self.function_decl_node()
        if fn is not None:
            return [fn]
        return [self.simple_statement()]

    def _class_keyword_ahead(self) -> str | None:
        """Detect `modifiers class X` declarations (keyword not first token)."""
        j = self.i
        while j < len(self.tokens):
            value = self.tokens[j].value
            if value in {"{", ";", "}", "(", ")"}:
                return None
            if value in _CLASS_KEYWORDS:
                return value
            j += 1
        return None

    # -- constructs -------------------------------------------------------------

    def if_node(self) -> StructureNode:
        keyword = self.take()
        children: list[StructureNode] = []
        if self.peek() is not None and self.peek().value == "(":
            children.append(StructureNode(kind="CONDITION", role="CONDITION",
                                          leaf_indices=self.paren_atoms()))
        children.append(StructureNode(kind="THEN_BRANCH", role="THEN_BRANCH",
                                      children=self.branch_children()))
        else_leafs: list[int] = []
        else_children: list[StructureNode] = []
        nxt = self.peek()
        if nxt is not None and nxt.value == "else":
            else_leafs.append(self.take().atom)
            after = self.peek()
            if after is not None and after.value == "if":
                else_children.append(self.if_node())
            else:
                else_children.extend(self.branch_children())
        children.append(StructureNode(kind=C.ELSE_BRANCH, role="ELSE_BRANCH",
                                      leaf_indices=else_leafs,
                                      children=else_children))
        return StructureNode(kind="CONDITIONAL_EXPRESSION", role="ROOT",
                             label="if", leaf_indices=[keyword.atom],
                             children=children)

    def loop_node(self, keyword_value: str) -> StructureNode:
        keyword = self.take()
        children: list[StructureNode] = []
        nxt = self.peek()
        if nxt is not None and nxt.value == "(":
            children.append(StructureNode(kind="CONDITION", role="CONDITION",
                                          leaf_indices=self.paren_atoms()))
        children.append(StructureNode(kind="BLOCK", role="BODY",
                                      children=self.branch_children()))
        return StructureNode(kind="LOOP_STRUCTURE", role="ROOT",
                             label=keyword_value, leaf_indices=[keyword.atom],
                             children=children)

    def do_node(self) -> StructureNode:
        keyword = self.take()
        children = [StructureNode(kind="BLOCK", role="BODY",
                                  children=self.branch_children())]
        condition_leafs: list[int] = []
        nxt = self.peek()
        if nxt is not None and nxt.value == "while":
            condition_leafs.append(self.take().atom)
            if self.peek() is not None and self.peek().value == "(":
                condition_leafs.extend(self.paren_atoms())
        children.append(StructureNode(kind="CONDITION", role="CONDITION",
                                      leaf_indices=condition_leafs))
        return StructureNode(kind="LOOP_STRUCTURE", role="ROOT", label="do",
                             leaf_indices=[keyword.atom], children=children)

    def class_node(self, keyword_value: str) -> StructureNode:
        keyword = self.take()
        leafs = [keyword.atom]
        nxt = self.peek()
        while nxt is not None and nxt.value != "{":
            tok = self.take()
            if tok.atom is not None:
                leafs.append(tok.atom)
            nxt = self.peek()
        children = self.scope_children() if nxt is not None and nxt.value == "{" \
            else []
        return StructureNode(kind=C.CLASS_DECLARATION, role="ROOT",
                             label=keyword_value, leaf_indices=leafs,
                             children=children)

    def labeled_block_node(self, keyword_value: str) -> StructureNode:
        keyword = self.take()
        children: list[StructureNode] = []
        nxt = self.peek()
        if nxt is not None and nxt.value == "(":
            children.append(StructureNode(kind="CONDITION", role="CONDITION",
                                          leaf_indices=self.paren_atoms()))
        children.append(StructureNode(kind="BLOCK", role="BODY",
                                      children=self.branch_children()))
        return StructureNode(kind="STATEMENT", role="MEMBER",
                             label=keyword_value, leaf_indices=[keyword.atom],
                             children=children)

    def function_decl_node(self) -> StructureNode | None:
        """Lookahead: qualifiers/type NAME(params) [throws X, Y] '{'."""
        start = self.i
        j = start
        name_j: int | None = None
        while j < len(self.tokens):
            tok = self.tokens[j]
            if tok.value == "(" and name_j is not None:
                break
            if name_j is not None:
                return None
            if tok.cls_is_atom() and tok.value not in _QUALIFIER_STOP \
                    and tok.value not in _CLASS_KEYWORDS:
                nxt = self.tokens[j + 1].value if j + 1 < len(self.tokens) else ""
                if nxt == "(":
                    name_j = j
                    j += 1
                    continue
                j += 1
                continue
            return None
        if name_j is None:
            return None
        depth = 0
        k = name_j + 1
        while k < len(self.tokens):
            value = self.tokens[k].value
            if value == "(":
                depth += 1
            elif value == ")":
                depth -= 1
                if depth == 0:
                    break
            k += 1
        if k >= len(self.tokens):
            return None
        k += 1
        # optional throws clause
        while k < len(self.tokens) and self.tokens[k].value == "throws":
            k += 1
            while k < len(self.tokens) and (
                    self.tokens[k].cls_is_atom()
                    or self.tokens[k].value == ","):
                if self.tokens[k].value == ",":
                    k += 1
                    continue
                k += 1
        if k >= len(self.tokens) or self.tokens[k].value != "{":
            return None
        # commit: leaves from start through closing paren (inclusive)
        leafs = [t.atom for t in self.tokens[start:k] if t.atom is not None]
        self.i = k + 1
        body = self.statements_until(in_braces=True)
        return StructureNode(kind=C.FUNCTION_DECLARATION, role="MEMBER",
                             leaf_indices=leafs,
                             children=[StructureNode(kind="BLOCK", role="BODY",
                                                     children=body)])

    def simple_statement(self) -> StructureNode:
        leafs: list[int] = []
        children: list[StructureNode] = []
        while True:
            tok = self.peek()
            if tok is None:
                break
            if tok.value == ";":
                self.take()
                break
            if tok.value == "}":
                break
            if tok.value == "{":
                children.append(StructureNode(
                    kind="BLOCK", role="MEMBER", children=self.scope_children()))
                continue
            taken = self.take()
            if taken.atom is not None:
                leafs.append(taken.atom)
        return StructureNode(kind="STATEMENT", role="MEMBER",
                             leaf_indices=leafs, children=children)

    # -- shared fragments ---------------------------------------------------------

    def paren_atoms(self) -> list[int]:
        """Consume balanced '( ... )' returning every atom inside, inclusive."""
        leafs: list[int] = []
        opening = self.take()
        if opening is not None and opening.atom is not None:
            leafs.append(opening.atom)
        depth = 1
        while depth > 0:
            tok = self.take()
            if tok is None:
                break
            if tok.value == "(":
                depth += 1
            elif tok.value == ")":
                depth -= 1
            if tok.atom is not None:
                leafs.append(tok.atom)
        return leafs

    def branch_children(self) -> list[StructureNode]:
        nxt = self.peek()
        if nxt is None:
            return []
        if nxt.value == "{":
            return self.scope_children()
        return self.statement()

    def scope_children(self) -> list[StructureNode]:
        opening = self.peek()
        if opening is None or opening.value != "{":
            return []
        self.take()
        return self.statements_until(in_braces=True)


def _mask(text: str) -> list[bool]:
    """True where character sits inside a comment or a generic-type span."""
    mask = [False] * len(text)
    for pattern in (re.compile(r"/\*.*?\*/", re.DOTALL),
                    re.compile(r"//[^\n]*"),
                    _GENERIC_SPAN):
        for match in pattern.finditer(text):
            for i in range(match.start(), match.end()):
                mask[i] = True
    return mask
