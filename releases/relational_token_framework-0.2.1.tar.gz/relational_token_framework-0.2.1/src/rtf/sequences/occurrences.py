"""Document registry and ordered occurrence store.

Registries are SETS of unique knowledge; the occurrence stream preserves
ORDER and REPETITION of every atomic appearance in every source document
(spec sections 15-16, 28). Token sequences must be derived from occurrences,
never from cell id ranges.
"""

from __future__ import annotations

import hashlib

from ..core.model import CODE_ORIGIN


class SequenceStore:
    def __init__(self, conn) -> None:
        self._conn = conn

    # -- documents -----------------------------------------------------------

    def register_document(self, source_name: str, language: str, source: str,
                          parser_version: str, config_version: str) -> tuple[int, bool]:
        digest = hashlib.sha256(source.encode("utf-8")).hexdigest()
        existing = self._conn.execute(
            "SELECT document_id FROM document WHERE content_sha256 = ?", (digest,)
        ).fetchone()
        if existing is not None:
            return int(existing[0]), False
        doc_id = int(
            self._conn.execute("SELECT COALESCE(MAX(document_id), 0) + 1 FROM document").fetchone()[0]
        )
        self._conn.execute(
            "INSERT INTO document(document_id, source_name, language, content_sha256, "
            "char_length, parser_version, config_version) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (doc_id, source_name, language, digest, len(source), parser_version, config_version),
        )
        return doc_id, True

    def get_document(self, document_id: int):
        row = self._conn.execute(
            "SELECT document_id, source_name, language, content_sha256, char_length, "
            "parser_version, config_version, ingested_at FROM document WHERE document_id = ?",
            (document_id,),
        ).fetchone()
        if row is None:
            return None
        return {
            "document_id": int(row[0]), "source_name": row[1], "language": row[2],
            "content_sha256": row[3], "char_length": int(row[4]),
            "parser_version": row[5], "config_version": row[6], "ingested_at": row[7],
        }

    # -- occurrences ----------------------------------------------------------

    def record_occurrence(self, document_id: int, position: int, tag_id: int,
                          row_id: int | None, value_id: int | None, concept: str | None,
                          raw_value: str, status: str, mapping_method: str | None,
                          cell_id: int | None, line: int | None, col: int | None,
                          provenance: str = CODE_ORIGIN) -> int:
        """Record one atom's admission decision.

        `provenance` is lexical provenance, already decided by the parser; it
        defaults to CODE so that every pre-Layer-1 call site keeps its existing
        behaviour without having to be edited.
        """
        cursor = self._conn.execute(
            "INSERT INTO occurrence(document_id, position, tag_id, row_id, value_id, concept, "
            "raw_value, status, mapping_method, cell_id, line, col, provenance) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (document_id, position, tag_id, row_id, value_id, concept, raw_value,
             status, mapping_method, cell_id, line, col, provenance),
        )
        return int(cursor.lastrowid)

    def document_stream(self, document_id: int) -> list[dict]:
        rows = self._conn.execute(
            """
            SELECT o.occurrence_id, o.position, t.tag_code, r.row_code, r.canonical_name,
                   v.value_string, v.value_code, o.status, o.mapping_method, o.cell_id,
                   o.line, o.col, o.raw_value, o.provenance
            FROM occurrence o
            JOIN tag_registry t ON t.tag_id = o.tag_id
            LEFT JOIN row_registry r ON r.row_id = o.row_id
            LEFT JOIN value_registry v ON v.value_id = o.value_id
            WHERE o.document_id = ?
            ORDER BY o.position
            """,
            (document_id,),
        ).fetchall()
        return [
            {
                "occurrence_id": int(r[0]), "position": int(r[1]), "tag_code": r[2],
                "row_code": r[3], "concept": r[4], "value_string": r[5],
                "value_code": r[6], "status": r[7], "mapping_method": r[8],
                "cell_id": int(r[9]) if r[9] is not None else None,
                "line": int(r[10]) if r[10] is not None else None,
                "col": int(r[11]) if r[11] is not None else None,
                "raw_value": r[12], "provenance": r[13],
            }
            for r in rows
        ]

    def count(self, document_id: int | None = None) -> int:
        if document_id is None:
            return int(self._conn.execute("SELECT COUNT(*) FROM occurrence").fetchone()[0])
        return int(self._conn.execute(
            "SELECT COUNT(*) FROM occurrence WHERE document_id = ?", (document_id,)).fetchone()[0])
