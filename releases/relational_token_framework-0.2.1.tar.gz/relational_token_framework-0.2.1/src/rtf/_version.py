"""Package version (single source; mirrors pyproject.toml)."""

__version__ = "0.2.1"