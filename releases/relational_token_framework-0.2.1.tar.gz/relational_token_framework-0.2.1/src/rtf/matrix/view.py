"""Excel-like matrix view over the relational database (spec sections 2, 17-19).

Rows are universal concepts, columns are TAG domains; intersections show the
atomic values registered as cells. Intersections with no fact render the
configured default marker (EMPTY by default: 'concept not applicable / not
present in this domain'); explicit annotations mark UNKNOWN ('system does not
know yet'). The two states are distinct and both explicit.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class MatrixModel:
    tag_columns: list[dict] = field(default_factory=list)      # [{tag_id, qualified_name}]
    concept_rows: list[dict] = field(default_factory=list)     # [{row_id, canonical_name}]
    intersections: dict[tuple[int, int], list[str]] = field(default_factory=dict)
    markers: dict[tuple[int, int], str] = field(default_factory=dict)
    default_marker: str = "EMPTY"

    def cell_display(self, row_id: int, tag_id: int) -> str:
        values = self.intersections.get((row_id, tag_id))
        if values:
            return ",".join(values)
        marker = self.markers.get((row_id, tag_id), self.default_marker)
        return marker

    def to_text(self) -> str:
        headers = [t["qualified_name"].split("::")[-1][:12] for t in self.tag_columns]
        width = max([18] + [len(h) + 2 for h in headers])
        lines = ["CONCEPT".ljust(30) + "".join(h.ljust(width) for h in headers)]
        for row in self.concept_rows:
            label = f"{row['row_code']} {row['canonical_name']}"[:29]
            line = label.ljust(30)
            for tag in self.tag_columns:
                line += self.cell_display(row["row_id"], tag["tag_id"])[:width - 1].ljust(width)
            lines.append(line)
        return "\n".join(lines)


class MatrixEngine:
    def __init__(self, conn, config) -> None:
        self._conn = conn
        self.config = config

    def build(self) -> MatrixModel:
        model = MatrixModel(default_marker=self.config.matrix_default_marker)
        model.tag_columns = [
            {"tag_id": r[0], "qualified_name": r[1]}
            for r in self._conn.execute(
                "SELECT tag_id, qualified_name FROM tag_registry ORDER BY tag_id")
        ]
        model.concept_rows = [
            {"row_id": r[0], "row_code": r[1], "canonical_name": r[2]}
            for r in self._conn.execute(
                "SELECT row_id, row_code, canonical_name FROM row_registry ORDER BY row_id")
        ]
        for tag_id, row_id, value_string in self._conn.execute(
            """
            SELECT c.tag_id, c.row_id, v.value_string
            FROM cell_registry c
            JOIN value_registry v ON v.value_id = c.value_id
            ORDER BY c.row_id, c.tag_id, v.value_string
            """
        ):
            model.intersections.setdefault((int(row_id), int(tag_id)), []).append(value_string)
        for tag_id, row_id, status in self._conn.execute(
            "SELECT tag_id, row_id, status FROM matrix_annotation"
        ):
            key = (int(row_id), int(tag_id))
            if key not in model.intersections:
                model.markers[key] = status
        return model

    def annotate(self, tag_id: int, row_id: int, status: str, note: str = "") -> None:
        if status not in ("EMPTY", "UNKNOWN"):
            raise ValueError("annotation status must be EMPTY or UNKNOWN")
        self._conn.execute(
            "INSERT INTO matrix_annotation(tag_id, row_id, status, note) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(tag_id, row_id) DO UPDATE SET status = excluded.status, note = excluded.note",
            (tag_id, row_id, status, note),
        )
        self._conn.commit()
