"""Cross-Domain Function: read-only relationship POINTER over RTF registries.

Spec mandate (CROSS-DOMAIN FUNCTION RULE):
  - It may query, retrieve, point, traverse.
  - It can NEVER create, overwrite, silently infer, translate text, or guess.
  - Unknown relationship -> UNRESOLVED. Conflicting -> CONFLICT.

Enforcement: the lookup opens its own SQLite connection in read-only mode
(`file:...?mode=ro`), so fabrication is impossible at the API level, not just
by convention. Every returned relationship is an EXISTING cell or ledger
entry - nothing else.
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass, field

RESOLVED = "RESOLVED"
UNRESOLVED = "UNRESOLVED"
CONFLICT = "CONFLICT"


@dataclass
class Relationship:
    tag_qualified: str
    row_code: str
    row_name: str
    value_string: str
    cell_id: int


@dataclass
class CrossDomainResult:
    status: str                       # RESOLVED | UNRESOLVED | CONFLICT
    source: dict
    relationships: list[Relationship] = field(default_factory=list)
    conflicts: list[dict] = field(default_factory=list)
    detail: str = ""


class CrossDomainFunction:
    """Point to ALREADY-ESTABLISHED cross-domain relationships. Read-only."""

    def __init__(self, db_path: str) -> None:
        uri = f"file:{db_path}?mode=ro"
        self._conn = sqlite3.connect(uri, uri=True)
        self._conn.execute("PRAGMA query_only = ON")

    def close(self) -> None:
        self._conn.close()

    # -- internal read-only queries ---------------------------------------

    def _row_for_cell(self, cell_id: int) -> dict | None:
        row = self._conn.execute(
            """
            SELECT c.tag_id, c.row_id, c.value_id, tr.qualified_name,
                   rr.row_code, rr.canonical_name, vr.value_string
            FROM cell_registry c
            JOIN tag_registry tr ON tr.tag_id = c.tag_id
            JOIN row_registry rr ON rr.row_id = c.row_id
            JOIN value_registry vr ON vr.value_id = c.value_id
            WHERE c.cell_id = ?
            """,
            (cell_id,),
        ).fetchone()
        if row is None:
            return None
        return {
            "tag_id": int(row[0]), "row_id": int(row[1]), "value_id": int(row[2]),
            "tag_qualified": row[3], "row_code": row[4], "row_name": row[5],
            "value_string": row[6],
        }

    def _find_cell(self, source_domain: str, value: str | None,
                   row_name: str | None) -> dict | None:
        """Locate an established source cell by domain + (value | row id/name)."""
        clauses = ["tr.qualified_name = ?"]
        params: list = [source_domain]
        if value is not None:
            clauses.append("vr.value_string = ?")
            params.append(value)
        if row_name is not None:
            # accept either the canonical concept name or the ROW_ code
            clauses.append("(rr.canonical_name = ? OR rr.row_code = ?)")
            params.extend([row_name, row_name])
        row = self._conn.execute(
            "SELECT c.cell_id FROM cell_registry c "
            "JOIN tag_registry tr ON tr.tag_id = c.tag_id "
            "JOIN row_registry rr ON rr.row_id = c.row_id "
            "JOIN value_registry vr ON vr.value_id = c.value_id "
            f"WHERE {' AND '.join(clauses)} LIMIT 1",
            params,
        ).fetchone()
        return self._row_for_cell(int(row[0])) if row else None

    def _conflicts_for(self, variant: str) -> list[dict]:
        rows = self._conn.execute(
            "SELECT conflict_id, variant, attempted_row_id, existing_row_id "
            "FROM mapping_conflict WHERE variant = ?",
            (variant,),
        ).fetchall()
        return [
            {"conflict_id": int(r[0]), "variant": r[1],
             "attempted_row_id": int(r[2]), "existing_row_id": int(r[3])}
            for r in rows
        ]

    def _cells_sharing_row(self, row_id: int, target_domain: str | None) -> list[Relationship]:
        clauses = ["c.row_id = ?"]
        params: list = [row_id]
        if target_domain is not None:
            clauses.append("tr.qualified_name = ?")
            params.append(target_domain)
        rows = self._conn.execute(
            "SELECT c.cell_id FROM cell_registry c "
            "JOIN tag_registry tr ON tr.tag_id = c.tag_id "
            f"WHERE {' AND '.join(clauses)} ORDER BY c.cell_id",
            params,
        ).fetchall()
        relationships = []
        for (cell_id,) in rows:
            fact = self._row_for_cell(int(cell_id))
            relationships.append(Relationship(
                tag_qualified=fact["tag_qualified"], row_code=fact["row_code"],
                row_name=fact["row_name"], value_string=fact["value_string"],
                cell_id=int(cell_id)))
        return relationships

    # -- public pointer API -------------------------------------------------

    def lookup(self, source_domain: str, source_value: str | None = None,
               source_row: str | None = None,
               target_domain: str | None = None) -> CrossDomainResult:
        """Point at established relationships for a source fact.

        Returns every EXISTING cell sharing the source fact's universal ROW,
        optionally filtered to one target domain. Never creates anything.
        """
        source = {"domain": source_domain, "value": source_value,
                  "row": source_row, "target_domain": target_domain}

        variant_candidates = [v for v in (source_value, source_row) if v]
        conflicts: list[dict] = []
        for variant in variant_candidates:
            conflicts.extend(self._conflicts_for(variant))
        if conflicts:
            return CrossDomainResult(status=CONFLICT, source=source,
                                     conflicts=conflicts,
                                     detail="mapping conflict recorded for variant")

        source_cell = self._find_cell(source_domain, source_value, source_row)
        if source_cell is None:
            return CrossDomainResult(status=UNRESOLVED, source=source,
                                     detail="no established source fact")
        relationships = self._cells_sharing_row(source_cell["row_id"], target_domain)
        if not relationships:
            return CrossDomainResult(status=UNRESOLVED, source=source,
                                     detail="no established relationships for ROW")
        return CrossDomainResult(status=RESOLVED, source=source,
                                 relationships=relationships)

    def resolution_stats(self) -> dict:
        """Registry-level relationship coverage summary (read-only)."""
        cells = int(self._conn.execute("SELECT COUNT(*) FROM cell_registry").fetchone()[0])
        rows = int(self._conn.execute("SELECT COUNT(*) FROM row_registry").fetchone()[0])
        multi = int(self._conn.execute(
            "SELECT COUNT(*) FROM (SELECT row_id FROM cell_registry "
            "GROUP BY row_id HAVING COUNT(DISTINCT tag_id) > 1)").fetchone()[0])
        conflicts = int(self._conn.execute(
            "SELECT COUNT(*) FROM mapping_conflict").fetchone()[0])
        return {"cells": cells, "rows": rows,
                "rows_spanning_multiple_domains": multi,
                "recorded_conflicts": conflicts}


__all__ = ["CrossDomainFunction", "CrossDomainResult", "Relationship",
           "RESOLVED", "UNRESOLVED", "CONFLICT"]
