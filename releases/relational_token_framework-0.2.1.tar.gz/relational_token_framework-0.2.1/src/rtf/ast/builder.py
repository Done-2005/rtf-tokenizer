"""AST layer: materialize parser structure sketches into structural elements.

The parser proposes StructureNode trees referencing flat extraction indices;
this module persists them as structural_element rows whose members point at
the corresponding atomic OCCURRENCES - the atoms are shared, never duplicated
(spec sections 8-13).
"""

from __future__ import annotations

from ..core.model import ParseResult, StructureNode


class ElementBuilder:
    def __init__(self, conn, store) -> None:
        self._conn = conn
        self.store = store

    def build_from_parse(self, document_id: int, parsed: ParseResult,
                         index_to_occurrence: dict[int, int]) -> int:
        """Persist all root structure trees; returns number of elements created."""
        created = 0
        for root in parsed.structures:
            created += self._persist_node(document_id, root, parent_id=None,
                                          index_to_occurrence=index_to_occurrence)
        return created

    def _persist_node(self, document_id: int, node: StructureNode, parent_id: int | None,
                      index_to_occurrence: dict[int, int]) -> int:
        element_id = self.store.create_element(
            document_id=document_id, kind=node.kind, role=node.role, parent_id=parent_id)
        position = 0
        for leaf_index in node.leaf_indices:
            occurrence_id = index_to_occurrence.get(leaf_index)
            if occurrence_id is None:
                continue
            self.store.add_member(element_id, position, role="ATOM",
                                  child_occurrence_id=occurrence_id)
            position += 1
        for child in node.children:
            child_id = self._persist_node(document_id, child, parent_id=element_id,
                                          index_to_occurrence=index_to_occurrence)
            self.store.add_member(element_id, position, role=child.role or "CHILD",
                                  child_element_id=child_id)
            position += 1
        return element_id
