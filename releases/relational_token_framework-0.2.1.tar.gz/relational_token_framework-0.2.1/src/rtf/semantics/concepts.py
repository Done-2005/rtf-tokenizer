"""Canonical universal concepts and curated alias tables.

These constants ARE the explicit semantic mapping decisions of RTF-V5.
A surface token never becomes a ROW by itself: it must resolve through one
of these curated entries, a stored mapping, or an explicit manual mapping.
Anything else is UNRESOLVED (spec sections 4, 14, 35).
"""

from __future__ import annotations

CONDITIONAL_LOGIC = "CONDITIONAL_LOGIC"
ELSE_BRANCH = "ELSE_BRANCH"
FUNCTION_DECLARATION = "FUNCTION_DECLARATION"
FUNCTION_CALL = "FUNCTION_CALL"
LOOP_CONSTRUCT = "LOOP_CONSTRUCT"
VARIABLE_BINDING = "VARIABLE_BINDING"
INTEGER_LITERAL = "INTEGER_LITERAL"
FLOAT_LITERAL = "FLOAT_LITERAL"
STRING_LITERAL = "STRING_LITERAL"
BOOLEAN_LITERAL = "BOOLEAN_LITERAL"
BOOLEAN_OPERATOR = "BOOLEAN_OPERATOR"
CLASS_DECLARATION = "CLASS_DECLARATION"
RELATIONAL_OPERATOR = "RELATIONAL_OPERATOR"
ARITHMETIC_OPERATOR = "ARITHMETIC_OPERATOR"
ASSIGNMENT_STATEMENT = "ASSIGNMENT_STATEMENT"
RETURN_STATEMENT = "RETURN_STATEMENT"
TYPE_ANNOTATION = "TYPE_ANNOTATION"
MODULE_IMPORT = "MODULE_IMPORT"
RANGE_EXPRESSION = "RANGE_EXPRESSION"
MACRO_INVOCATION = "MACRO_INVOCATION"
DELIMITER = "DELIMITER"
QUERY_SELECT = "QUERY_SELECT"
QUERY_FILTER = "QUERY_FILTER"
MEASUREMENT = "MEASUREMENT"
FORCE = "FORCE"
VELOCITY = "VELOCITY"
ENERGY = "ENERGY"
ACCELERATION = "ACCELERATION"
CHEMICAL_ELEMENT = "CHEMICAL_ELEMENT"
CHEMICAL_COMPOUND = "CHEMICAL_COMPOUND"
CHEMICAL_REACTION = "CHEMICAL_REACTION"
CONCENTRATION = "CONCENTRATION"
BIOLOGICAL_CELL = "BIOLOGICAL_CELL"
GENE = "GENE"
ORGANISM = "ORGANISM"
BIOLOGICAL_PROCESS = "BIOLOGICAL_PROCESS"
PLANT_ROOT = "PLANT_ROOT"
PLANT_STEM = "PLANT_STEM"
PLANT_LEAF = "PLANT_LEAF"
PLANT_FLOWER = "PLANT_FLOWER"
ORGAN = "ORGAN"
TISSUE = "TISSUE"
ANATOMICAL_STRUCTURE = "ANATOMICAL_STRUCTURE"
ANATOMICAL_SITE = "ANATOMICAL_SITE"
DIAGNOSIS = "DIAGNOSIS"
MEDICAL_PROCEDURE = "MEDICAL_PROCEDURE"
BEHAVIOR = "BEHAVIOR"
HISTORICAL_EVENT = "HISTORICAL_EVENT"
HISTORICAL_PERIOD = "HISTORICAL_PERIOD"
NOUN = "NOUN"
VERB = "VERB"
ADJECTIVE = "ADJECTIVE"

SEED_CONCEPTS: list[tuple[str, str]] = [
    (CONDITIONAL_LOGIC, "universal concept of conditional branching control flow"),
    (ELSE_BRANCH, "universal concept of the alternative branch of a conditional"),
    (FUNCTION_DECLARATION, "universal concept of declaring a named callable unit"),
    (FUNCTION_CALL, "universal concept of invoking a callable with arguments"),
    (LOOP_CONSTRUCT, "universal concept of iterative repetition over an iteration space"),
    (VARIABLE_BINDING, "universal concept of binding an identifier to a stored value"),
    (INTEGER_LITERAL, "universal concept of an integer scalar literal"),
    (FLOAT_LITERAL, "universal concept of a floating point scalar literal"),
    (STRING_LITERAL, "universal concept of a string scalar literal"),
    (BOOLEAN_LITERAL, "universal concept of a boolean true/false scalar literal"),
    (BOOLEAN_OPERATOR, "universal concept of logical operators combining predicates"),
    (CLASS_DECLARATION, "universal concept of declaring a composite type blueprint"),
    (RELATIONAL_OPERATOR, "universal concept of comparison or equality relations"),
    (ARITHMETIC_OPERATOR, "universal concept of numeric arithmetic operations"),
    (ASSIGNMENT_STATEMENT, "universal concept of assigning a value to an identifier"),
    (RETURN_STATEMENT, "universal concept of returning a value from a callable"),
    (TYPE_ANNOTATION, "universal concept of annotating an identifier with a type"),
    (MODULE_IMPORT, "universal concept of importing external modules into scope"),
    (RANGE_EXPRESSION, "universal concept of an iteration space or membership range"),
    (MACRO_INVOCATION, "universal concept of macro invocation expanding to code"),
    (DELIMITER, "universal structural delimiter symbol such as parentheses"),
    (QUERY_SELECT, "universal concept of projecting selected fields from a collection"),
    (QUERY_FILTER, "universal concept of filtering collection members by a predicate"),
    # 10-domain expansion (each sanctioned as a distinct universal concept;
    # similar words across domains are NOT auto-merged - sharing requires
    # explicit justification recorded in the semantic ledger)
    (MEASUREMENT, "universal concept of a quantitative measurement of a physical quantity"),
    (FORCE, "universal concept of physical force"),
    (VELOCITY, "universal concept of physical velocity"),
    (ENERGY, "universal concept of physical energy"),
    (ACCELERATION, "universal concept of physical acceleration"),
    (CHEMICAL_ELEMENT, "universal concept of a chemical element"),
    (CHEMICAL_COMPOUND, "universal concept of a chemical compound"),
    (CHEMICAL_REACTION, "universal concept of a chemical reaction"),
    (CONCENTRATION, "universal concept of solution concentration"),
    (BIOLOGICAL_CELL, "universal concept of a biological cell"),
    (GENE, "universal concept of a gene"),
    (ORGANISM, "universal concept of a living organism"),
    (BIOLOGICAL_PROCESS, "universal concept of a biological process"),
    (PLANT_ROOT, "universal concept of a plant root organ"),
    (PLANT_STEM, "universal concept of a plant stem organ"),
    (PLANT_LEAF, "universal concept of a plant leaf organ"),
    (PLANT_FLOWER, "universal concept of a plant flower organ"),
    (ORGAN, "universal concept of an anatomical organ"),
    (TISSUE, "universal concept of biological tissue"),
    (ANATOMICAL_STRUCTURE, "universal concept of an anatomical structure"),
    (ANATOMICAL_SITE, "universal concept of an anatomical site referenced in medical coding"),
    (DIAGNOSIS, "universal concept of a medical diagnosis"),
    (MEDICAL_PROCEDURE, "universal concept of a medical procedure"),
    (BEHAVIOR, "universal concept of observed animal behavior"),
    (HISTORICAL_EVENT, "universal concept of a historical event"),
    (HISTORICAL_PERIOD, "universal concept of a historical period"),
    (NOUN, "universal concept of the grammatical class of nouns"),
    (VERB, "universal concept of the grammatical class of verbs"),
    (ADJECTIVE, "universal concept of the grammatical class of adjectives"),
]

# Curated surface-token to universal-concept mappings per language.
# These constitute DOMAIN_RULE / PARSER_RULE evidence, recorded in the ledger.
KEYWORD_MAPS: dict[str, dict[str, str]] = {
    "python": {
        "if": CONDITIONAL_LOGIC,
        "elif": CONDITIONAL_LOGIC,
        "else": ELSE_BRANCH,
        "def": FUNCTION_DECLARATION,
        "lambda": FUNCTION_DECLARATION,
        "for": LOOP_CONSTRUCT,
        "while": LOOP_CONSTRUCT,
        "in": RANGE_EXPRESSION,
        "class": CLASS_DECLARATION,
        "import": MODULE_IMPORT,
        "return": RETURN_STATEMENT,
        "and": BOOLEAN_OPERATOR,
        "or": BOOLEAN_OPERATOR,
        "not": BOOLEAN_OPERATOR,
        "True": BOOLEAN_LITERAL,
        "False": BOOLEAN_LITERAL,
        "print": FUNCTION_CALL,
    },
    "java": {
        "if": CONDITIONAL_LOGIC,
        "else": ELSE_BRANCH,
        "for": LOOP_CONSTRUCT,
        "while": LOOP_CONSTRUCT,
        "do": LOOP_CONSTRUCT,
        "switch": CONDITIONAL_LOGIC,
        "case": CONDITIONAL_LOGIC,
        "class": CLASS_DECLARATION,
        "interface": CLASS_DECLARATION,
        "enum": CLASS_DECLARATION,
        "record": CLASS_DECLARATION,
        "new": FUNCTION_CALL,
        "return": RETURN_STATEMENT,
        "import": MODULE_IMPORT,
        "=": ASSIGNMENT_STATEMENT,
        "<": RELATIONAL_OPERATOR,
        ">": RELATIONAL_OPERATOR,
        "<=": RELATIONAL_OPERATOR,
        ">=": RELATIONAL_OPERATOR,
        "==": RELATIONAL_OPERATOR,
        "!=": RELATIONAL_OPERATOR,
        "+": ARITHMETIC_OPERATOR,
        "-": ARITHMETIC_OPERATOR,
        "*": ARITHMETIC_OPERATOR,
        "/": ARITHMETIC_OPERATOR,
        "%": ARITHMETIC_OPERATOR,
        "&&": BOOLEAN_OPERATOR,
        "||": BOOLEAN_OPERATOR,
        "!": BOOLEAN_OPERATOR,
        "true": BOOLEAN_LITERAL,
        "false": BOOLEAN_LITERAL,
        "System": VARIABLE_BINDING,
        "out": VARIABLE_BINDING,
        "println": FUNCTION_CALL,
        "printf": FUNCTION_CALL,
    },
    "rust": {
        "if": CONDITIONAL_LOGIC,
        "else": ELSE_BRANCH,
        "loop": LOOP_CONSTRUCT,
        "while": LOOP_CONSTRUCT,
        "for": LOOP_CONSTRUCT,
        "in": RANGE_EXPRESSION,
        "..": RANGE_EXPRESSION,
        "fn": FUNCTION_DECLARATION,
        "struct": CLASS_DECLARATION,
        "enum": CLASS_DECLARATION,
        "trait": CLASS_DECLARATION,
        "impl": CLASS_DECLARATION,
        "let": ASSIGNMENT_STATEMENT,
        "mut": ASSIGNMENT_STATEMENT,
        "return": RETURN_STATEMENT,
        "match": CONDITIONAL_LOGIC,
        "use": MODULE_IMPORT,
        "=": ASSIGNMENT_STATEMENT,
        "<": RELATIONAL_OPERATOR,
        ">": RELATIONAL_OPERATOR,
        "<=": RELATIONAL_OPERATOR,
        ">=": RELATIONAL_OPERATOR,
        "==": RELATIONAL_OPERATOR,
        "!=": RELATIONAL_OPERATOR,
        "+": ARITHMETIC_OPERATOR,
        "-": ARITHMETIC_OPERATOR,
        "*": ARITHMETIC_OPERATOR,
        "/": ARITHMETIC_OPERATOR,
        "%": ARITHMETIC_OPERATOR,
        "&&": BOOLEAN_OPERATOR,
        "||": BOOLEAN_OPERATOR,
        "true": BOOLEAN_LITERAL,
        "false": BOOLEAN_LITERAL,
    },
    "math": {
        "=": RELATIONAL_OPERATOR,
        "<": RELATIONAL_OPERATOR,
        ">": RELATIONAL_OPERATOR,
        "<=": RELATIONAL_OPERATOR,
        ">=": RELATIONAL_OPERATOR,
        "!=": RELATIONAL_OPERATOR,
        "==": RELATIONAL_OPERATOR,
        "+": ARITHMETIC_OPERATOR,
        "-": ARITHMETIC_OPERATOR,
        "*": ARITHMETIC_OPERATOR,
        "/": ARITHMETIC_OPERATOR,
        "^": ARITHMETIC_OPERATOR,
        "%": ARITHMETIC_OPERATOR,
    },
    "sql": {
        "select": QUERY_SELECT,
        "from": QUERY_SELECT,
        "distinct": QUERY_SELECT,
        "where": QUERY_FILTER,
        "having": QUERY_FILTER,
        "and": BOOLEAN_OPERATOR,
        "or": BOOLEAN_OPERATOR,
        "not": BOOLEAN_OPERATOR,
        "=": RELATIONAL_OPERATOR,
        "<": RELATIONAL_OPERATOR,
        ">": RELATIONAL_OPERATOR,
        "<=": RELATIONAL_OPERATOR,
        ">=": RELATIONAL_OPERATOR,
        "!=": RELATIONAL_OPERATOR,
        "+": ARITHMETIC_OPERATOR,
        "-": ARITHMETIC_OPERATOR,
        "*": ARITHMETIC_OPERATOR,
        "/": ARITHMETIC_OPERATOR,
        "%": ARITHMETIC_OPERATOR,
    },
}

LATEX_ALIASES: dict[str, str] = {
    r"\gt": ">",
    r"\lt": "<",
    r"\leq": "<=",
    r"\geq": ">=",
    r"\neq": "!=",
    r"\times": "*",
    r"\div": "/",
    r"\pm": "+",
}

# 10-domain expansion: curated domain keyword tables. Every entry is an
# explicit semantic mapping decision recorded in the ledger; unknown
# words become VARIABLE_BINDING proposals (honest) or UNRESOLVED.
DOMAIN_KEYWORD_MAPS: dict[str, dict[str, str]] = {
    "physics": {
        "force": FORCE, "mass": MEASUREMENT, "acceleration": ACCELERATION,
        "velocity": VELOCITY, "speed": VELOCITY, "energy": ENERGY,
        "distance": MEASUREMENT, "time": MEASUREMENT, "work": ENERGY,
        "momentum": MEASUREMENT, "gravity": FORCE, "newton": FORCE,
    },
    "chemistry": {
        "element": CHEMICAL_ELEMENT, "compound": CHEMICAL_COMPOUND,
        "reaction": CHEMICAL_REACTION, "concentration": CONCENTRATION,
        "moles": CONCENTRATION, "hydrogen": CHEMICAL_ELEMENT,
        "oxygen": CHEMICAL_ELEMENT, "sodium": CHEMICAL_ELEMENT,
        "chlorine": CHEMICAL_ELEMENT, "carbon": CHEMICAL_ELEMENT,
        "water": CHEMICAL_COMPOUND, "salt": CHEMICAL_COMPOUND,
    },
    "biology": {
        "cell": BIOLOGICAL_CELL, "gene": GENE, "organism": ORGANISM,
        "contains": BIOLOGICAL_PROCESS, "expresses": BIOLOGICAL_PROCESS,
        "produces": BIOLOGICAL_PROCESS, "divides": BIOLOGICAL_PROCESS,
        "protein": BIOLOGICAL_PROCESS, "dna": GENE, "tissue": TISSUE,
    },
    "botany": {
        "root": PLANT_ROOT, "stem": PLANT_STEM, "leaf": PLANT_LEAF,
        "leaves": PLANT_LEAF, "flower": PLANT_FLOWER,
        "flowers": PLANT_FLOWER, "absorbs": BIOLOGICAL_PROCESS,
        "photosynthesis": BIOLOGICAL_PROCESS, "grows": BIOLOGICAL_PROCESS,
    },
    "zoology": {
        "organism": ORGANISM, "animal": ORGANISM,
        "behavior": BEHAVIOR, "migrates": BEHAVIOR,
        "hunts": BEHAVIOR, "anatomy": ANATOMICAL_STRUCTURE,
    },
    "anatomy": {
        "organ": ORGAN, "heart": ORGAN, "lung": ORGAN,
        "liver": ORGAN, "tissue": TISSUE, "connects": BIOLOGICAL_PROCESS,
        "structure": ANATOMICAL_STRUCTURE, "bone": ANATOMICAL_STRUCTURE,
        "muscle": ANATOMICAL_STRUCTURE,
    },
    "medical": {
        "diagnosis": DIAGNOSIS, "procedure": MEDICAL_PROCEDURE,
        "site": ANATOMICAL_SITE, "biopsy": MEDICAL_PROCEDURE,
        "transplant": MEDICAL_PROCEDURE, "diabetes": DIAGNOSIS,
        "heart": ORGAN,
    },
    "english": {
        "noun": NOUN, "verb": VERB, "adjective": ADJECTIVE,
        "adverb": ADJECTIVE, "is": RELATIONAL_OPERATOR,
        "run": VERB, "dog": NOUN, "fast": ADJECTIVE,
    },
    "history": {
        "event": HISTORICAL_EVENT, "war": HISTORICAL_EVENT,
        "period": HISTORICAL_PERIOD, "renaissance": HISTORICAL_PERIOD,
        "revolution": HISTORICAL_EVENT, "treaty": HISTORICAL_EVENT,
        "empire": HISTORICAL_PERIOD,
    },
    "r": {
        "if": CONDITIONAL_LOGIC, "else": ELSE_BRANCH,
        "for": LOOP_CONSTRUCT, "while": LOOP_CONSTRUCT,
        "repeat": LOOP_CONSTRUCT, "function": FUNCTION_DECLARATION,
        "return": RETURN_STATEMENT, "in": RANGE_EXPRESSION,
        "library": MODULE_IMPORT, "require": MODULE_IMPORT,
        "TRUE": BOOLEAN_LITERAL, "FALSE": BOOLEAN_LITERAL,
        "NA": BOOLEAN_LITERAL, "NULL": BOOLEAN_LITERAL,
        "Inf": FLOAT_LITERAL, "NaN": FLOAT_LITERAL,
        "<=": RELATIONAL_OPERATOR, ">=": RELATIONAL_OPERATOR,
        "==": RELATIONAL_OPERATOR, "!=": RELATIONAL_OPERATOR,
        "<": RELATIONAL_OPERATOR, ">": RELATIONAL_OPERATOR,
        "+": ARITHMETIC_OPERATOR, "-": ARITHMETIC_OPERATOR,
        "*": ARITHMETIC_OPERATOR, "/": ARITHMETIC_OPERATOR,
        "%%": ARITHMETIC_OPERATOR, "^": ARITHMETIC_OPERATOR,
        "&&": BOOLEAN_OPERATOR, "||": BOOLEAN_OPERATOR,
        "&": BOOLEAN_OPERATOR, "|": BOOLEAN_OPERATOR,
        "!": BOOLEAN_OPERATOR,
        "cat": FUNCTION_CALL, "print": FUNCTION_CALL,
        "paste": FUNCTION_CALL, "sum": FUNCTION_CALL,
        "mean": FUNCTION_CALL, "length": FUNCTION_CALL,
        "c": FUNCTION_CALL, "matrix": FUNCTION_CALL,
        "data.frame": FUNCTION_CALL,
    },
}


def resolve_keyword(language: str, token: str) -> str | None:
    """Curated per-language keyword resolution. Returns canonical concept or None."""
    return (KEYWORD_MAPS.get(language, {}).get(token)
            or DOMAIN_KEYWORD_MAPS.get(language, {}).get(token))
