"""Semantic mapping layer.

Resolution order (spec section 14):
  1. EXACT_CANONICAL - the proposed concept equals a registered canonical name
  2. EXPLICIT_ALIAS / DOMAIN_RULE / PARSER_RULE - curated or stored mappings
     recorded in the semantic_mapping ledger
  3. MANUAL_MAPPING - explicit human decision via map_manual()
  4. UNRESOLVED - no safe determination; never fabricate

Automatic ROW creation is OFF by default and only happens through the
explicit configuration flag (auto_row_creation=True) or create_row().
"""

from __future__ import annotations

from dataclasses import dataclass

from ..core.errors import SemanticConflictError


@dataclass
class RowResolution:
    row_id: int | None
    method: str | None   # one of the ledger methods, or 'UNRESOLVED'
    created: bool = False
    detail: str = ""


class SemanticMapper:
    def __init__(self, conn, rows, config) -> None:
        self._conn = conn
        self.rows = rows
        self.config = config

    # -- resolution ---------------------------------------------------------

    def resolve(self, concept: str, language: str | None = None,
                surface_token: str | None = None) -> RowResolution:
        """Resolve a parser-proposed canonical concept to a ROW.

        language/surface_token are used to record PARSER_RULE evidence when the
        proposal came from a curated keyword table rather than a canonical name.
        """
        exact = self.rows.find_exact(concept)
        if exact is not None:
            if surface_token is not None and surface_token != concept:
                self._ledger(surface_token, exact, "PARSER_RULE",
                             f"keyword table {language} -> {concept}")
            return RowResolution(exact, "EXACT_CANONICAL", detail=concept)

        stored = self._stored_variant(concept)
        if stored is not None:
            return stored

        if self.config.auto_row_creation:
            row_id = self.rows.create(concept, f"auto-created from parser proposal {concept!r}")
            self._ledger(concept, row_id, "EXACT_CANONICAL", "auto-created row")
            return RowResolution(row_id, "EXACT_CANONICAL", created=True)

        return RowResolution(None, "UNRESOLVED")

    def resolve_surface(self, language: str, token: str) -> RowResolution:
        """Resolve a raw surface token through curated keyword tables."""
        from .concepts import resolve_keyword

        concept = resolve_keyword(language, token)
        if concept is None:
            stored = self._stored_variant(token)
            if stored is not None:
                return stored
            return RowResolution(None, "UNRESOLVED")
        row_id = self.rows.find_exact(concept)
        if row_id is None:
            return RowResolution(None, "UNRESOLVED")
        self._ledger(token, row_id, "DOMAIN_RULE", f"{language} keyword table -> {concept}")
        return RowResolution(row_id, "DOMAIN_RULE", detail=f"{language}:{token}->{concept}")

    def _stored_variant(self, variant: str) -> RowResolution | None:
        row = self._conn.execute(
            "SELECT m.row_id, m.method FROM semantic_mapping m "
            "WHERE m.variant = ? AND m.method IN "
            "('EXPLICIT_ALIAS','DOMAIN_RULE','PARSER_RULE','MANUAL_MAPPING') "
            "ORDER BY CASE m.method WHEN 'MANUAL_MAPPING' THEN 0 ELSE 1 END LIMIT 1",
            (variant,),
        ).fetchone()
        if row is None:
            return None
        return RowResolution(int(row[0]), row[1], detail=variant)

    def _ledger(self, variant: str, row_id: int, method: str, detail: str = "") -> None:
        self._conn.execute(
            "INSERT OR IGNORE INTO semantic_mapping(variant, row_id, method, detail) "
            "VALUES (?, ?, ?, ?)",
            (variant, row_id, method, detail),
        )

    # -- explicit human decisions -------------------------------------------

    def map_manual(self, variant: str, row_id: int, detail: str = "") -> None:
        if self.rows.get(row_id) is None:
            raise KeyError(f"unknown row_id {row_id}")
        existing = self._stored_variant(variant)
        if existing is not None and existing.row_id != row_id:
            self._conn.execute(
                "INSERT INTO mapping_conflict(variant, attempted_row_id, existing_row_id) "
                "VALUES (?, ?, ?)",
                (variant, row_id, existing.row_id),
            )
            # commit BEFORE raising so the conflict is durable and visible
            # to read-only observers (Cross-Domain Function must see it)
            self._conn.commit()
            raise SemanticConflictError(
                f"variant {variant!r} already maps to row {existing.row_id}; conflict recorded"
            )
        self._ledger(variant, row_id, "MANUAL_MAPPING", detail)
        self._conn.commit()

    def conflicts(self) -> list[dict]:
        rows = self._conn.execute(
            "SELECT conflict_id, variant, attempted_row_id, existing_row_id FROM mapping_conflict"
        ).fetchall()
        return [
            {
                "conflict_id": int(r[0]),
                "variant": r[1],
                "attempted_row_id": int(r[2]),
                "existing_row_id": int(r[3]),
            }
            for r in rows
        ]

    def ledger_entries(self) -> list[dict]:
        rows = self._conn.execute(
            "SELECT mapping_id, variant, row_id, method, detail FROM semantic_mapping ORDER BY mapping_id"
        ).fetchall()
        return [
            {"mapping_id": int(r[0]), "variant": r[1], "row_id": int(r[2]),
             "method": r[3], "detail": r[4]}
            for r in rows
        ]
