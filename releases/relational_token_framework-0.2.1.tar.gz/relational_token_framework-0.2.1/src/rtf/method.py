"""Your method, packaged: the RTF pipeline as one object.

RTF wraps the frozen ingestion (TAG -> parse -> ROW -> VALUE -> CELL ->
occurrences -> structures) with language auto-detection, tokenizer
fitting, training-ready streams, validation, and persistence - everything
needed to pipeline any data, locally or on Kaggle, in a few lines.
"""

from __future__ import annotations

import sqlite3
from hashlib import sha256
from pathlib import Path

from . import representation as _rep
from .core.model import IngestionReport, RTFConfig
from .engine import RepresentationEngine
from .tokenizer import RTFTokenizer

EXT_LANGUAGES = {
    ".py": "python", ".pyw": "python",
    ".java": "java",
    ".rs": "rust",
    ".r": "r", ".R": "r",
    ".sql": "sql",
    ".tex": "math", ".math": "math",
    ".txt": "text", ".md": "text", ".csv": "text", ".json": "text",
    ".log": "text", ".xml": "text", ".yaml": "text", ".yml": "text",
    ".html": "text",
}

_SOURCE_DDL = (
    "CREATE TABLE IF NOT EXISTS document_source("
    "document_id INTEGER PRIMARY KEY REFERENCES document(document_id), "
    "content TEXT NOT NULL)"
)


class RTF:
    def __init__(self, db_path: str = ":memory:",
                 config: RTFConfig | None = None) -> None:
        self._db_path = db_path
        self._engine = RepresentationEngine(db_path, config or RTFConfig())
        self._engine.conn.execute(_SOURCE_DDL)
        self._engine.conn.commit()
        self._texts = [row[0] for row in self._engine.conn.execute(
            "SELECT s.content FROM document_source s "
            "JOIN document d ON d.document_id = s.document_id "
            "ORDER BY s.document_id")]

    @property
    def engine(self) -> RepresentationEngine:
        return self._engine

    @staticmethod
    def detect_language(text: str) -> str:
        try:
            from .parsing import detect_domain
            return detect_domain(text)
        except Exception:
            return "text"

    @classmethod
    def language_for_file(cls, path, language: str | None = None) -> str:
        if language and language != "auto":
            return language
        by_ext = EXT_LANGUAGES.get(Path(path).suffix.casefold())
        if by_ext:
            return by_ext
        text = Path(path).read_text(encoding="utf-8", errors="ignore")
        return cls.detect_language(text)

    def add_text(self, text: str, language: str = "auto",
                 source_name: str | None = None) -> IngestionReport:
        if language == "auto":
            language = self.detect_language(text)
        report = self._engine.ingest(
            text, language=language,
            source_name=source_name or f"{language}:{sha256(text.encode('utf-8')).hexdigest()[:12]}")
        if not report.duplicate_document:
            self._engine.conn.execute(
                "INSERT OR IGNORE INTO document_source(document_id, content) "
                "VALUES (?, ?)", (report.document_id, text))
            self._engine.conn.commit()
            self._texts.append(text)
        return report

    def add_file(self, path, language: str | None = None) -> IngestionReport:
        path = Path(path)
        text = path.read_text(encoding="utf-8", errors="ignore")
        return self.add_text(text,
                             language=self.language_for_file(path, language),
                             source_name=f"{path.name}")

    def add_dir(self, path, language: str | None = None) -> list[IngestionReport]:
        reports = []
        for child in sorted(Path(path).rglob("*")):
            if child.is_file():
                reports.append(self.add_file(child, language))
        return reports

    def add_batch(self, items, language: str = "auto",
                  commit_every: int = 500, progress=None) -> dict:
        """Ingest many items with periodic commits and progress reports.

        items: iterable of text, or of (text, language[, source_name]) tuples.
        Designed for large corpora on a FILE-backed database: every document
        is durable after its own ingest, and commit_every bounds the transaction
        window. progress, when given, is called as progress(done, summary).
        """
        summary = {"added": 0, "duplicates": 0, "occurrences": 0,
                   "rejected_atoms": 0, "unresolved": 0}
        done = 0
        for done, item in enumerate(items, start=1):
            if isinstance(item, (tuple, list)):
                text = item[0]
                lang = item[1] if len(item) > 1 else language
                name = item[2] if len(item) > 2 else None
            else:
                text, lang, name = item, language, None
            report = self.add_text(text, language=lang, source_name=name)
            if report.duplicate_document:
                summary["duplicates"] += 1
            else:
                summary["added"] += 1
                summary["occurrences"] += report.occurrences_recorded
                summary["rejected_atoms"] += len(report.rejections)
                summary["unresolved"] += len(report.unresolved)
            if done % commit_every == 0:
                self.commit()
                if progress is not None:
                    progress(done, dict(summary))
        self.commit()
        if progress is not None:
            progress(done, dict(summary))
        return summary

    def commit(self) -> None:
        self._engine.conn.commit()

    def snapshot(self, path) -> str:
        """Fast online copy of a FILE-backed database (no memory doubling).

        Unlike save() from :memory:, this copies file to file, so it stays
        cheap at any corpus size. Use for periodic safety copies during
        long ingestions.
        """
        self.commit()
        target = sqlite3.connect(str(path))
        with target:
            self._engine.conn.backup(target)
        target.close()
        return str(path)

    def fit_tokenizer(self, kind: str = "structured") -> RTFTokenizer:
        tok = RTFTokenizer(kind=kind, conn=self._engine.conn)
        if kind == "char":
            return tok.fit_texts(self._texts)
        return tok.fit()

    def encode(self, text: str, language: str = "auto",
               kind: str = "structured") -> list[int]:
        report = self.add_text(text, language=language)
        return self.fit_tokenizer(kind).encode_document(report.document_id)

    def decode(self, ids: list[int], kind: str = "structured") -> list[str]:
        return self.fit_tokenizer(kind).decode(ids)

    def streams(self):
        return _rep.build_streams(self._engine, self._texts)

    def relationships(self, tag: str):
        from .cross_domain import RelationshipGraph

        return RelationshipGraph().outgoing(tag)

    def check_relation(self, subj=None, rel=None, obj=None):
        from .cross_domain import DeterministicExecutor

        return DeterministicExecutor().check(subj=subj, rel=rel, obj=obj)

    def respond_relation(self, subj=None, rel=None, obj=None) -> list[str]:
        from .cross_domain import DeterministicExecutor

        return DeterministicExecutor().respond(subj=subj, rel=rel, obj=obj)

    def stats(self) -> dict:
        conn = self._engine.conn
        count = lambda table: int(
            conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
        return {"tags": count("tag_registry"), "rows": count("row_registry"),
                "values": count("value_registry"),
                "cells": count("cell_registry"),
                "documents": count("document"),
                "occurrences": count("occurrence"),
                "structures": count("structural_element")}

    def validate(self):
        return self._engine.validate()

    def export_json(self, path) -> str:
        return self._engine.export_json(path)

    def export_matrix_xlsx(self, path) -> str:
        return self._engine.export_matrix_xlsx(path)

    def save(self, path) -> str:
        """Snapshot an in-memory database to a file.

        For large corpora, construct RTF(file_path) up front and use
        snapshot() for safety copies instead: no giant in-memory build,
        no giant save.
        """
        self.commit()
        target = sqlite3.connect(str(path))
        with target:
            self._engine.conn.backup(target)
        target.close()
        return str(path)

    @classmethod
    def open(cls, path) -> "RTF":
        return cls(db_path=str(path))

    def close(self) -> None:
        self._engine.close()


__all__ = ["RTF", "EXT_LANGUAGES"]