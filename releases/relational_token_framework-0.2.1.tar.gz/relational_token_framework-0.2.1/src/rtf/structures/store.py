"""Structural element storage: higher-level COMPLETE representations.

A structural element references atomic occurrences as members; it never
duplicates them (spec sections 8-13, 23). Elements may nest via child
element links, giving CONDITION -> THEN_BRANCH / ELSE_BRANCH trees.
"""

from __future__ import annotations

from ..core.codes import format_element_code


class StructureStore:
    def __init__(self, conn) -> None:
        self._conn = conn

    def create_element(self, document_id: int, kind: str, role: str,
                       parent_id: int | None) -> int:
        element_id = int(self._conn.execute(
            "SELECT COALESCE(MAX(element_id), 0) + 1 FROM structural_element").fetchone()[0])
        self._conn.execute(
            "INSERT INTO structural_element(element_id, element_code, document_id, kind, role, parent_id) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (element_id, format_element_code(element_id), document_id, kind, role, parent_id),
        )
        return element_id

    def add_member(self, element_id: int, position: int, role: str,
                   child_element_id: int | None = None,
                   child_occurrence_id: int | None = None) -> int:
        cursor = self._conn.execute(
            "INSERT INTO structural_member(element_id, position, role, child_element_id, child_occurrence_id) "
            "VALUES (?, ?, ?, ?, ?)",
            (element_id, position, role, child_element_id, child_occurrence_id),
        )
        return int(cursor.lastrowid)

    def elements_for_document(self, document_id: int) -> list[dict]:
        rows = self._conn.execute(
            "SELECT e.element_id, e.element_code, e.kind, e.role, e.parent_id "
            "FROM structural_element e WHERE e.document_id = ? ORDER BY e.element_id",
            (document_id,),
        ).fetchall()
        return [
            {"element_id": int(r[0]), "element_code": r[1], "kind": r[2],
             "role": r[3], "parent_id": int(r[4]) if r[4] is not None else None}
            for r in rows
        ]

    def members_of(self, element_id: int) -> list[dict]:
        rows = self._conn.execute(
            """
            SELECT m.position, m.role,
                   m.child_element_id, m.child_occurrence_id,
                   se.kind, se.element_code,
                   v.value_string, vr.row_code
            FROM structural_member m
            LEFT JOIN structural_element se ON se.element_id = m.child_element_id
            LEFT JOIN occurrence o ON o.occurrence_id = m.child_occurrence_id
            LEFT JOIN value_registry v ON v.value_id = o.value_id
            LEFT JOIN row_registry vr ON vr.row_id = o.row_id
            WHERE m.element_id = ?
            ORDER BY m.position
            """,
            (element_id,),
        ).fetchall()
        return [
            {
                "position": int(r[0]), "role": r[1],
                "child_element_id": int(r[2]) if r[2] is not None else None,
                "child_occurrence_id": int(r[3]) if r[3] is not None else None,
                "child_kind": r[4], "child_code": r[5],
                "value_string": r[6], "concept": r[7],
            }
            for r in rows
        ]
