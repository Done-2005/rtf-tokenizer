"""Integrity validation of a persisted RTF-V5 database (spec sections 30-31)."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Finding:
    status: str      # PASS | FAIL
    code: str
    detail: str

    def __str__(self) -> str:  # pragma: no cover - display helper
        return f"[{self.status}] {self.code}: {self.detail}"


class Validator:
    def __init__(self, conn) -> None:
        self._conn = conn

    def run(self) -> list[Finding]:
        findings: list[Finding] = []

        # F001 unique permanent codes
        dup_codes = self._conn.execute(
            "SELECT COUNT(*) FROM (SELECT tag_code FROM tag_registry "
            "INTERSECT SELECT row_code FROM row_registry)"
        ).fetchone()[0]
        findings.append(Finding("PASS" if dup_codes == 0 else "FAIL",
                                "F001_CODE_NAMESPACES", "registry code namespaces disjoint"))

        # F002 every MAPPED occurrence references an existing cell
        orphans = self._conn.execute(
            """
            SELECT COUNT(*) FROM occurrence o
            WHERE o.status = 'MAPPED' AND (
                o.cell_id IS NULL OR NOT EXISTS
                (SELECT 1 FROM cell_registry c WHERE c.cell_id = o.cell_id))
            """
        ).fetchone()[0]
        findings.append(Finding("PASS" if orphans == 0 else "FAIL",
                                "F002_OCCURRENCE_CELL_LINK", f"{orphans} orphaned mapped occurrences"))

        # F003 no fabricated rows: rows are SEED, AUTO-flagged, or mapped by ledger
        unmapped_rows = self._conn.execute(
            """
            SELECT COUNT(*) FROM row_registry r
            WHERE r.origin = 'AUTO'
              AND NOT EXISTS (SELECT 1 FROM semantic_mapping m WHERE m.row_id = r.row_id)
            """
        ).fetchone()[0]
        findings.append(Finding("PASS" if unmapped_rows == 0 else "FAIL",
                                "F003_ROW_TRACEABILITY", f"{unmapped_rows} auto rows without ledger entry"))

        # F004 cell triple uniqueness holds under insert policy
        triples = self._conn.execute(
            "SELECT COUNT(*) FROM (SELECT tag_id, row_id, value_id, COUNT(*) n "
            "FROM cell_registry GROUP BY tag_id, row_id, value_id HAVING n > 1)"
        ).fetchone()[0]
        findings.append(Finding("PASS" if triples == 0 else "FAIL",
                                "F004_CELL_TRIPLE_UNIQUE", f"{triples} duplicate triples"))

        # F005 structural members reference exactly one target
        bad_members = self._conn.execute(
            """
            SELECT COUNT(*) FROM structural_member
            WHERE (child_element_id IS NULL AND child_occurrence_id IS NULL)
               OR (child_element_id IS NOT NULL AND child_occurrence_id IS NOT NULL)
            """
        ).fetchone()[0]
        findings.append(Finding("PASS" if bad_members == 0 else "FAIL",
                                "F005_MEMBER_TARGETS", f"{bad_members} malformed member links"))

        # F006 occurrence positions contiguous per document (documents with
        # zero occurrences - e.g. fully rejected sources - are skipped)
        docs_with_occurrences = self._conn.execute(
            "SELECT COUNT(DISTINCT document_id) FROM occurrence").fetchone()[0]
        checked = self._conn.execute(
            """
            SELECT COUNT(DISTINCT document_id) FROM (
                SELECT document_id,
                       ROW_NUMBER() OVER (PARTITION BY document_id ORDER BY position) - 1 AS expect,
                       position
                FROM occurrence)
            WHERE expect = position
            """
        ).fetchone()[0]
        gaps = docs_with_occurrences - checked
        findings.append(Finding("PASS" if gaps == 0 else "FAIL",
                                "F006_POSITION_CONTIGUITY", f"{gaps} documents with position gaps"))
        return findings

    def require_pass(self) -> None:
        from ..core.errors import ValidationFailure

        findings = self.run()
        failed = [f for f in findings if f.status != "PASS"]
        if failed:
            raise ValidationFailure(failed)
