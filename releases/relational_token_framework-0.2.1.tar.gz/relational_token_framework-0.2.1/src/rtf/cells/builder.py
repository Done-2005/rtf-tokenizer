"""Cell builder: CELL = TAG x ROW -> VALUE with UNIQUE(tag,row,value).

One semantic ROW may legitimately contain many atomic VALUES
(e.g. Conditional Logic + if / elif / else) (spec sections 6, 28).
"""

from __future__ import annotations

from dataclasses import dataclass

from ..atomic.rules import is_atomic
from ..core.codes import format_cell_code
from ..core.errors import NonAtomicValueError


@dataclass
class CellOutcome:
    status: str            # 'created' | 'duplicate'
    cell_id: int | None
    value_created: bool = False


class CellBuilder:
    def __init__(self, conn, values) -> None:
        self._conn = conn
        self.values = values

    def build(self, tag_id: int, row_id: int, discriminator: str | None,
              literal: str) -> CellOutcome:
        if not is_atomic(literal):
            raise NonAtomicValueError(
                literal, f"atomicity violation: {literal!r} is not a single scalar token")
        value_id, value_created = self.values.get_or_register(literal)
        # `IS` rather than `=`: SQL `=` never matches NULL, so `=` would miss an
        # existing NULL-discriminator cell and insert a duplicate every time.
        existing = self._conn.execute(
            "SELECT cell_id FROM cell_registry WHERE tag_id = ? AND row_id = ? "
            "AND discriminator IS ? AND value_id = ?",
            (tag_id, row_id, discriminator, value_id),
        ).fetchone()
        if existing is not None:
            return CellOutcome("duplicate", int(existing[0]), value_created)
        cell_id = int(
            self._conn.execute("SELECT COALESCE(MAX(cell_id), 0) + 1 FROM cell_registry").fetchone()[0]
        )
        self._conn.execute(
            "INSERT INTO cell_registry(cell_id, cell_code, tag_id, row_id, discriminator, value_id) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (cell_id, format_cell_code(cell_id), tag_id, row_id, discriminator, value_id),
        )
        return CellOutcome("created", cell_id, value_created)

    def get(self, cell_id: int):
        row = self._conn.execute(
            "SELECT c.cell_id, c.cell_code, c.discriminator, t.qualified_name, r.canonical_name, v.value_string "
            "FROM cell_registry c "
            "JOIN tag_registry t ON t.tag_id = c.tag_id "
            "JOIN row_registry r ON r.row_id = c.row_id "
            "JOIN value_registry v ON v.value_id = c.value_id "
            "WHERE c.cell_id = ?",
            (cell_id,),
        ).fetchone()
        if row is None:
            return None
        return {
            "cell_id": int(row[0]), "cell_code": row[1], "discriminator": row[2],
            "tag": row[3], "row_concept": row[4], "value_string": row[5],
        }
