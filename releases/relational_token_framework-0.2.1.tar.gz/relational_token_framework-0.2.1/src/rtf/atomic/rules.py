from __future__ import annotations

import re

# An atomic value is a single scalar token. Grammar-defined literals
# (quoted strings) may remain atomic per spec section 7.
_SCALAR = re.compile(r"^[^\s{};]{1,64}$")
_QUOTED = re.compile(r'^"[^"\n]{0,62}"$|^\x27[^\x27\n]{0,62}\x27$')


def is_atomic(value: str) -> bool:
    if not value:
        return False
    if _QUOTED.fullmatch(value):
        return True
    return bool(_SCALAR.fullmatch(value)) and any(ch.isalnum() or not ch.isspace() for ch in value)
