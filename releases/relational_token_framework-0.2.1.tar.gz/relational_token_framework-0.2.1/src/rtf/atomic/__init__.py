from .rules import is_atomic

__all__ = ["is_atomic"]
