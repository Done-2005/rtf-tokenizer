"""Training-ready representation streams (stdlib only).

Builds the two aligned streams over the same corpus: the conventional
character stream (control condition) and the structured [T,R,V] stream
(the RTF representation), with window chunking for language-model
training. Vocabularies are plain dicts, so they serialize to JSON for
the Kaggle / cluster training bundle.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

WINDOW = 160
SPLIT = 0.8


@dataclass
class Window:
    ids: list
    loss_start: int = 1


def build_streams(engine, raw_sources: list[str]):
    char_vocab: dict[str, int] = {"<pad>": 0, "<unk>": 1, "<eos>": 2}
    char_stream: list[int] = []
    for source in raw_sources:
        for ch in source:
            if ch not in char_vocab:
                char_vocab[ch] = len(char_vocab)
            char_stream.append(char_vocab[ch])
    char_stream.append(char_vocab["<eos>"])

    struct_vocab: dict[str, int] = {"<pad>": 0, "<unk>": 1, "<eos>": 2}
    struct_stream: list[int] = []
    for tag_code, row_code, value_string in engine.conn.execute(
        """
        SELECT t.tag_code, r.row_code, v.value_string
        FROM occurrence o
        JOIN tag_registry t ON t.tag_id = o.tag_id
        LEFT JOIN row_registry r ON r.row_id = o.row_id
        LEFT JOIN value_registry v ON v.value_id = o.value_id
        WHERE o.status IN ('MAPPED','DELIMITER')
        ORDER BY o.occurrence_id
        """
    ):
        for symbol in (f"T:{tag_code}",
                       f"R:{row_code}" if row_code else None,
                       f"V:{value_string}" if value_string else None):
            if symbol is None:
                continue
            if symbol not in struct_vocab:
                struct_vocab[symbol] = len(struct_vocab)
            struct_stream.append(struct_vocab[symbol])
    struct_stream.append(struct_vocab["<eos>"])
    return char_stream, struct_stream, char_vocab, struct_vocab


def chunk(stream: list[int], size: int = WINDOW) -> list[Window]:
    return [Window(stream[i:i + size])
            for i in range(0, len(stream), size)]


def split(stream: list[int], split_frac: float = SPLIT) -> tuple[list[int], list[int]]:
    point = int(len(stream) * split_frac)
    return stream[:point], stream[point:]


def save_json(path, data) -> None:
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(data, handle)


def load_json(path) -> Any:
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


__all__ = ["Window", "build_streams", "chunk", "split", "save_json",
           "load_json", "WINDOW", "SPLIT"]