"""Permanent registration: one global, monotonic id space (0.1.6).

Ported behavior from the verified method registries (registries/tags.py,
rows.py, values.py) expressed as a DB-free, JSON-serialisable counter.

The verified invariant: TAG, ROW, VALUE and CELL ids come from ONE
global monotonic counter and are NEVER restarted or reused, so a given
integer uniquely identifies one registered entity across every domain in
a corpus (e.g. a value may share its id space with tags and rows).

    Registration is NOT the neural index and NOT the tokenizer stoi:
    it is the permanent identity layer. The tokenizer stoi is learned
    from a corpus; Registration is registered once and persisted.

    >>> reg = Registration()
    >>> reg.tag_id("PYTHON")          # 1
    >>> reg.tag_id("MATH")            # 2
    >>> reg.row_id("INTEGER_LITERAL") # 3  (shared by python and math)
    >>> reg.row_id("INTEGER_LITERAL") # 3  (deduplicated, no reuse)
    >>> reg.value_id("x")             # 4
    >>> t, r, v, c = reg.cell("PYTHON", "INTEGER_LITERAL", "x")
"""

from __future__ import annotations

import json

KINDS_OF_ID = ("tag", "row", "value", "cell")


class Registration:
    """Global monotonic TAG/ROW/VALUE/CELL registry (permanent ids)."""

    def __init__(self) -> None:
        self._counter = 0
        self._tags: dict[str, int] = {}      # tag name -> id
        self._rows: dict[str, int] = {}      # row name -> id (global)
        self._values: dict[str, int] = {}    # value text -> id (global)
        self._cells: dict[tuple[int, int, int], int] = {}  # (t,r,v) -> id
        self._id_to_tag: dict[int, str] = {}
        self._id_to_row: dict[int, str] = {}
        self._id_to_value: dict[int, str] = {}

    def _next_id(self) -> int:
        self._counter += 1
        return self._counter

    def _ensure_monotonic(self, loaded: int) -> None:
        if loaded > self._counter:
            self._counter = loaded

    def tag_id(self, name: str) -> int:
        name = str(name)
        if name in self._tags:
            return self._tags[name]
        new_id = self._next_id()
        self._tags[name] = new_id
        self._id_to_tag[new_id] = name
        return new_id

    def row_id(self, name: str) -> int:
        name = str(name)
        if name in self._rows:
            return self._rows[name]
        new_id = self._next_id()
        self._rows[name] = new_id
        self._id_to_row[new_id] = name
        return new_id

    def value_id(self, value: str) -> int:
        value = str(value)
        if value in self._values:
            return self._values[value]
        new_id = self._next_id()
        self._values[value] = new_id
        self._id_to_value[new_id] = value
        return new_id

    def cell_id(self, tag_id: int, row_id: int, value_id: int) -> int:
        key = (tag_id, row_id, value_id)
        if key in self._cells:
            return self._cells[key]
        new_id = self._next_id()
        self._cells[key] = new_id
        return new_id

    def cell(self, tag: str, row: str, value: str) -> tuple[int, int, int, int]:
        """Register (or fetch) a full (TAG, ROW, VALUE) cell identity."""
        t = self.tag_id(tag)
        r = self.row_id(row)
        v = self.value_id(value)
        return t, r, v, self.cell_id(t, r, v)

    @property
    def max_id(self) -> int:
        return self._counter

    @property
    def tags(self) -> dict[str, int]:
        return dict(self._tags)

    @property
    def rows(self) -> dict[str, int]:
        return dict(self._rows)

    @property
    def values(self) -> dict[str, int]:
        return dict(self._values)

    @property
    def cells(self) -> dict[tuple[int, int, int], int]:
        return dict(self._cells)

    def tag_name(self, tag_id: int) -> str | None:
        return self._id_to_tag.get(tag_id)

    def row_name(self, row_id: int) -> str | None:
        return self._id_to_row.get(row_id)

    def value_text(self, value_id: int) -> str | None:
        return self._id_to_value.get(value_id)

    def save(self, path) -> str:
        data = {
            "counter": self._counter,
            "tags": self._tags,
            "rows": self._rows,
            "values": self._values,
            "cells": {f"{t},{r},{v}": c for (t, r, v), c in self._cells.items()},
        }
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(data, handle, ensure_ascii=False, sort_keys=True)
        return str(path)

    @classmethod
    def load(cls, path) -> "Registration":
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        reg = cls()
        reg._counter = int(data.get("counter", 0))
        reg._tags = {str(k): int(v) for k, v in data.get("tags", {}).items()}
        reg._rows = {str(k): int(v) for k, v in data.get("rows", {}).items()}
        reg._values = {str(k): int(v) for k, v in data.get("values", {}).items()}
        cells = {}
        for key, cell_id in data.get("cells", {}).items():
            t, r, v = (int(part) for part in key.split(","))
            cells[(t, r, v)] = int(cell_id)
        reg._cells = cells
        reg._id_to_tag = {v: k for k, v in reg._tags.items()}
        reg._id_to_row = {v: k for k, v in reg._rows.items()}
        reg._id_to_value = {v: k for k, v in reg._values.items()}
        # Never restart: keep the counter at or above any id seen.
        seen = [reg._counter]
        seen += list(reg._tags.values()) + list(reg._rows.values())
        seen += list(reg._values.values()) + list(reg._cells.values())
        reg._ensure_monotonic(max(seen))
        return reg


__all__ = ["Registration", "KINDS_OF_ID"]