"""Copy-3 canonical architecture: compressed shared embedding + tied head.

Requires torch: install with the torch extra
(`pip install relational-token-framework[torch]`). Importing THIS MODULE
never requires torch; only instantiating the model does, with an explicit
error message when torch is missing.

The vocabulary is stored ONCE in a small shared base space (d_shared)
and projected to the transformer hidden dimension; logits are computed
through the SAME shared weight, so the output head is never duplicated.
Downstream transformer blocks are byte-identical to the frozen baseline.
"""

from __future__ import annotations

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F

    _TORCH_AVAILABLE = True
except ImportError:
    _TORCH_AVAILABLE = False


def _require_torch() -> None:
    if not _TORCH_AVAILABLE:
        raise ImportError(
            "the Copy-3 architecture requires torch: "
            "pip install relational-token-framework[torch]")


if _TORCH_AVAILABLE:
    class Copy3TinyTransformer(nn.Module):
        def __init__(self, vocab_size: int, d_model: int = 64,
                     n_layers: int = 2, n_heads: int = 2, ffn: int = 128,
                     max_len: int = 256, pad_id: int = 0,
                     d_shared: int = 16) -> None:
            super().__init__()
            self.pad_id = pad_id
            self.max_len = max_len
            self.emb = nn.Embedding(vocab_size, d_shared)
            self.proj = nn.Linear(d_shared, d_model)
            self.pos = nn.Embedding(max_len, d_model)
            layer = nn.TransformerEncoderLayer(
                d_model=d_model, nhead=n_heads, dim_feedforward=ffn,
                dropout=0.1, batch_first=True, norm_first=True)
            self.blocks = nn.TransformerEncoder(layer, num_layers=n_layers)
            self.norm = nn.LayerNorm(d_model)

        def embed(self, ids) -> "torch.Tensor":
            return self.proj(self.emb(ids))

        def logits(self, hidden) -> "torch.Tensor":
            w = self.emb.weight @ self.proj.weight.t()
            return F.linear(hidden, w, None)

        def forward(self, ids) -> "torch.Tensor":
            length = ids.size(1)
            positions = torch.arange(length, device=ids.device)
            hidden = self.embed(ids) + self.pos(positions)[None]
            causal = torch.triu(
                torch.ones(length, length, device=ids.device,
                           dtype=torch.bool), diagonal=1)
            hidden = self.blocks(hidden, mask=causal, is_causal=True,
                                 src_key_padding_mask=ids.eq(self.pad_id))
            return self.logits(self.norm(hidden))

    TinyTransformer = Copy3TinyTransformer

    def count_parameters(model) -> int:
        return sum(p.numel() for p in model.parameters()
                   if p.requires_grad)

    def save_checkpoint(model, vocab: dict, config: dict, path) -> str:
        torch.save({"model_state": model.state_dict(), "vocab": vocab,
                    "config": config}, str(path))
        return str(path)

    def load_checkpoint(path, **overrides):
        payload = torch.load(str(path), map_location="cpu",
                             weights_only=True)
        config = dict(payload["config"])
        config.update(overrides)
        model = Copy3TinyTransformer(len(payload["vocab"]), **config)
        model.load_state_dict(payload["model_state"])
        model.eval()
        return model, payload["vocab"], config
else:
    class Copy3TinyTransformer:
        def __init__(self, *args, **kwargs) -> None:
            _require_torch()

    TinyTransformer = Copy3TinyTransformer

    def count_parameters(model) -> int:
        _require_torch()

    def save_checkpoint(model, vocab: dict, config: dict, path) -> str:
        _require_torch()

    def load_checkpoint(path, **overrides):
        _require_torch()


__all__ = ["Copy3TinyTransformer", "TinyTransformer", "count_parameters",
           "save_checkpoint", "load_checkpoint"]