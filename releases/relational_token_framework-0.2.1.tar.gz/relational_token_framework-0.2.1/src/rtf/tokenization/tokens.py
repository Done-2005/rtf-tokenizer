"""RTF tokenizer interfaces for model integration (spec sections 22-23, 32-33).

Three coexisting representations, none assumed superior:

  ConventionalTokenizer - char-level baseline (control condition)
  StructuredTokenizer   - [T:TAG, R:ROW, V:VALUE] triple per occurrence
  CombinedTokenizer     - one reversible integer per (TAG,ROW,VALUE) fact
  StructuralTokenizer   - higher-level structural element tokens wrapping
                          atomic streams (structure-kind vocabulary)

All expose fit/encode and keep the relational address recoverable.
"""

from __future__ import annotations

import sqlite3

from .addresses import combine_address, decompose_address
from .codec import decode_composite, encode_composite

PAD = "<pad>"
UNK = "<unk>"
EOS = "<eos>"
SPECIALS = [PAD, UNK, EOS]


def _build_vocab(symbols):
    itos = list(SPECIALS)
    seen = set(itos)
    for symbol in symbols:
        if symbol not in seen:
            itos.append(symbol)
            seen.add(symbol)
    stoi = {s: i for i, s in enumerate(itos)}
    return stoi, itos


class ConventionalTokenizer:
    """Char-level control baseline over raw source text."""

    kind = "conventional_char"

    def __init__(self) -> None:
        self._stoi: dict[str, int] = {}
        self._itos: list[str] = []

    def fit(self, texts: list[str]) -> "ConventionalTokenizer":
        self._stoi, self._itos = _build_vocab(sorted({ch for t in texts for ch in t}))
        return self

    @property
    def vocab_size(self) -> int:
        return len(self._itos)

    def encode(self, text: str) -> list[int]:
        return [self._stoi.get(ch, 1) for ch in text] + [self._stoi[EOS]]


class StructuredTokenizer:
    """Experiment B: three factorized tokens per occurrence."""

    kind = "rtf_structured"

    def __init__(self, conn: sqlite3.Connection) -> None:
        self._conn = conn
        self._stoi: dict[str, int] = {}
        self._itos: list[str] = []

    def fit_from_db(self) -> "StructuredTokenizer":
        tag_syms = {f"T:{r[0]}" for r in self._conn.execute("SELECT tag_code FROM tag_registry")}
        row_syms = {f"R:{r[0]}" for r in self._conn.execute("SELECT row_code FROM row_registry")}
        val_syms = {f"V:{r[0]}" for r in self._conn.execute("SELECT value_string FROM value_registry")}
        symbols = (list(SPECIALS) + sorted(tag_syms) + sorted(row_syms) + sorted(val_syms))
        self._itos = symbols
        self._stoi = {s: i for i, s in enumerate(symbols)}
        return self

    @property
    def vocab_size(self) -> int:
        return len(self._itos)

    def encode_document(self, document_id: int) -> list[int]:
        unk = self._stoi[UNK]
        out: list[int] = []
        for row in self._conn.execute(
            """
            SELECT t.tag_code, r.row_code, v.value_string
            FROM occurrence o
            JOIN tag_registry t ON t.tag_id = o.tag_id
            LEFT JOIN row_registry r ON r.row_id = o.row_id
            LEFT JOIN value_registry v ON v.value_id = o.value_id
            WHERE o.document_id = ? AND o.status IN ('MAPPED','DELIMITER')
            ORDER BY o.position
            """,
            (document_id,),
        ):
            tag_code, row_code, value_string = row
            out.append(self._stoi.get(f"T:{tag_code}", unk))
            if row_code is not None:
                out.append(self._stoi.get(f"R:{row_code}", unk))
            if value_string is not None:
                out.append(self._stoi.get(f"V:{value_string}", unk))
        out.append(self._stoi[EOS])
        return out


class CombinedTokenizer:
    """Experiment A: one vocabulary entry per unique (TAG|ROW|VALUE) fact.

    Every entry keeps its numeric relational address; token ids decode back.
    """

    kind = "rtf_combined"

    def __init__(self, conn: sqlite3.Connection) -> None:
        self._conn = conn
        self._stoi: dict[str, int] = {}
        self._itos: list[str] = []
        self.addresses: dict[int, tuple[int, int, int]] = {}

    def fit_from_db(self) -> "CombinedTokenizer":
        composites = {
            encode_composite(t, r, v)
            for t, r, v in self._conn.execute(
                """
                SELECT tr.tag_code, rr.row_code, vr.value_string
                FROM cell_registry c
                JOIN tag_registry tr ON tr.tag_id = c.tag_id
                JOIN row_registry rr ON rr.row_id = c.row_id
                JOIN value_registry vr ON vr.value_id = c.value_id
                """
            )
        }
        self._stoi, self._itos = _build_vocab(sorted(composites))
        self.attach_addresses()
        return self

    def attach_addresses(self) -> None:
        tags = dict(self._conn.execute("SELECT tag_code, tag_id FROM tag_registry"))
        rows = dict(self._conn.execute("SELECT row_code, row_id FROM row_registry"))
        values = dict(self._conn.execute("SELECT value_string, value_id FROM value_registry"))
        self.addresses.clear()
        for token_id, symbol in enumerate(self._itos):
            decoded = decode_composite(symbol)
            if decoded is None:
                continue
            t, r, v = decoded
            if t in tags and r in rows and v in values:
                self.addresses[token_id] = combine_address(tags[t], rows[r], values[v])

    @property
    def vocab_size(self) -> int:
        return len(self._itos)

    def address_of(self, token_id: int) -> tuple[int, int, int] | None:
        return self.addresses.get(token_id)

    def decode(self, token_id: int) -> str:
        return self._itos[token_id]

    def encode_document(self, document_id: int) -> list[int]:
        unk = self._stoi[UNK]
        out: list[int] = []
        for row in self._conn.execute(
            """
            SELECT t.tag_code, r.row_code, v.value_string, o.status
            FROM occurrence o
            JOIN tag_registry t ON t.tag_id = o.tag_id
            LEFT JOIN row_registry r ON r.row_id = o.row_id
            LEFT JOIN value_registry v ON v.value_id = o.value_id
            WHERE o.document_id = ? AND o.status IN ('MAPPED','DELIMITER')
            ORDER BY o.position
            """,
            (document_id,),
        ):
            tag_code, row_code, value_string, _status = row
            symbol = encode_composite(tag_code, row_code, value_string)
            out.append(self._stoi.get(symbol, unk))
        out.append(self._stoi[EOS])
        return out


class StructuralTokenizer:
    """Higher-level representation: structure markers interleave with atoms.

    Encoding walks each document's structural_element forest depth-first and
    emits STRUCT_OPEN:<KIND> ... members ... STRUCT_CLOSE:<KIND> at every
    subtree boundary, so nesting (CONDITION inside CONDITIONAL_EXPRESSION,
    BODY inside FUNCTION_DECLARATION, ...) is visible to attention directly
    (spec section 23). Members resolve to structured T/R/V triple tokens;
    mapped occurrences not referenced by any structure are appended in
    position order so the encoding always covers the full atom stream.
    """

    kind = "rtf_structural"

    def __init__(self, conn: sqlite3.Connection) -> None:
        self._conn = conn
        self._stoi: dict[str, int] = {}
        self._itos: list[str] = []

    def fit_from_db(self) -> "StructuralTokenizer":
        kinds = sorted({r[0] for r in self._conn.execute(
            "SELECT DISTINCT kind FROM structural_element")})
        tag_syms = sorted(f"T:{r[0]}" for r in self._conn.execute(
            "SELECT tag_code FROM tag_registry"))
        row_syms = sorted(f"R:{r[0]}" for r in self._conn.execute(
            "SELECT row_code FROM row_registry"))
        val_syms = sorted(f"V:{r[0]}" for r in self._conn.execute(
            "SELECT value_string FROM value_registry"))
        symbols: list[str] = list(SPECIALS)
        symbols += [f"STRUCT_OPEN:{k}" for k in kinds]
        symbols += [f"STRUCT_CLOSE:{k}" for k in kinds]
        symbols += tag_syms + row_syms + val_syms
        seen: set[str] = set()
        itos: list[str] = []
        for symbol in symbols:
            if symbol not in seen:
                seen.add(symbol)
                itos.append(symbol)
        self._itos = itos
        self._stoi = {s: i for i, s in enumerate(itos)}
        return self

    def _fit_if_needed(self) -> None:
        if not self._itos:
            self.fit_from_db()

    @property
    def vocab_size(self) -> int:
        self._fit_if_needed()
        return len(self._itos)

    def vocab(self) -> list[str]:
        self._fit_if_needed()
        return list(self._itos)

    def _atom_triples(self, document_id: int) -> tuple[dict[int, list[int]], dict[int, int]]:
        """occurrence_id -> token triple, and occurrence_id -> position."""
        unk = self._stoi[UNK]
        triples: dict[int, list[int]] = {}
        positions: dict[int, int] = {}
        for occ_id, position, tag_code, row_code, value_string in self._conn.execute(
            """
            SELECT o.occurrence_id, o.position, t.tag_code, r.row_code, v.value_string
            FROM occurrence o
            JOIN tag_registry t ON t.tag_id = o.tag_id
            LEFT JOIN row_registry r ON r.row_id = o.row_id
            LEFT JOIN value_registry v ON v.value_id = o.value_id
            WHERE o.document_id = ? AND o.status IN ('MAPPED','DELIMITER')
            ORDER BY o.position
            """,
            (document_id,),
        ):
            toks = [self._stoi.get(f"T:{tag_code}", unk)]
            if row_code is not None:
                toks.append(self._stoi.get(f"R:{row_code}", unk))
            if value_string is not None:
                toks.append(self._stoi.get(f"V:{value_string}", unk))
            triples[int(occ_id)] = toks
            positions[int(occ_id)] = int(position)
        return triples, positions

    def encode_document(self, document_id: int) -> list[int]:
        from ..structures import StructureStore

        self._fit_if_needed()
        unk = self._stoi[UNK]
        eos = self._stoi[EOS]
        store = StructureStore(self._conn)

        triples, positions = self._atom_triples(document_id)
        elements = store.elements_for_document(document_id)
        if not elements:
            out: list[int] = []
            for occ_id in sorted(positions, key=positions.get):
                out.extend(triples[occ_id])
            out.append(eos)
            return out

        by_id = {e["element_id"]: e for e in elements}
        children_map: dict[int, list[dict]] = {}
        roots: list[dict] = []
        for e in elements:
            if e["parent_id"] is None:
                roots.append(e)
            else:
                children_map.setdefault(e["parent_id"], []).append(e)

        out = []
        referenced: set[int] = set()

        def walk(element: dict) -> None:
            kind = element["kind"]
            out.append(self._stoi[f"STRUCT_OPEN:{kind}"])
            for member in store.members_of(element["element_id"]):
                if member["child_occurrence_id"] is not None:
                    occ_id = member["child_occurrence_id"]
                    if occ_id in triples:
                        out.extend(triples[occ_id])
                        referenced.add(occ_id)
                elif member["child_element_id"] is not None:
                    child = by_id.get(member["child_element_id"])
                    if child is not None:
                        walk(child)
            out.append(self._stoi[f"STRUCT_CLOSE:{kind}"])

        for root in roots:
            walk(root)

        for occ_id in sorted((o for o in positions if o not in referenced),
                             key=positions.get):
            out.extend(triples[occ_id])
        out.append(eos)
        return out


__all__ = [
    "ConventionalTokenizer", "StructuredTokenizer", "CombinedTokenizer",
    "StructuralTokenizer", "combine_address", "decompose_address",
    "PAD", "UNK", "EOS",
]
