"""Five-domain metadata and the portable [T,R,V] atom tokenizer (0.1.6).

Domain set for the 0.1.6 Copy-3 training campaign:
    python, java, math, tool (function calling), english.

This module is the package-side port of the verified standalone Kaggle
tokenizer (kaggle/rtf_tokenizer.py) extended to the five domains above.
It is stdlib-only and DB-free: given raw text it produces the typed
atom stream (T:<tag> R:<concept> V:<value>) that the package tokenizer
maps to integer ids.

Tool (function) calls are NOT free text: they are structured
{"function": ..., "arguments": {...}} specs rendered through
tool_call_atoms() into the canonical representation:

    T:TOOL_CALL R:FUNCTION_NAME V:get_weather
    T:TOOL_CALL R:ARGUMENT_NAME  V:city
    T:TOOL_CALL R:ARGUMENT_VALUE V:Chennai

English prose uses R:WORD for content words so the trained stream stays
content-preserving (no fabricated relationships; plain vocabulary names).
"""

from __future__ import annotations

import re

# The five canonical domains for the 0.1.6 campaign.
DOMAINS = ["python", "java", "math", "tool", "english"]

# Tag symbol used for each domain in the T: slot.
TAGS = {
    "python": "PYTHON",
    "java": "JAVA",
    "math": "MATH",
    "tool": "TOOL_CALL",
    "english": "ENGLISH",
}

EXTS = {
    ".py": "python", ".pyw": "python",
    ".java": "java",
    ".tex": "math", ".math": "math",
    ".tool": "tool", ".tcall": "tool", ".functions": "tool",
    ".txt": "english", ".md": "english", ".csv": "english",
    ".json": "english", ".log": "english",
}

# Faithful port of the keyword tables from kaggle/rtf_tokenizer.py.
# python/java/rust/r/sql tables map a literal token to its ROW concept.
KEYWORDS = {
    "python": {"if": "CONDITIONAL_LOGIC", "elif": "CONDITIONAL_LOGIC",
               "else": "ELSE_BRANCH", "def": "FUNCTION_DECLARATION",
               "lambda": "FUNCTION_DECLARATION", "for": "LOOP_CONSTRUCT",
               "while": "LOOP_CONSTRUCT", "in": "RANGE_EXPRESSION",
               "class": "CLASS_DECLARATION", "import": "MODULE_IMPORT",
               "return": "RETURN_STATEMENT", "and": "BOOLEAN_OPERATOR",
               "or": "BOOLEAN_OPERATOR", "not": "BOOLEAN_OPERATOR",
               "True": "BOOLEAN_LITERAL", "False": "BOOLEAN_LITERAL",
               "print": "FUNCTION_CALL"},
    "java": {"if": "CONDITIONAL_LOGIC", "else": "ELSE_BRANCH",
             "for": "LOOP_CONSTRUCT", "while": "LOOP_CONSTRUCT",
             "do": "LOOP_CONSTRUCT", "switch": "CONDITIONAL_LOGIC",
             "case": "CONDITIONAL_LOGIC", "class": "CLASS_DECLARATION",
             "interface": "CLASS_DECLARATION", "enum": "CLASS_DECLARATION",
             "record": "CLASS_DECLARATION", "new": "FUNCTION_CALL",
             "return": "RETURN_STATEMENT", "import": "MODULE_IMPORT",
             "=": "ASSIGNMENT_STATEMENT", "<": "RELATIONAL_OPERATOR",
             ">": "RELATIONAL_OPERATOR", "<=": "RELATIONAL_OPERATOR",
             ">=": "RELATIONAL_OPERATOR", "==": "RELATIONAL_OPERATOR",
             "!=": "RELATIONAL_OPERATOR", "+": "ARITHMETIC_OPERATOR",
             "-": "ARITHMETIC_OPERATOR", "*": "ARITHMETIC_OPERATOR",
             "/": "ARITHMETIC_OPERATOR", "%": "ARITHMETIC_OPERATOR",
             "&&": "BOOLEAN_OPERATOR", "||": "BOOLEAN_OPERATOR",
             "!": "BOOLEAN_OPERATOR", "true": "BOOLEAN_LITERAL",
             "false": "BOOLEAN_LITERAL", "println": "FUNCTION_CALL",
             "printf": "FUNCTION_CALL"},
    "math": {"=": "RELATIONAL_OPERATOR", "<": "RELATIONAL_OPERATOR",
             ">": "RELATIONAL_OPERATOR", "<=": "RELATIONAL_OPERATOR",
             ">=": "RELATIONAL_OPERATOR", "!=": "RELATIONAL_OPERATOR",
             "==": "RELATIONAL_OPERATOR", "+": "ARITHMETIC_OPERATOR",
             "-": "ARITHMETIC_OPERATOR", "*": "ARITHMETIC_OPERATOR",
             "/": "ARITHMETIC_OPERATOR", "^": "ARITHMETIC_OPERATOR",
             "%": "ARITHMETIC_OPERATOR"},
    # Tool JSON keys map to their canonical R concepts so a raw tool
    # document still round-trips even before tool_call_atoms() is used.
    "tool": {"function": "FUNCTION_NAME", "name": "FUNCTION_NAME",
             "arguments": "ARGUMENTS", "argument": "ARGUMENT_NAME"},
    # English: grammar words keep a stable ROW so prose streams are
    # token-count efficient; content words fall through to R:WORD.
    "english": {"the": "DETERMINER", "a": "DETERMINER", "an": "DETERMINER",
                "this": "DETERMINER", "that": "DETERMINER", "these": "DETERMINER",
                "those": "DETERMINER", "is": "VERB_BE", "are": "VERB_BE",
                "was": "VERB_BE", "were": "VERB_BE", "be": "VERB_BE",
                "to": "INFINITIVE_PARTICLE", "of": "PREPOSITION",
                "in": "PREPOSITION", "on": "PREPOSITION", "at": "PREPOSITION",
                "for": "PREPOSITION", "with": "PREPOSITION", "by": "PREPOSITION",
                "from": "PREPOSITION", "and": "CONJUNCTION", "or": "CONJUNCTION",
                "but": "CONJUNCTION", "not": "NEGATION", "no": "NEGATION",
                "it": "PRONOUN", "he": "PRONOUN", "she": "PRONOUN", "we": "PRONOUN",
                "they": "PRONOUN", "you": "PRONOUN", "i": "PRONOUN"},
}

# Structural fallback used for any atom not covered above (symbols).
_DEFAULT_CONCEPT = "DELIMITER"
# Word fallback is domain-dependent: identifiers in code are
# VARIABLE_BINDING (verified kaggle behavior); prose words are WORD.
_WORD_FALLBACK = {
    "python": "VARIABLE_BINDING",
    "java": "VARIABLE_BINDING",
    "math": "VARIABLE_BINDING",
    "tool": "VARIABLE_BINDING",
    "english": "WORD",
}

_TOKEN_RE = re.compile(
    r"\"(?:[^\"\\]|\\.)*\"|'(?:[^'\\]|\\.)*'|\d+\.\d+|\d+"
    r"|[A-Za-z_][A-Za-z0-9_]*(?:'[A-Za-z0-9_]+)*"
    r"|==|!=|<=|>=|&&|\|\||%%|\.\.|->|::|<-|[^\s]")
_WORD_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*(?:'[A-Za-z0-9_]+)*")
_FLOAT_RE = re.compile(r"\d+\.\d+")
_INT_RE = re.compile(r"\d+")


def normalise(value) -> str:
    """Deterministic string rendering for V: slot values."""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return repr(value)
    if isinstance(value, (list, tuple)):
        return "[" + ",".join(normalise(v) for v in value) + "]"
    if isinstance(value, dict):
        return "{" + ",".join(f"{k}:{normalise(v)}"
                              for k, v in value.items()) + "}"
    return str(value)


def detect_domain(text: str, filename: str | None = None) -> str:
    """Best-effort domain detection over the five canonical domains.

    Deterministic keyword scoring; ties resolved in fixed order. Falls
    back to 'english' for prose and 'tool' for structured call specs.
    """
    if isinstance(text, dict):
        return "tool"
    if filename:
        ext = "." + filename.rsplit(".", 1)[-1] if "." in filename else ""
        if ext in EXTS:
            return EXTS[ext]
    head = text[:2000]
    scores = {"python": 0, "java": 0, "math": 0}
    scores["tool"] = 2 if re.search(r"\b(function|arguments)\s*:", head) else 0
    if re.search(r"\bdef\s+\w+\s*\(|^\s*import\s+\w+", head):
        scores["python"] += 3
    if re.search(r"\b(if|elif|for|while|print|range)\b", head):
        scores["python"] += 2
    if re.search(r"\bpublic\s+(class|static)\b|System\.out\.print", head):
        scores["java"] += 4
    if re.search(r"[\\]?(gt|leq|times|sum|int)_?|=\s*[0-9()+\-*/^]", head):
        scores["math"] += 2
    best = max(scores.items(), key=lambda kv: (kv[1], -list(scores).index(kv[0])))
    if best[1] > 0:
        return best[0]
    return "english"


def tokenize_text(text: str, language: str | None = None,
                  filename: str | None = None) -> tuple[str, list[tuple[str, str]]]:
    """Tokenize raw text into (concept, value) atoms for one domain."""
    if isinstance(text, dict):
        lang = "tool"
        atomic = tool_call_atoms(text)
        return lang, [(concept, value) for _t, concept, value in atomic]
    lang = language or detect_domain(text, filename)
    if lang not in TAGS:
        lang = "english"
    table = KEYWORDS.get(lang, {})
    atoms: list[tuple[str, str]] = []
    for m in _TOKEN_RE.finditer(text):
        token = m.group(0)
        if not token.strip():
            continue
        concept = table.get(token)
        if concept is not None:
            atoms.append((concept, token))
        elif len(token) > 1 and token[0] in "\"'" and token[-1] == token[0]:
            atoms.append(("STRING_LITERAL", token))
        elif _FLOAT_RE.fullmatch(token):
            atoms.append(("FLOAT_LITERAL", token))
        elif _INT_RE.fullmatch(token):
            atoms.append(("INTEGER_LITERAL", token))
        elif _WORD_RE.fullmatch(token):
            atoms.append((_WORD_FALLBACK.get(lang, "VARIABLE_BINDING"),
                          token))
        else:
            math_concept = KEYWORDS["math"].get(token)
            atoms.append((math_concept or _DEFAULT_CONCEPT, token))
    return lang, atoms


def tool_call_atoms(fn_call) -> list[tuple[str, str, str]]:
    """Canonical [T,R,V] representation of a function-call spec.

    fn_call is a dict with keys 'function' (or 'name') and 'arguments'
    (a mapping), or a list of such dicts (multi-tool order preserved).
    """
    calls = fn_call if isinstance(fn_call, list) else [fn_call]
    atoms: list[tuple[str, str, str]] = []
    for call in calls:
        if not isinstance(call, dict):
            continue
        name = call.get("function") or call.get("name", "")
        atoms.append(("TOOL_CALL", "FUNCTION_NAME", normalise(name)))
        arguments = call.get("arguments", {})
        if isinstance(arguments, dict):
            for arg_name, arg_value in arguments.items():
                atoms.append(("TOOL_CALL", "ARGUMENT_NAME",
                              normalise(arg_name)))
                atoms.append(("TOOL_CALL", "ARGUMENT_VALUE",
                              normalise(arg_value)))
        elif isinstance(arguments, list):
            for arg_value in arguments:
                atoms.append(("TOOL_CALL", "ARGUMENT_VALUE",
                              normalise(arg_value)))
        if "result" in call:
            atoms.append(("TOOL_CALL", "RESULT", normalise(call["result"])))
    return atoms


__all__ = ["DOMAINS", "TAGS", "EXTS", "KEYWORDS", "normalise",
           "detect_domain", "tokenize_text", "tool_call_atoms"]