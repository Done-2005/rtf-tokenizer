"""Reversible codec for the composite (TAG|ROW|VALUE) symbol.

The composite packs three registry codes into one vocabulary symbol. A naive
``f"{tag}|{row}|{value}"`` is ambiguous: VALUE is free-form source text, and the
R and Java logical-or operator ``||`` is a legitimate VALUE. That symbol then
splits into four parts on ``symbol.split("|")``, so the fact becomes
undecodable and loses its relational address.

Escaping keeps the readable three-field shape while making the field boundary
unambiguous. Only the escape character and the separator are affected, so every
VALUE containing neither is byte-identical to before and the fitted vocabulary
does not churn.

The mapping is injective:

    '%' -> '%25'      '|' -> '%7C'

Every '%' in an encoded string therefore always begins a valid triplet, so
``unescape(encode(v)) == v`` and ``encode`` cannot map two distinct values onto
one symbol. Decoding scans left to right rather than doing sequential replaces,
which would mis-decode a value that literally contains ``%7C``.
"""

from __future__ import annotations

SEPARATOR = "|"
_ESCAPE = "%"
_ENCODED_ESCAPE = "%25"
_ENCODED_SEPARATOR = "%7C"


def escape_value(value: str) -> str:
    """Escape the separator and the escape character inside a VALUE."""
    return value.replace(_ESCAPE, _ENCODED_ESCAPE).replace(
        SEPARATOR, _ENCODED_SEPARATOR)


def unescape_value(text: str) -> str:
    """Inverse of :func:`escape_value`, scanning left to right."""
    if _ESCAPE not in text:
        return text
    out: list[str] = []
    i = 0
    n = len(text)
    while i < n:
        if text[i] == _ESCAPE and i + 3 <= n:
            triplet = text[i + 1:i + 3]
            if triplet == "25":
                out.append(_ESCAPE)
                i += 3
                continue
            if triplet == "7C":
                out.append(SEPARATOR)
                i += 3
                continue
        out.append(text[i])
        i += 1
    return "".join(out)


def encode_composite(tag: str, row: str, value: str) -> str:
    """Build the composite vocabulary symbol for one (TAG, ROW, VALUE) fact."""
    return f"{tag}{SEPARATOR}{row}{SEPARATOR}{escape_value(value)}"


def decode_composite(symbol: str) -> tuple[str, str, str] | None:
    """Recover (tag, row, value) from a composite symbol.

    Returns None if the symbol is not a well-formed composite. Note the split is
    on exactly two separators: VALUE is the remainder and is never split, so an
    escaped separator inside VALUE cannot break the parse.
    """
    if SEPARATOR not in symbol:
        return None
    tag, sep, rest = symbol.partition(SEPARATOR)
    if not sep or SEPARATOR not in rest:
        return None
    row, sep, value = rest.partition(SEPARATOR)
    if not sep:
        return None
    return tag, row, unescape_value(value)


__all__ = ["SEPARATOR", "escape_value", "unescape_value",
           "encode_composite", "decode_composite"]
