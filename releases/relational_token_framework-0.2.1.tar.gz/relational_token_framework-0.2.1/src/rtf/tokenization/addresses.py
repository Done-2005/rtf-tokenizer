"""Canonical reversible RTF address arithmetic.

The combined RTF token is NOT an arbitrary integer: it is a lossless
mixed-radix packing of the relational address, and decompose_address()
always recovers [TAG_ID, ROW_ID, VALUE_ID] (spec section 22).
"""

from __future__ import annotations

RADIX_TAG = 1_000_000
RADIX_ROW = 1_000_000
RADIX_VALUE = 10_000_000
_ADDRESS_OFFSET = 3  # 0..2 reserved for <pad>/<unk>/<eos>


def combine_address(tag_id: int, row_id: int, value_id: int) -> int:
    if not (1 <= tag_id <= RADIX_TAG and 1 <= row_id <= RADIX_ROW
            and 1 <= value_id <= RADIX_VALUE):
        raise ValueError(f"address out of range: {(tag_id, row_id, value_id)}")
    return _ADDRESS_OFFSET + ((tag_id - 1) * RADIX_ROW + (row_id - 1)) * RADIX_VALUE + (value_id - 1)


def decompose_address(address: int) -> tuple[int, int, int]:
    payload = address - _ADDRESS_OFFSET
    if payload < 0:
        raise ValueError(f"not a cell address: {address}")
    value_id = payload % RADIX_VALUE + 1
    payload //= RADIX_VALUE
    row_id = payload % RADIX_ROW + 1
    tag_id = payload // RADIX_ROW + 1
    return tag_id, row_id, value_id
