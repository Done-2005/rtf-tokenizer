"""Canonical dataset assembly + encoding (verbatim port of training/dataset.py
and the EncodedPair task type from training/tasks.py).

Canonical special tokens MUST match the Copy-3 machinery:
    PAD, UNK, SEP, EOS = "<pad>", "<unk>", "<sep>", "<eos>"
(<sep> is present; the 0.1.6 atoms kind was missing it.)

Enc is the union vocabulary shared by both arms so their Copy-3 models have
identical parameter counts (verified by parameter_check).
"""

from __future__ import annotations

from dataclasses import dataclass, field

from ..cross_domain.relationships import (
    RELATIONS, is_cross_domain, rel_to_words, answers)
from .tags import TAG_DOMAIN
from .typed_atoms import (definition_answer, definition_atoms, procedural_atoms,
                          relation_atoms)

# Canonical special tokens (must match Copy-3 machinery).
PAD, UNK, SEP, EOS = "<pad>", "<unk>", "<sep>", "<eos>"
SPECIALS = [PAD, UNK, SEP, EOS]


@dataclass
class EncodedPair:
    pair_id: str
    solution_domain: str
    ids: list[int]
    loss_start: int                       # first TARGET index (predict ids[t] for t >= loss_start)
    slots: list[tuple[int, str]] = field(default_factory=list)


class Enc:
    """Integer vocabulary shared by both arms (union of all symbols)."""

    def __init__(self, symbols):
        self.itos = list(SPECIALS) + sorted(symbols)
        self.stoi = {s: i for i, s in enumerate(self.itos)}
        self.vocab_size = len(self.itos)

    @classmethod
    def from_itos(cls, itos: list[str]) -> "Enc":
        """Rebuild an Enc from a full itos list (e.g. after save/load).

        Keeps the canonical specials at the front and derives stoi so the
        loaded tokenizer matches the frozen vocabulary exactly.
        """
        used: list[str] = []
        for s in itos:
            if s not in used:
                used.append(s)
        enc = cls.__new__(cls)
        enc.itos = used
        enc.stoi = {s: i for i, s in enumerate(used)}
        enc.vocab_size = len(used)
        return enc


def build_records(defs, relations, procedural):
    """Assemble canonical records from the three source tables.

    The `procedural` rows must be (tag, category, question, plain_answer,
    rtf_answer, content) — six fields (enforced by schema_guard).
    """
    recs = []
    for tag, dom, desc in defs:
        recs.append({
            "id": f"DEF_{tag}", "domain": dom, "cross": False,
            "category": "definition", "top_tag": tag,
            "text_in": f"what is {tag} ?",
            "rtf_in": definition_atoms(tag),
            "text_out": " ".join([tag] + desc),
            "rtf_out": definition_answer(tag),
        })
    for subj, rel, obj in relations:
        recs.append({
            "id": f"REL_{subj}_{rel}_{obj}", "domain": TAG_DOMAIN[subj],
            "cross": is_cross_domain(subj, obj), "category": "relation",
            "top_tag": subj,
            "text_in": f"how are {subj} and {obj} related ?",
            "rtf_in": relation_atoms(subj, rel, obj),
            "text_out": (f"{subj} {rel_to_words(rel)} {obj} "
                         f"(confidence high, action execute)"),
            "rtf_out": answers(subj, rel, obj),
        })
    for tag, cat, q, a, rtf_out, content in procedural:
        recs.append({
            "id": f"PROC_{cat}_{q[:14].replace(' ','_')}_x",
            "domain": TAG_DOMAIN[tag], "cross": False, "category": cat,
            "top_tag": tag, "text_in": q, "rtf_in": procedural_atoms(tag, cat, content),
            "text_out": a, "rtf_out": rtf_out,
        })
    return recs


def build_bpe_pieces(tok, text):
    return tok.encode(text)


def build_encoder(records, tok):
    """Union vocabulary over RTF typed atoms + BPE pieces (both arms)."""
    syms = set()
    for r in records:
        syms.update(r["rtf_in"])
        syms.update(r["rtf_out"])
        if tok is not None:
            syms.update(build_bpe_pieces(tok, r["text_in"]))
            syms.update(build_bpe_pieces(tok, r["text_out"]))
    return Enc(syms)


def make_pair(enc: Enc, problem, answer, pair_id: str = "p",
              solution_domain: str = "direct") -> EncodedPair:
    """Build an EncodedPair (flat ids + loss-start + slots) for one record.

    Stream: ids = encode(problem) + [SEP] + encode(answer) + [EOS];
    loss is applied only to the solution-region targets (t >= loss_start).
    """
    pid = [enc.stoi.get(t, enc.stoi[UNK]) for t in problem]
    aid = [enc.stoi.get(t, enc.stoi[UNK]) for t in answer]
    ids = pid + [enc.stoi[SEP]] + aid + [enc.stoi[EOS]]
    loss_start = len(pid) + 1
    slots = [(loss_start + i + 1, "A") for i in range(len(aid))]
    slots.append((len(ids) - 1, "EOS"))
    return EncodedPair(pair_id, solution_domain, ids, loss_start, slots)


def build_pairs(records, enc, problem_of, answer_of):
    """Return rtf_pairs for a record list (problem_of/answer_of extract
    the typed symbol stream of each side from a record)."""
    pairs = []
    for r in records:
        pairs.append(make_pair(enc, problem_of(r), answer_of(r),
                               pair_id=r["id"], solution_domain=r["domain"]))
    return pairs


__all__ = ["PAD", "UNK", "SEP", "EOS", "SPECIALS", "Enc", "EncodedPair",
           "build_records", "build_encoder", "build_bpe_pieces", "make_pair",
           "build_pairs", "RELATIONS"]