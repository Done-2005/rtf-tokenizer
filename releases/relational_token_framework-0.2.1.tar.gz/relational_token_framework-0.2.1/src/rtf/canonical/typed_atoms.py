"""Typed-atom representation builder (verbatim port of representation/typed_atoms.py).

Content-preserving for the supported typed-atom grammar and covered
inputs (uncovered symbols map to <unk> silently at the id level). The
architecture rule:

    RTF may STRUCTURE information, but must NEVER REMOVE information needed
    to distinguish different questions.

The BAD design (v2) emitted the SAME input for every arithmetic question:
    Q : T:ARITHMETIC E ASK ARITHMETIC
which collapsed 2+2, 10x5, 15x8 to one input with answers 4, 50, 120 — an
unsatisfiable task that made RTF plateau at 0.936.

The GOOD design (v3) keeps the operands/operation as typed VALUE atoms:
    Q : T:ARITHMETIC N:10 R:TIMES N:5 E ASK ARITHMETIC
Now the inputs are distinct and RTF reaches 1.000 everywhere while still
learning faster than BPE.
"""

from __future__ import annotations

from .meanings import MEANINGS
from .tags import TAG_DOMAIN

# Router / ask punctuation tokens shared by all typed streams.
Q, COL, T, R, V, E, ASK = "Q", ":", "T:", "R:", "V:", "E", "ASK"


def definition_atoms(tag: str) -> list[str]:
    """Typed input for 'what is <TAG>?' preserving tag identity + the ask."""
    return [Q, COL, T, tag, V, tag, E, ASK, "MEANING"]


def relation_atoms(subj: str, rel: str, obj: str) -> list[str]:
    """Typed input capturing a typed relationship between two main tags."""
    return [Q, COL, T, subj, R, rel, T, obj, E, ASK, "RELATION"]


def procedural_atoms(tag: str, category: str, content) -> list[str]:
    """Typed input for a procedural QA.

    `content` is a list of (prefix, value) typed atoms (V:/N:/R:) that carry
    the DISTINGUISHING content preserved from the question. It MUST be present
    so no two questions collapse to the same input (the v3 rule).
    """
    atoms = [Q, COL, T, tag, E]
    for prefix, value in content:
        atoms += [prefix, value]
    atoms += [ASK, category.upper()]
    return atoms


def definition_answer(tag: str) -> list[str]:
    """Typed gold answer for a definition: tag name + its meaning words."""
    return [tag] + list(MEANINGS[tag])


__all__ = ["Q", "COL", "T", "R", "V", "E", "ASK", "MEANINGS", "TAG_DOMAIN",
           "definition_atoms", "relation_atoms", "procedural_atoms",
           "definition_answer"]