"""Canonical Five-Domain benchmark data (verbatim port of
BENCHMARKS/five_domain/data.py — the authoritative source tables).

DEFS      : (independent_main_tag, domain, meaning_words)      — 23 tags
RELATIONS : (subject, relation, object)                         — 12 (6 cross)
PROCEDURAL: (tag, category, question, plain_answer,             — 12
             rtf_answer, content_atoms)
"""

from __future__ import annotations

DEFS = [
    ("PYTHON", "PYTHON", ["the", "python", "programming", "language"]),
    ("PYTHON_FUNCTIONS", "PYTHON", ["functions", "and", "callables", "in", "python"]),
    ("PYTHON_ARCHITECTURE", "PYTHON", ["structure", "and", "organization", "of", "a", "python", "system"]),
    ("PYTHON_PROBLEMS", "PYTHON", ["problems", "and", "tasks", "solvable", "in", "python"]),
    ("PYTHON_SOLUTIONS", "PYTHON", ["implementations", "and", "solutions", "for", "python", "problems"]),
    ("JAVA", "JAVA", ["the", "java", "programming", "language"]),
    ("JAVA_OBJECTS", "JAVA", ["objects", "classes", "and", "inheritance", "in", "java"]),
    ("JAVA_METHODS", "JAVA", ["methods", "that", "define", "behavior", "of", "java", "objects"]),
    ("JAVA_PROBLEMS", "JAVA", ["problems", "and", "tasks", "solvable", "in", "java"]),
    ("JAVA_SOLUTIONS", "JAVA", ["implementations", "for", "java", "problems"]),
    ("RUST", "RUST", ["the", "rust", "systems", "programming", "language"]),
    ("RUST_MEMORY", "RUST", ["memory", "safety", "ownership", "and", "borrowing", "in", "rust"]),
    ("RUST_OWNERSHIP", "RUST", ["ownership", "the", "rule", "where", "each", "rust", "value", "has", "one", "owner"]),
    ("RUST_PROBLEMS", "RUST", ["problems", "and", "tasks", "solvable", "in", "rust"]),
    ("RUST_SOLUTIONS", "RUST", ["implementations", "for", "rust", "problems"]),
    ("MATHEMATICS", "MATHEMATICS", ["the", "mathematical", "science", "of", "structure", "and", "quantity"]),
    ("ALGEBRA", "MATHEMATICS", ["algebra", "equations", "and", "symbolic", "manipulation"]),
    ("CALCULUS", "MATHEMATICS", ["calculus", "limits", "derivatives", "and", "integrals"]),
    ("ARITHMETIC", "MATHEMATICS", ["arithmetic", "addition", "subtraction", "multiplication", "and", "division", "of", "numbers"]),
    ("STATISTICS", "STATISTICS", ["the", "statistical", "science", "of", "data", "and", "uncertainty"]),
    ("PROBABILITY", "STATISTICS", ["probability", "random", "events", "and", "distributions"]),
    ("REGRESSION", "STATISTICS", ["regression", "modeling", "and", "prediction", "of", "data"]),
    ("MEAN", "STATISTICS", ["the", "average", "of", "a", "set", "of", "numbers"]),
]

RELATIONS = [
    ("PYTHON", "RELATED_TO", "MATHEMATICS"),
    ("PYTHON", "USED_FOR", "STATISTICS"),
    ("JAVA", "RELATED_TO", "MATHEMATICS"),
    ("RUST", "USED_FOR", "STATISTICS"),
    ("MATHEMATICS", "SUPPORTS", "STATISTICS"),
    ("STATISTICS", "USES", "MATHEMATICS"),
    ("PYTHON", "HAS", "PYTHON_FUNCTIONS"),
    ("PYTHON", "HAS", "PYTHON_SOLUTIONS"),
    ("JAVA", "HAS", "JAVA_METHODS"),
    ("RUST", "HAS", "RUST_OWNERSHIP"),
    ("MATHEMATICS", "HAS", "ARITHMETIC"),
    ("STATISTICS", "HAS", "MEAN"),
]

# (tag, category, plain_question, plain_answer, rtf_answer, content_atoms)
PROCEDURAL = [
    ("ARITHMETIC", "arithmetic", "what is 2 plus 2", "4", ["4"],
     [("N:", "2"), ("R:", "PLUS"), ("N:", "2")]),
    ("ARITHMETIC", "arithmetic", "what is the sum of 2 and 2", "4", ["4"],
     [("N:", "2"), ("R:", "PLUS"), ("N:", "2"), ("V:", "SUM")]),
    ("ARITHMETIC", "arithmetic", "what is 10 times 5", "50", ["50"],
     [("N:", "10"), ("R:", "TIMES"), ("N:", "5")]),
    ("ARITHMETIC", "arithmetic", "what is 15 times 8", "120", ["120"],
     [("N:", "15"), ("R:", "TIMES"), ("N:", "8")]),
    ("ARITHMETIC", "arithmetic", "what is 7 minus 3", "4", ["4"],
     [("N:", "7"), ("R:", "MINUS"), ("N:", "3")]),
    ("PYTHON_FUNCTIONS", "code", "what does a python function do",
     "a function defines reusable program behavior",
     ["PYTHON_FUNCTIONS", "define", "reusable", "behavior", "CONF", "HIGH",
      "ACTION", "EXECUTE"],
     [("V:", "DEFINE"), ("V:", "REUSABLE_BEHAVIOR")]),
    ("PYTHON_FUNCTIONS", "code", "create a function that adds two numbers",
     "def add a b : return a plus b",
     ["PYTHON_FUNCTIONS", "def", "add", "a", "b", "return", "a", "plus", "b",
      "CONF", "HIGH", "ACTION", "EXECUTE"],
     [("V:", "CREATE"), ("V:", "ADD_TWO_NUMBERS")]),
    ("JAVA_METHODS", "method", "how do you define a method in java",
     "a method is defined inside a class with a name and body",
     ["JAVA_METHODS", "define", "method", "inside", "class", "CONF", "HIGH",
      "ACTION", "EXECUTE"],
     [("V:", "DEFINE_METHOD")]),
    ("RUST_OWNERSHIP", "ownership", "what is ownership in rust",
     "ownership is rust rule where each value has one owner",
     ["RUST_OWNERSHIP", "each", "value", "has", "one", "owner", "CONF", "HIGH",
      "ACTION", "EXECUTE"],
     [("V:", "EACH_VALUE_ONE_OWNER")]),
    ("MEAN", "statistic", "what is the mean of 2 4 6", "4", ["4"],
     [("N:", "2"), ("N:", "4"), ("N:", "6")]),
    ("MEAN", "statistic", "calculate the mean of 2 4 6", "4", ["4"],
     [("N:", "2"), ("N:", "4"), ("N:", "6"), ("V:", "CALCULATE")]),
    ("REGRESSION", "statistic", "what does regression predict",
     "regression predicts a value from data",
     ["REGRESSION", "predict", "value", "from", "data", "CONF", "HIGH",
      "ACTION", "EXECUTE"],
     [("V:", "PREDICT_VALUE")]),
]

__all__ = ["DEFS", "RELATIONS", "PROCEDURAL"]