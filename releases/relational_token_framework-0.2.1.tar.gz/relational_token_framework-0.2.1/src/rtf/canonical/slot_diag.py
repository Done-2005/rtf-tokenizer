"""Slot-level diagnosis: how well does the model learn T / R / V *separately*?

The canonical benchmark answer streams carry three distinct slot families:

    DEF:  [TAG]  + meaning words...
    REL:  [TAG, ROW, TAG] + [ROW ...]        (subject, relation, object,
                                             then confidence/action tokens)
    PROC: [VALUE]                            (the numeric answer)

This module computes an independent profile per slot on the SAME held-out
evaluation set, with chance baselines, so the honest question is:

    "How much information about VALUE is the model actually learning
     relative to the difficulty of the VALUE space?"

rather than the naive "VALUE is lower than TAG".

We do NOT touch the tokenizer, architecture, vocabulary, CASE variant, or
training procedure. Only the frozen checkpoint's predictions are consumed:
    pred_id_lists      argmax ids (top-1, required)
    top5_id_lists      optional top-5 ids per answer region
    ce_lists           optional per-position cross-entropy (model-side)

Everything here is deterministic and torch-free; the model-side values are
supplied by the caller (e.g. a Kaggle eval pass) and only aggregated here.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field

# ---------------------------------------------------------------------------
# Slot taxonomy
# ---------------------------------------------------------------------------

TAG, ROW, VALUE = "TAG", "ROW", "VALUE"
SLOTS = (TAG, ROW, VALUE)


def canonical_slots(category: str, answer_len: int) -> list[str | None]:
    """Default per-position slot label for one canonical answer region.

    Returns None for structural positions that are not scored as a slot.
    Callers with a different benchmark layout must supply their own slot_of.
    """
    cat = category.lower()
    if cat == "definition":
        return ([TAG] if answer_len > 0 else []) + \
            [VALUE] * max(0, answer_len - 1)
    if cat == "relation":
        if answer_len == 0:
            return []
        labels = ([TAG, ROW, TAG] + [ROW] * max(0, answer_len - 3))
        return labels[:answer_len]
    if cat == "arithmetic":
        return [VALUE] * answer_len
    return [VALUE] * answer_len  # unknown categories -> score as VALUE


# ---------------------------------------------------------------------------
# Per-position analysis
# ---------------------------------------------------------------------------

@dataclass
class PositionResult:
    slot: str | None
    gold: str
    pred: str | None
    top5_hit: bool | None = None
    ce: float | None = None


@dataclass
class SlotStats:
    slug: str
    n: int = 0
    top1_hits: int = 0
    top5_hits_known: int = 0          # positions with top5 info
    top5_hits: int = 0
    ce_values: list = field(default_factory=list)
    distinct_gold: set = field(default_factory=set)   # per-slot vocab size

    @property
    def top1_acc(self) -> float:
        return round(self.top1_hits / self.n, 4) if self.n else 0.0

    @property
    def top5_acc(self) -> float:
        if not self.top5_hits_known:
            return float("nan")       # caller did not provide top-5
        return round(self.top5_hits / self.top5_hits_known, 4) if \
            self.top5_hits_known else 0.0

    @property
    def mean_ce(self) -> float:
        if not self.ce_values:
            return float("nan")
        return round(sum(self.ce_values) / len(self.ce_values), 4)

    @property
    def vocab_size(self) -> int:
        return len(self.distinct_gold)

    @property
    def chance_top1(self) -> float:
        """Random Top-1 = 1/N_slot over the observed per-slot vocab."""
        return round(1.0 / self.vocab_size, 6) if self.vocab_size else 0.0

    @property
    def gain_over_chance(self) -> float:
        """(acc - chance) / (1 - chance): information actually learned
        relative to the difficulty of the slot's value space."""
        if self.n == 0 or self.vocab_size <= 1:
            return float("nan")
        return round((self.top1_acc - self.chance_top1) / (1 - self.chance_top1),
                     4)


def analyze_positions(positions: list[PositionResult]) -> dict[str, SlotStats]:
    """Aggregate per-position results into per-slot statistics."""
    stats: dict[str, SlotStats] = {}
    for p in positions:
        if p.slot is None:
            continue
        s = stats.setdefault(p.slot, SlotStats(p.slot))
        s.n += 1
        s.distinct_gold.add(p.gold)
        if p.pred == p.gold:
            s.top1_hits += 1
        if p.top5_hit is not None:
            s.top5_hits_known += 1
            if p.top5_hit:
                s.top5_hits += 1
        if p.ce is not None:
            s.ce_values.append(p.ce)
    return stats


def slot_profile(stats: dict[str, SlotStats]) -> dict:
    """Compact profile ready to print/compare (the three-way table)."""
    return {
        s.slug: {
            "n": s.n, "top1_acc": s.top1_acc, "top5_acc": s.top5_acc,
            "mean_ce": s.mean_ce, "vocab_size": s.vocab_size,
            "chance_top1": s.chance_top1, "gain_over_chance": s.gain_over_chance,
        } for s in stats.values()}


def chance_baselines(vocab_sizes: dict[str, int]) -> dict[str, float]:
    """Random Top-1 per slot: 1/N_T, 1/N_R, 1/N_V."""
    return {k: round(1.0 / v, 6) for k, v in vocab_sizes.items() if v}


def largest_gap(profile: dict, tol: float = 0.01) -> tuple[str, str, float] | None:
    """The slot with the largest gain-over-chance deficit vs the best slot.

    Returns None when every slot is within `tol` of the best (no gap), so a
    perfect model does not fabricate a "weakest slot" line.
    """
    if len(profile) < 2:
        return None
    best = max(profile.items(), key=lambda kv: kv[1]["gain_over_chance"])
    worst = min(profile.items(), key=lambda kv: kv[1]["gain_over_chance"])
    diff = best[1]["gain_over_chance"] - worst[1]["gain_over_chance"]
    if diff < tol:
        return None
    return worst[0], best[0], worst[1]["gain_over_chance"]


# ---------------------------------------------------------------------------
# Pair-level hook (frozen checkpoint consumption, no retraining)
# ---------------------------------------------------------------------------

def slot_report_on_pairs(gold_pairs, pred_id_lists, enc,
                         task_of=None, slot_of=None,
                         top5_id_lists=None, ce_lists=None) -> dict:
    """Full three-way slot profile from gold EncodedPairs + model argmax.

    gold_pairs:      list[EncodedPair]  (answer regions are the evaluated set)
    pred_id_lists:   parallel list of full id sequences (model argmax)
    enc:             the Enc (union vocab) for decode
    task_of(pair)-> str|None: category per pair, default "definition"
    slot_of(record_idx, category, answer_atoms)-> list[slot|None]: per-answer-
                     position slot labels; defaults to canonical_slots()
    top5_id_lists / ce_lists: optional parallel structures
                     {pair_index: list over answer region} for Top-5 and CE.

    Returns {profile, positions, n_answer_positions, chance_baselines,
             largest_gap}.
    """
    itos = enc.itos

    def dec(ids):
        return [itos[i] if 0 <= i < len(itos) else "<unk>" for i in ids]

    results: list[PositionResult] = []
    n_answer_positions = 0
    for pi, (pair, pred_ids) in enumerate(zip(gold_pairs, pred_id_lists)):
        cat = task_of(pair) if task_of else "definition"
        gold_atoms = dec(pair.ids[pair.loss_start - 1:])
        pred_atoms = dec(pred_ids[pair.loss_start - 1:])
        slots = slot_of(pi, cat, gold_atoms) if slot_of \
            else canonical_slots(cat, len(gold_atoms))
        top5 = top5_id_lists[pi] if top5_id_lists else None
        ces = ce_lists[pi] if ce_lists else None
        for j in range(len(gold_atoms)):
            slot = slots[j] if j < len(slots) else None
            n_answer_positions += 1
            if slot is None:
                continue
            g = gold_atoms[j]
            p = pred_atoms[j] if j < len(pred_atoms) else None
            t5hit = None
            if top5 is not None:
                cands = top5[j] if j < len(top5) else []
                t5hit = g in set(cands)
            ce = ces[j] if ces is not None and j < len(ces) else None
            results.append(PositionResult(slot, g, p, t5hit, ce))

    stats = analyze_positions(results)
    profile = slot_profile(stats)
    sizes = {s.slug: s.vocab_size for s in stats.values()}
    return {
        "profile": profile,
        "positions": results,
        "n_answer_positions": n_answer_positions,
        "chance_baselines": chance_baselines(sizes),
        "largest_gap": largest_gap(profile),
    }


# ---------------------------------------------------------------------------
# Print helpers
# ---------------------------------------------------------------------------

def format_three_way(report: dict) -> str:
    """The 3-line factual summary + gap line."""
    prof = report["profile"]
    lines = []
    for s in (TAG, ROW, VALUE):
        if s not in prof:
            continue
        d = prof[s]
        lines.append(f"{s:5}: top1={d['top1_acc']*100:6.1f}%  "
                     f"top5={d['top5_acc']*100:6.1f}%  ce={d['mean_ce']:6.4f}  "
                     f"n={d['n']}  N={d['vocab_size']}  "
                     f"chance=1/{d['vocab_size']}={d['chance_top1']:.4f}  "
                     f"gain_vs_chance={d['gain_over_chance']:+.4f}")
    gap = report.get("largest_gap")
    if gap:
        lines.append(f"largest measured learning gap: {gap[0]} is weakest "
                     f"vs {gap[1]} (gain {gap[2]:+.4f})")
    return "\n".join(lines)


__all__ = ["TAG", "ROW", "VALUE", "SLOTS", "canonical_slots",
           "PositionResult", "SlotStats", "analyze_positions", "slot_profile",
           "chance_baselines", "largest_gap", "slot_report_on_pairs",
           "format_three_way"]