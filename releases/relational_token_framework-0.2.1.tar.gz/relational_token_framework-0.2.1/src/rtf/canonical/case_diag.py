"""Value-error classification diagnostic (case analysis).

Evaluation-side only. Never changes tokenization or the frozen [T,R,V]
VALUE semantics. Splits VALUE predictions into four buckets:

    exact      - predicted value == gold value
    case_only  - differs ONLY in casing (Print vs print)
    different  - changes the identifier/text beyond casing
    missing    - gold had a value but the prediction stopped short

For a target stream plus a predicted stream it reports:

    VALUE exact accuracy          exact / gold
    VALUE case-insensitive acc    (exact + case_only) / gold
    case-only error rate          case_only / (gold - exact)

The key diagnostic is ``case_only_fraction``: if a large share of VALUE
errors are pure-casing errors, an explicit case-metadata experiment
(V_CASE atoms, see case_variant.py) is worth running; if the share is
small, casing is not the main VALUE bottleneck.
"""

from __future__ import annotations

VALUE_PREFIXES = ("V:",)
TITLE = "TITLE"
LOWER = "LOWER"
UPPER = "UPPER"
MIXED = "MIXED"
NONE = "NONE"

_EXACT = "exact"
_CASE_ONLY = "case_only"
_DIFFERENT = "different"
_MISSING = "missing"
_EXTRA = "extra"

# tokens that cannot be a value (grammar punctuation / routers)
_NON_VALUE = {"Q", ":", "E", "ASK", "MEANING", "RELATION", "T:", "R:", "V:", "N:"}


def case_kind(token: str) -> str:
    """Classify a value token's casing: UPPER / LOWER / TITLE / MIXED / NONE.

    - UPPER  all letters are uppercase       ("PRINT")
    - LOWER  all letters are lowercase       ("print")
    - TITLE  first letter uppercase, rest lower and no other upper ("Print")
    - MIXED  mixed beyond title-casing       ("printX", "get_Value")
    - NONE   no alphabetic characters        ("(", "10", "+")
    """
    if not token or not any(c.isalpha() for c in token):
        return NONE
    cased = [c for c in token if c.isalpha()]
    if not any(c.islower() for c in cased):
        return UPPER
    if not any(c.isupper() for c in cased):
        return LOWER
    if cased[0].isupper() and not any(c.isupper() for c in cased[1:]):
        return TITLE
    return MIXED


def extract_values(stream, prefixes=VALUE_PREFIXES) -> list[tuple[str, str]]:
    """Pull (prefix, value) pairs out of a typed-atom stream.

    The canonical stream carries the prefix and the value as SEPARATE
    atoms ("V:", "print"). A value atom is the token immediately after a
    value prefix when it is not itself grammar punctuation. By default
    only the ``V:`` (VALUE) slot is returned — the case-relevant slot.
    """
    values: list[tuple[str, str]] = []
    i = 0
    n = len(stream)
    while i < n:
        tok = stream[i]
        if tok in prefixes and i + 1 < n:
            nxt = stream[i + 1]
            if nxt not in _NON_VALUE:
                values.append((tok, nxt))
                i += 2
                continue
        i += 1
    return values


def align(gold_tokens, pred_tokens) -> list[tuple[str, str | None]]:
    """Position-aligned (gold, pred) pairs for two answer token lists.

    Lengths may differ: a missing prediction yields (gold, None), a
    gold-absent prediction yields (None, pred) and is counted as extra.
    """
    out = []
    n = max(len(gold_tokens), len(pred_tokens))
    for i in range(n):
        g = gold_tokens[i] if i < len(gold_tokens) else None
        p = pred_tokens[i] if i < len(pred_tokens) else None
        out.append((g, p))
    return out


def classify(gold: str | None, pred: str | None) -> str:
    """Bucket a single (gold, pred) value pair."""
    if pred is None:
        return _MISSING
    if gold is None:
        return _EXTRA
    if gold == pred:
        return _EXACT
    if gold.lower() == pred.lower():
        return _CASE_ONLY
    return _DIFFERENT


def value_report(gold_tokens, pred_tokens) -> dict:
    """Full diagnostic for one gold/pred value sequence.

    Assumes gold_tokens / pred_tokens are the decoded ANSWER atoms
    (the loss region), compared positionally. Returns counts plus the
    three headline numbers and the case-only error fraction.
    """
    buckets = {_EXACT: 0, _CASE_ONLY: 0, _DIFFERENT: 0,
               _MISSING: 0, _EXTRA: 0}
    for g, p in align(gold_tokens, pred_tokens):
        buckets[classify(g, p)] += 1

    n_gold = len(gold_tokens)
    n_exact = buckets[_EXACT]
    n_case = buckets[_CASE_ONLY]
    n_err = n_gold - n_exact
    exact_acc = (n_exact / n_gold) if n_gold else 0.0
    ci_acc = ((n_exact + n_case) / n_gold) if n_gold else 0.0
    case_only_fraction = (n_case / n_err) if n_err else 0.0

    return {
        "n_gold": n_gold, "n_pred": len(pred_tokens),
        "exact": n_exact, "case_only": n_case, "different": buckets[_DIFFERENT],
        "missing": buckets[_MISSING], "extra": buckets[_EXTRA],
        "value_exact_accuracy": round(exact_acc, 4),
        "value_case_insensitive_accuracy": round(ci_acc, 4),
        "case_only_fraction_of_errors": round(case_only_fraction, 4),
    }


def value_report_streams(gold_atoms, pred_atoms) -> dict:
    """Diagnostic over typed-atom streams: values extracted, then compared.

    Both inputs are the ANSWER-region typed atom lists of a pair.
    """
    g = [v for _p, v in extract_values(gold_atoms)] if gold_atoms else []
    p = [v for _p, v in extract_values(pred_atoms)] if pred_atoms else []
    return value_report(g, p)


def summarize(reports) -> dict:
    """Aggregate several per-pair reports into corpus-level numbers."""
    total_gold = sum(r["n_gold"] for r in reports)
    total_exact = sum(r["exact"] for r in reports)
    total_case = sum(r["case_only"] for r in reports)
    total_err = total_gold - total_exact
    return {
        "n_pairs": len(reports),
        "n_gold_values": total_gold,
        "value_exact_accuracy": round((total_exact / total_gold), 4)
        if total_gold else 0.0,
        "value_case_insensitive_accuracy": round(
            ((total_exact + total_case) / total_gold), 4) if total_gold else 0.0,
        "case_only_fraction_of_errors": round((total_case / total_err), 4)
        if total_err else 0.0,
    }


__all__ = ["value_report", "value_report_streams", "summarize",
           "classify", "align", "case_kind", "extract_values"]