"""CELL-address diagnostics: is the VALUE bottleneck a cell-association gap?

Excel analogy the experiment is built on:

    TAG  = column identity        (A, B, C)
    ROW  = row identity            (1, 2, 3)
    CELL = address                 (A1)  -> the selected cell
    VALUE = cell content           (what A1 shows)
    FORMULA = derivation           (=A1+B1, =A1+1, =A1+2)  -> how it was made

Current Copy-3 streams ask the model to learn the full association at once:

    T:TAG_x  R:ROW_y  V:value        (learn  (TAG,ROW) -> VALUE )

The hypothesis under test: VALUE accuracy is low because the model must
reconstruct the TAG x ROW -> VALUE association in one prediction, and part
of that difficulty is CELL address selection (which cell is being asked for).

Three controlled arms (pure stream builders - add C:, never replace T/R/V):

    Arm A  baseline          T:tag R:row V:value
    Arm B  explicit CELL     T:tag R:row C:cell V:value
    Arm C  CELL-first        C:cell T:tag R:row V:value

And the pipelined decomposition:

    TAG + ROW -> CELL     (cell selection)
    CELL -> VALUE         (retrieval)
    TAG + ROW -> VALUE    (direct; the current single-shot pathway)

IMPORTANT: this module only MEASURES. It does not implement a CELL variant
in the tokenizer/architecture. The C: arm builders are used by experiments
on a FROZEN checkpoint; a verdict is only meaningful for deciding whether
to train a CELL variant, not as a promised improvement.
"""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass

from .registry import CELLS

C_PREFIX = "C:"
CC = "C:"                       # typed-prefix constant to match T:/R:/V:/N:
_PREFIX_RE = re.compile(r"^(T:|R:|V:|N:|C:)")

# ---------------------------------------------------------------------------
# Deterministic cell identity (no arithmetic on categorical ids)
# ---------------------------------------------------------------------------

def cell_id_for(tag_label: str, row_label: str,
                registry=None) -> str | int:
    """Deterministic CELL address from a (TAG, ROW) coordinate pair.

    - registry=None : categorical string composition "CELL:TAG@ROW".
      NO numeric addition (the user's warning: A+1 on categorical ids could
      invent accidental relationships).
    - registry=CELLS: permanent identity via the frozen Registry (CELL-N,
      globally unique, never reused). Idempotent by key.
    """
    key = f"{tag_label}@{row_label}"
    if registry is not None:
        return registry.register(key)
    return f"CELL:{key}"


def cell_key(cell: str | int) -> str:
    """Normalize any cell id to its registry key form for comparison."""
    s = str(cell)
    if s.startswith("CELL:"):
        return s[len("CELL:"):]
    if s.startswith("CELL-"):
        return s
    m = re.match(r"^(.*?)@(.*)$", s)
    return s


# ---------------------------------------------------------------------------
# The three controlled-arm stream builders (pure, additive)
# ---------------------------------------------------------------------------

def arm_streams(tag: str, row: str, value: str,
                cell: str | None = None, arm: str = "A") -> list[str]:
    """Atom stream for one arm. T/R/V are ALWAYS preserved.

    Arm A: baseline (no C:).  Arm B: CELL after R:.
    Arm C: CELL first, then T/R/V.
    """
    cell = cell if cell is not None else \
        str(cell_id_for(tag, row))
    if arm == "A":
        return ["T:", tag, "R:", row, "V:", value]
    if arm == "B":
        return ["T:", tag, "R:", row, "C:", str(cell), "V:", value]
    if arm == "C":
        return ["C:", str(cell), "T:", tag, "R:", row, "V:", value]
    raise ValueError(f"arm must be A/B/C (got {arm!r})")


def stream_is_cell_preserved(stream: list[str], tag: str, row: str,
                             value: str, arm: str = "A") -> bool:
    """Verify additive rule: streaming an arm never drops T/R/V atoms.

    Arm A has no C: (that IS the baseline); arms B/C must additionally
    carry the C: prefix and the composed cell address.
    """
    base = (tag in stream and row in stream and value in stream
            and all(atom in stream for atom in ("T:", "R:", "V:")))
    if arm == "A":
        return base and "C:" not in stream
    return (base and "C:" in stream
            and str(cell_id_for(tag, row)) in stream)


# ---------------------------------------------------------------------------
# Measurement on decoded atom streams
# ---------------------------------------------------------------------------

@dataclass
class LookupMetrics:
    n_pairs: int
    cell_selection_hits: int          # TAG+ROW -> CELL correct
    retrieval_hits: int               # CELL -> VALUE, on pairs where the
                                      # model emitted the correct cell
    retrieval_denominator: int
    direct_hits: int                  # TAG+ROW -> VALUE correct (single-shot)
    n_cells: int
    n_values: int
    n_values_per_cell: int            # distinct values at an address (avg)

    @property
    def cell_selection_acc(self) -> float:
        return round(self.cell_selection_hits / self.n_pairs, 4) \
            if self.n_pairs else 0.0

    @property
    def retrieval_acc(self) -> float:
        return round(self.retrieval_hits / self.retrieval_denominator, 4) \
            if self.retrieval_denominator else float("nan")

    @property
    def direct_acc(self) -> float:
        return round(self.direct_hits / self.n_pairs, 4) \
            if self.n_pairs else 0.0

    @property
    def chance_cell(self) -> float:
        return round(1.0 / self.n_cells, 4) if self.n_cells else 0.0

    @property
    def chance_value_direct(self) -> float:
        return round(1.0 / self.n_values, 4) if self.n_values else 0.0

    @property
    def chance_value_given_cell(self) -> float:
        return round(1.0 / self.n_values_per_cell, 4) \
            if self.n_values_per_cell else 0.0

    def gain_over_chance(self, which: str) -> float | None:
        acc, chance = {"cell": (self.cell_selection_acc, self.chance_cell),
                       "retrieval": (self.retrieval_acc,
                                     self.chance_value_given_cell),
                       "direct": (self.direct_acc,
                                  self.chance_value_direct)}[which]
        if chance >= 1.0:
            return 0.0 if acc >= 1.0 else float("nan")
        return round((acc - chance) / (1 - chance), 4)


def _probable(reg) -> float:
    return reg.gain_over_chance("cell")


def verdict(lm: LookupMetrics, tol: float = 0.05) -> str:
    """Interpret the three-accuracy pattern (the experiment's decision rule).

    Meaningful only when the model is NOT at chance everywhere.
    """
    if lm.n_pairs == 0:
        return "no data"
    c, r, d = lm.cell_selection_acc, lm.retrieval_acc, lm.direct_acc
    if c > 0.9 and r > 0.9 and d < 0.7:
        return ("pathway bottleneck: TAG+ROW->CELL and CELL->VALUE are both "
                "strong, direct (TAG+ROW->VALUE) is the weak link -> the "
                "model CONTAINS the value but the single-shot prediction "
                "pathway is the bottleneck.")
    if c < 0.7 and r > 0.9:
        return ("cell addressing bottleneck: the model cannot select the "
                "CELL reliably (TAG+ROW->CELL weak) but CAN retrieve a value "
                "once the cell is right -> try a CELL-first/selection arm.")
    if c < 0.7 and r < 0.7:
        return ("representation bottleneck (deeper): both cell selection and "
                "cell->value retrieval are weak -> investigate embedding / "
                "copying / output-head issues before any CELL variant.")
    return ("no clear single bottleneck: selection, retrieval, and direct "
            "are aligned; VALUE gap must come from another lever (case, "
            "sparsity, or vocabulary size).")


# ---------------------------------------------------------------------------
# Pair-level hook (frozen checkpoint consumption)
# ---------------------------------------------------------------------------

def extract_cell_and_value(atoms) -> tuple[str | None, str | None]:
    """Pull the first C: cell and the first V:/N: value from atom symbols."""
    cell = val = None
    i = 0
    while i < len(atoms):
        a = atoms[i]
        if a == "C:" and i + 1 < len(atoms):
            cell = atoms[i + 1]
            i += 2
            continue
        if a in ("V:", "N:") and i + 1 < len(atoms):
            if val is None:
                val = atoms[i + 1]
            i += 2
            continue
        i += 1
    return cell, val


def cell_lookup_diagnostics(gold_pairs, pred_id_lists, enc,
                            tag_of=None, row_of=None, value_of=None,
                            arm="A") -> LookupMetrics:
    """Full lookup-profile from gold EncodedPairs + frozen model argmax.

    tag_of(pair)->str, row_of(pair)->str, value_of(pair)->str supply the
    record-level truth. Cell ids are deterministic from (tag,row).
    `arm` is the evaluation arm (B/C only when a C: arm was trained).
    """
    if tag_of is None or row_of is None or value_of is None:
        raise ValueError("tag_of/row_of/value_of must be supplied to "
                         "reconstruct CELL addresses from records.")
    itos = enc.itos

    def dec(ids):
        return [itos[i] if 0 <= i < len(itos) else "<unk>" for i in ids]

    direct_hits = cell_selection_hits = retrieval_hits = 0
    retrieval_den = 0
    cells: set = set()
    values: set = set()
    value_counts: Counter = Counter()

    for pair, pred_ids in zip(gold_pairs, pred_id_lists):
        tag, row, value = tag_of(pair), row_of(pair), value_of(pair)
        cell = cell_id_for(tag, row)
        cells.add(cell_key(cell))
        values.add(value)
        value_counts[cell_key(cell)] = value_counts.get(cell_key(cell), 0) + 1
        atoms = dec(pred_ids[pair.loss_start - 1:])
        pcell, pval = extract_cell_and_value(atoms)
        is_cell = pcell is not None and cell_key(pcell) == cell_key(cell)
        if is_cell:
            cell_selection_hits += 1
        if pval == value:
            direct_hits += 1
        if is_cell:
            retrieval_den += 1
            if pval == value:
                retrieval_hits += 1

    n_value_counts = list(value_counts.values())
    return LookupMetrics(
        n_pairs=len(gold_pairs),
        cell_selection_hits=cell_selection_hits,
        retrieval_hits=retrieval_hits,
        retrieval_denominator=retrieval_den,
        direct_hits=direct_hits,
        n_cells=len(cells),
        n_values=len(values),
        n_values_per_cell=round(sum(n_value_counts) / len(n_value_counts), 4)
        if n_value_counts else 0,
    )


def format_lookup(lm: LookupMetrics) -> str:
    lines = [
        f"TAG+ROW -> CELL   (selection) : {lm.cell_selection_acc*100:6.1f}%  "
        f"chance 1/{lm.n_cells}={lm.chance_cell:.4f}  "
        f"gain={lm.gain_over_chance('cell')}  n={lm.n_pairs}",
        f"CELL -> VALUE     (retrieval) : "
        f"{('%6.1f%%' % (lm.retrieval_acc*100)) if lm.retrieval_denominator else '   n/a'}  "
        f"chance 1/{lm.n_values_per_cell or '?'}  "
        f"gain={lm.gain_over_chance('retrieval')}  "
        f"n={lm.retrieval_denominator}",
        f"TAG+ROW -> VALUE  (direct)    : {lm.direct_acc*100:6.1f}%  "
        f"chance 1/{lm.n_values}={lm.chance_value_direct:.4f}  "
        f"gain={lm.gain_over_chance('direct')}  n={lm.n_pairs}",
        f"verdict: {verdict(lm)}",
    ]
    return "\n".join(lines)


__all__ = ["C_PREFIX", "CC", "cell_id_for", "cell_key", "arm_streams",
           "stream_is_cell_preserved", "LookupMetrics", "verdict",
           "extract_cell_and_value", "cell_lookup_diagnostics",
           "format_lookup"]