"""Serializer: plain-text <-> typed-atom conversion (verbatim port of
representation/serializer.py).

Converts a plain-language question into the typed-atom stream, and
reverses typed atoms back to a readable form:

    Q : T:ARITHMETIC N:10 R:TIMES N:5 E ASK ARITHMETIC

The serializer is deterministic: the same question always yields the same
atom stream. Within the mapped question forms (the relation map plus the
numeric literal path) the stream retains every distinguishing value;
arbitrary text outside those forms is not covered by that guarantee.
"""

from __future__ import annotations

from .typed_atoms import procedural_atoms

# Number literal <> atom prefix used in the verified encoding.
N_PREFIX = "N:"
R_PREFIX = "R:"
V_PREFIX = "V:"

# operation words in a question -> typed R: relationship atom
_WORD_TO_REL = {
    "plus": "PLUS", "sum": "PLUS", "add": "PLUS", "added": "PLUS",
    "times": "TIMES", "multiplied": "TIMES", "multiply": "TIMES",
    "minus": "MINUS", "subtract": "MINUS", "subtracted": "MINUS",
    "mean": "MEAN", "average": "MEAN",
}


def _iseq(seq, words):
    """True if `words` appears as a contiguous subsequence of the token seq."""
    n = len(words)
    return any(seq[i:i + n] == list(words) for i in range(len(seq) - n + 1))


def parse_question_to_atoms(question: str, tag: str, category: str):
    """Best-effort deterministic extraction of typed content atoms.

    Returns the `content` argument expected by procedural_atoms: a list of
    (prefix, value) pairs that preserve the distinguishing information.
    """
    toks = question.lower().replace("?", "").split()
    content = []

    numbers = [t for t in toks if t.isdigit()]
    if numbers:
        for n in numbers:
            content.append((N_PREFIX, n))
        rel = next((_WORD_TO_REL[w] for w in toks if w in _WORD_TO_REL), None)
        if rel:
            content.append((R_PREFIX, rel))

    # code / method / ownership: action + object words preserved as values
    if _iseq(toks, ["create", "a", "function"]):
        content.append((V_PREFIX, "CREATE"))
        content.append((V_PREFIX, "ADD_TWO_NUMBERS"))
    elif _iseq(toks, ["define", "a", "function"]):
        content.append((V_PREFIX, "DEFINE"))
        content.append((V_PREFIX, "REUSABLE_BEHAVIOR"))
    elif _iseq(toks, ["define", "a", "method"]):
        content.append((V_PREFIX, "DEFINE_METHOD"))
    elif _iseq(toks, ["ownership"]) or _iseq(toks, ["owns"]):
        content.append((V_PREFIX, "EACH_VALUE_ONE_OWNER"))
    elif _iseq(toks, ["predict"]):
        content.append((V_PREFIX, "PREDICT_VALUE"))
    elif _iseq(toks, ["calculate"]) or _iseq(toks, ["compute"]):
        content.append((V_PREFIX, "CALCULATE"))

    return content


def serialize_plain(question: str, tag: str, category: str) -> list[str]:
    """Full typed stream for a plain question (uses the canonical builders)."""
    content = parse_question_to_atoms(question, tag, category)
    return procedural_atoms(tag, category, content)


def deserialize(atoms: list[str]) -> str:
    """Render a typed-atom stream back to readable text."""
    if not atoms:
        return ""
    return " ".join(atoms)


__all__ = ["N_PREFIX", "R_PREFIX", "V_PREFIX", "parse_question_to_atoms",
           "serialize_plain", "deserialize"]