"""Independent main tags (verbatim port of representation/tags.py).

The 23 canonical tags used by the Five-Domain benchmark. These are
INDEPENDENT MAIN SEMANTIC TAGS. The underscore is part of the name and does
NOT imply any parent/child hierarchy or sub-tag relationship.
"""

from __future__ import annotations

# (tag, domain) — canonical 23 independent main tags across 5 domains.
TAGS = [
    # PYTHON domain
    "PYTHON", "PYTHON_FUNCTIONS", "PYTHON_ARCHITECTURE",
    "PYTHON_PROBLEMS", "PYTHON_SOLUTIONS",
    # JAVA domain
    "JAVA", "JAVA_OBJECTS", "JAVA_METHODS", "JAVA_PROBLEMS", "JAVA_SOLUTIONS",
    # RUST domain
    "RUST", "RUST_MEMORY", "RUST_OWNERSHIP", "RUST_PROBLEMS", "RUST_SOLUTIONS",
    # MATHEMATICS domain
    "MATHEMATICS", "ALGEBRA", "CALCULUS", "ARITHMETIC",
    # STATISTICS domain
    "STATISTICS", "PROBABILITY", "REGRESSION", "MEAN",
]

TAG_DOMAIN = {
    "PYTHON": "PYTHON", "PYTHON_FUNCTIONS": "PYTHON",
    "PYTHON_ARCHITECTURE": "PYTHON", "PYTHON_PROBLEMS": "PYTHON",
    "PYTHON_SOLUTIONS": "PYTHON",
    "JAVA": "JAVA", "JAVA_OBJECTS": "JAVA", "JAVA_METHODS": "JAVA",
    "JAVA_PROBLEMS": "JAVA", "JAVA_SOLUTIONS": "JAVA",
    "RUST": "RUST", "RUST_MEMORY": "RUST", "RUST_OWNERSHIP": "RUST",
    "RUST_PROBLEMS": "RUST", "RUST_SOLUTIONS": "RUST",
    "MATHEMATICS": "MATHEMATICS", "ALGEBRA": "MATHEMATICS",
    "CALCULUS": "MATHEMATICS", "ARITHMETIC": "MATHEMATICS",
    "STATISTICS": "STATISTICS", "PROBABILITY": "STATISTICS",
    "REGRESSION": "STATISTICS", "MEAN": "STATISTICS",
}

DOMAINS = ["PYTHON", "JAVA", "RUST", "MATHEMATICS", "STATISTICS"]

__all__ = ["TAGS", "TAG_DOMAIN", "DOMAINS"]