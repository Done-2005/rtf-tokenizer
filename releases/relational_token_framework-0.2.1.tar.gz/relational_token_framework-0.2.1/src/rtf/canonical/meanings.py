"""Custom meanings (verbatim port of representation/meanings.py)."""

from __future__ import annotations

MEANINGS = {
    "PYTHON": ["the", "python", "programming", "language"],
    "PYTHON_FUNCTIONS": ["functions", "and", "callables", "in", "python"],
    "PYTHON_ARCHITECTURE": ["structure", "and", "organization", "of", "a",
                            "python", "system"],
    "PYTHON_PROBLEMS": ["problems", "and", "tasks", "solvable", "in", "python"],
    "PYTHON_SOLUTIONS": ["implementations", "and", "solutions", "for", "python",
                         "problems"],
    "JAVA": ["the", "java", "programming", "language"],
    "JAVA_OBJECTS": ["objects", "classes", "and", "inheritance", "in", "java"],
    "JAVA_METHODS": ["methods", "that", "define", "behavior", "of", "java",
                     "objects"],
    "JAVA_PROBLEMS": ["problems", "and", "tasks", "solvable", "in", "java"],
    "JAVA_SOLUTIONS": ["implementations", "for", "java", "problems"],
    "RUST": ["the", "rust", "systems", "programming", "language"],
    "RUST_MEMORY": ["memory", "safety", "ownership", "and", "borrowing", "in",
                    "rust"],
    "RUST_OWNERSHIP": ["ownership", "the", "rule", "where", "each", "rust",
                       "value", "has", "one", "owner"],
    "RUST_PROBLEMS": ["problems", "and", "tasks", "solvable", "in", "rust"],
    "RUST_SOLUTIONS": ["implementations", "for", "rust", "problems"],
    "MATHEMATICS": ["the", "mathematical", "science", "of", "structure", "and",
                    "quantity"],
    "ALGEBRA": ["algebra", "equations", "and", "symbolic", "manipulation"],
    "CALCULUS": ["calculus", "limits", "derivatives", "and", "integrals"],
    "ARITHMETIC": ["arithmetic", "addition", "subtraction", "multiplication",
                   "and", "division", "of", "numbers"],
    "STATISTICS": ["the", "statistical", "science", "of", "data", "and",
                   "uncertainty"],
    "PROBABILITY": ["probability", "random", "events", "and", "distributions"],
    "REGRESSION": ["regression", "modeling", "and", "prediction", "of", "data"],
    "MEAN": ["the", "average", "of", "a", "set", "of", "numbers"],
}

CATEGORY_MEANINGS = {
    "arithmetic": "numeric computation result",
    "code": "reusable program behavior",
    "method": "class-member behavior definition",
    "ownership": "rust single-owner memory rule",
    "statistic": "data-driven statistical result",
}

__all__ = ["MEANINGS", "CATEGORY_MEANINGS"]