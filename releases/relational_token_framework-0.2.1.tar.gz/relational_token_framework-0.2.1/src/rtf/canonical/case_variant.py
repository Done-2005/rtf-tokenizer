"""RTF-CASE: explicit case metadata as auxiliary structure (experimental arm).

Adds casing as INFORMATION (never removes it): each ``V: VALUE`` atom in a
typed stream gains a ``V_CASE:<kind>`` atom immediately before the ``V:``
prefix. The exact VALUE string stays untouched, so Copy-3 content
preservation holds; the model just no longer has to infer casing purely
from the raw value token.

    baseline stream :  Q : T:ARITHMETIC E V: print R: PLUS ASK ARITHMETIC
    RTF-CASE stream :  Q : T:ARITHMETIC E V_CASE:LOWER V: print R: PLUS ASK ...

This is evaluation- and training-side only. It does NOT modify the frozen
canonical builders (typed_atoms / serializer / encoder). It transforms a
record's problem/answer streams into the variant, which is then fitted
with the union Enc exactly like the baseline (build_case_variant_pairs).

Case kinds (from case_diag.case_kind): UPPER, LOWER, TITLE, MIXED, NONE.
"""

from __future__ import annotations

from .case_diag import case_kind
from .encoder import Enc, build_pairs, make_pair
from .typed_atoms import ASK, COL, E, Q  # noqa: F401 (stream punctuation)

V_CASE = "V_CASE:"

# atoms that are grammar / prefixes, never a concrete value
_NON_VALUE = {"Q", ":", "E", "ASK", "MEANING", "RELATION",
              "T:", "R:", "V:", "N:"}


def case_meta_atom(value: str) -> str:
    """The auxiliary casing atom for a value (V_CASE:LOWER, ...)."""
    return f"{V_CASE}{case_kind(value)}"


def with_case_meta(stream) -> list[str]:
    """Insert a V_CASE:<kind> atom before every V: VALUE in the stream.

    The value atom immediately following ``V:`` is preserved verbatim;
    only the new case atom is added. Streams without ``V:`` values are
    returned unchanged (equal-length slice copy).
    """
    out: list[str] = []
    i = 0
    n = len(stream)
    while i < n:
        tok = stream[i]
        is_value_head = tok == "V:" and i + 1 < n and stream[i + 1] not in _NON_VALUE
        if is_value_head:
            out.append(case_meta_atom(stream[i + 1]))
            out.append(tok)
            out.append(stream[i + 1])
            i += 2
            continue
        out.append(tok)
        i += 1
    return out


def strip_case_meta(stream) -> list[str]:
    """Reverse the variant: drop every V_CASE: atom, restoring baseline."""
    return [tok for tok in stream if not tok.startswith(V_CASE)]


def apply_case_meta_to_records(records) -> list[dict]:
    """Variant copies of compiled records (rtf_in and rtf_out rewritten).

    The gold answer stream keeps its exact values; it gains the same
    case atoms so the model can emit the auxiliary structure.
    """
    variant = []
    for r in records:
        v = dict(r)
        v["rtf_in"] = with_case_meta(v["rtf_in"])
        v["rtf_out"] = with_case_meta(v["rtf_out"])
        variant.append(v)
    return variant


def build_case_variant_pairs(records, enc: Enc | None = None):
    """EncodedPairs for the RTF-CASE arm over the variant streams.

    Uses the same union-vocabulary rule as the baseline: the Enc holds
    every symbol across variant problems and answers, so RTF-CASE and
    BPE arms share identical parameter counts.
    """
    variant = apply_case_meta_to_records(records)
    if enc is None:
        syms = set()
        for r in variant:
            syms.update(r["rtf_in"])
            syms.update(r["rtf_out"])
        enc = Enc(syms)
    return build_pairs(variant, enc,
                       problem_of=lambda r: r["rtf_in"],
                       answer_of=lambda r: r["rtf_out"])


def case_summary(records) -> dict:
    """How many V: values gained a case atom across the records."""
    total = 0
    missing = 0  # V: with no following value (should never happen post-guard)
    for r in records:
        s = r["rtf_in"]
        total += sum(1 for i in range(len(s) - 1)
                     if s[i] == "V:" and s[i + 1] not in _NON_VALUE)
        missing += sum(1 for i in range(len(s) - 1)
                       if s[i] == "V:" and s[i + 1] in _NON_VALUE)
    return {"v_values": total, "v_without_value": missing,
            "variant_per_record": len(records)}


__all__ = ["V_CASE", "case_meta_atom", "with_case_meta", "strip_case_meta",
           "apply_case_meta_to_records", "build_case_variant_pairs",
           "case_summary"]