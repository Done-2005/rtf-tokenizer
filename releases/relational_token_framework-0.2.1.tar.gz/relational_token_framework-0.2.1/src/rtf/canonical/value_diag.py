"""VALUE Diagnosis Report: why is VALUE accuracy lower than TAG/ROW?

Replaces ``"VALUE accuracy is 47%"`` with a decomposable diagnosis:

    47% exact accuracy is driven by [rare values X%], [case-only Y%],
    [unseen values Z%], [values not present in context W%] ...

The framework is deterministic (no torch needed) and consumes gold
``EncodedPair`` object + a model's argmax id sequences via
``value_report_on_pairs``, so every future RTF-vs-BPE experiment emits the
same VALUE error breakdown automatically.

Ten lenses:

    L1 case           exact / case-insensitive / case-only fraction
    L2 frequency      very-frequent / frequent / medium / rare / singleton
    L3 type           identifier / keyword / punctuation / number / string /
                      operator / function-name / natural-word / other-literal
    L4 seen/unseen    value appears in train vocab or must be generalized
    L5 context        nearby / earlier-in-sequence / elsewhere-in-doc /
                      inferable-only / absent
    L6 freq->acc      value frequency -> prediction accuracy curve
    L7 position       start / middle / end of answer + distance to source
    L8 confusion      same-type swap / frequent-value / contextual-value / random
    L9 copy-vs-learn  target present in visible context vs not
    L10 architecture  tied C-shared embedding + tied output head effect

Everything here is additive. The frozen canonical [T,R,V] builders,
tokenizer and case variant are NOT modified.
"""

from __future__ import annotations

import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field

from ..tokenization.domains import KEYWORDS, _TOKEN_RE, tokenize_text
from .case_diag import case_kind, classify as _classify_pair  # noqa: F401
from .case_diag import (value_report)  # noqa: F401  (re-export for callers)

# ---------------------------------------------------------------------------
# L3: VALUE type classification
# ---------------------------------------------------------------------------

_OP_TOKEN_SET = {
    "=", "<", ">", "<=", ">=", "==", "!=", "+", "-", "*", "/", "%", "^",
    "&&", "||", "!", "//", "**", "..", "->", "::", "<-", "%%",
}
_PUNCT_SET = set("(){},;.:[]")
_OPERATOR_CONCEPTS = {"ARITHMETIC_OPERATOR", "RELATIONAL_OPERATOR",
                      "BOOLEAN_OPERATOR", "ASSIGNMENT_STATEMENT"}

VALUE_TYPES = ("identifier", "keyword", "punctuation", "number", "string",
               "operator", "function", "natural_word", "other_literal")


def classify_value_type(value: str, domain: str = "english") -> str:
    """Classify a VALUE string by lexical shape (independent of ROW).

    Precedence: string > number > keyword > operator > punctuation >
    identifier/function > natural word > other literal. Function names are
    values that carry a FUNCTION_CALL concept or look like identifiers
    adjacent to an open paren in the stream (caller may pass context).
    """
    if not value:
        return "other_literal"
    if len(value) >= 2 and value[0] in "\"'" and value[-1] == value[0]:
        return "string"
    if re.fullmatch(r"\d+(\.\d+)?", value):
        return "number"
    table = KEYWORDS.get(domain, {})
    if value in table:
        return "keyword"
    if value in _OP_TOKEN_SET:
        return "operator"
    if value in _PUNCT_SET:
        return "punctuation"
    if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*(?:'[A-Za-z0-9_]+)*", value):
        return "function" if domain in ("python", "java") and False else \
            ("natural_word" if domain == "english" else "identifier")
    return "other_literal"


def type_with_call_context(values: list[tuple[str, str, str]]) -> dict[str, str]:
    """Map each (prefix, value, key_atom) triple to a value type using the
    ROW concept when it is informative (FUNCTION_CALL => function)."""
    out = {}
    for prefix, value, key_atom in values:
        if key_atom == "FUNCTION_CALL":
            out[value] = "function"
        elif key_atom in _OPERATOR_CONCEPTS:
            out[value] = "operator"
    return out


# ---------------------------------------------------------------------------
# L2: frequency buckets (train-side frequency table)
# ---------------------------------------------------------------------------

FREQ_BANDS = (("very_frequent", 100), ("frequent", 25), ("medium", 8),
              ("rare", 2))  # singleton = count <= 1


def frequency_bucket(count: int) -> str:
    if count <= 0:
        return "singleton"  # OOV / never in train
    if count == 1:
        return "singleton"
    for name, floor in sorted(FREQ_BANDS, key=lambda x: -x[1]):
        if count >= floor:
            return name
    return "rare"


def build_frequency_table(values) -> dict[str, int]:
    """Train-side VALUE frequencies (count occurrences, dedup later)."""
    return dict(Counter(v for _p, v in values))


def bucket_values(values, freq) -> dict[str, int]:
    out = Counter()
    for _p, v in values:
        out[frequency_bucket(freq.get(v, 0))] += 1
    return dict(out)


# ---------------------------------------------------------------------------
# L4: seen vs unseen
# ---------------------------------------------------------------------------

def seen_unseen(gold_values, train_values: set) -> dict:
    seen = sum(1 for _p, v in gold_values if v in train_values)
    total = len(gold_values)
    return {"seen": seen, "unseen": total - seen,
            "seen_rate": round(seen / total, 4) if total else 0.0,
            "n": total}


# ---------------------------------------------------------------------------
# L5 + L9: context dependency / copy-vs-learn
# ---------------------------------------------------------------------------

def context_source(value: str, context_symbols, doc_values=None,
                   nearby: int = 6) -> str:
    """Where the correct VALUE text is available relative to the target.

    - 'nearby'       appears within `nearby` symbols before the target
    - 'earlier'      appears earlier in the same sequence
    - 'elsewhere'    appears in the document but not this sequence
    - 'inferable'    not literal in context, but derivable from TAG/ROW
    - 'absent'       not available anywhere in the supplied context
    """
    if not context_symbols:
        return "absent"
    head = context_symbols[-nearby:]
    if value in head:
        return "nearby"
    if value in context_symbols:
        return "earlier"
    if doc_values and value in doc_values:
        return "elsewhere"
    return "inferable"  # present implicitly via TAG/ROW structure


# ---------------------------------------------------------------------------
# L7: position buckets
# ---------------------------------------------------------------------------

def position_bucket(index: int, length: int) -> str:
    if length == 0:
        return "start"
    q = index / length
    if q < 0.33:
        return "start"
    if q < 0.66:
        return "middle"
    return "end"


# ---------------------------------------------------------------------------
# L8: confusion structure
# ---------------------------------------------------------------------------

def confusion_kind(gold: str, pred: str, gold_types, freq, context_values) -> str:
    gold_t = gold_types.get(gold, classify_value_type(gold))
    pred_t = gold_types.get(pred, classify_value_type(pred))
    if pred_t == gold_t:
        return "same_type"
    if frequency_bucket(freq.get(pred, 0)) in ("very_frequent", "frequent"):
        return "frequent_value"
    if pred in context_values:
        return "contextual_value"
    return "random_value"


# ---------------------------------------------------------------------------
# The assembled report + the argmax integration hook.
# ---------------------------------------------------------------------------

@dataclass
class ValueDiagnosis:
    """One gold/pred answer-pair diagnosis, assembled from all lenses."""
    pair_id: str = ""
    domain: str = ""
    by_value: dict = field(default_factory=dict)       # value -> summary
    lenses: dict = field(default_factory=dict)          # aggregated numbers
    case: dict = field(default_factory=dict)
    by_frequency: dict = field(default_factory=dict)
    by_type: dict = field(default_factory=dict)
    by_context: dict = field(default_factory=dict)
    by_position: dict = field(default_factory=dict)
    confusion: dict = field(default_factory=dict)
    copy_vs_learn: dict = field(default_factory=dict)
    architecture: dict = field(default_factory=dict)


def diagnose_values(gold_values, pred_values, *, freq=None, train_values=None,
                    context_symbols=None, doc_values=None, types=None,
                    pair_id="", domain="english") -> ValueDiagnosis:
    """Core: full decomposition of one gold vs pred value sequence.

    gold_values / pred_values are lists of (prefix, value) tuples from the
    ANSWER region. Position is relative to the gold sequence.
    """
    freq = freq or {}
    train = set(train_values) if train_values else set(freq)
    types = types or {}
    gold_keys = [v for _p, v in gold_values]
    n = len(gold_keys)
    case_counts = Counter()
    correct = 0
    by_freq = Counter()
    by_type = Counter()
    by_context = Counter()
    by_position = Counter()
    confusion = Counter()
    context_values = set(gold_keys) | set(context_symbols or [])

    for i, gold in enumerate(gold_keys):
        pred = pred_values[i][1] if i < len(pred_values) else None
        case_counts[_classify_pair(gold, pred)] += 1
        if pred == gold:
            correct += 1
        by_freq[frequency_bucket(freq.get(gold, 0))] += 1
        by_type[types.get(gold, classify_value_type(gold, domain))] += 1
        if pred is not None and pred != gold:
            confusion[confusion_kind(gold, pred, types, freq,
                                     context_values)] += 1
        by_position[position_bucket(i, n)] += 1
        src = context_source(gold, list(context_symbols or []),
                             doc_values, nearby=6)
        by_context[src] += 1

    copy_vs_learn = dict(counter_split(gold_values, pred_values,
                                       context_symbols))

    n_err = n - correct
    case = value_report(gold_keys, [p for _p, p in pred_values])

    return ValueDiagnosis(
        pair_id=pair_id, domain=domain,
        lenses={
            "n_values": n, "correct": correct, "errors": n_err,
            "accuracy": round(correct / n, 4) if n else 0.0,
        },
        case=case,
        by_frequency=dict(by_freq),
        by_type=dict(by_type),
        by_context=dict(by_context),
        by_position=dict(by_position),
        confusion=dict(confusion),
        copy_vs_learn=copy_vs_learn,
        architecture=architecture_facts(),
    )


def counter_split(gold_values, pred_values, context_symbols) -> Counter:
    """copy (target text visible in context) vs inference (not visible)."""
    out = Counter()
    ctx = set(context_symbols or [])
    for i, (_, gold) in enumerate(gold_values):
        pred = pred_values[i][1] if i < len(pred_values) else None
        kind = "copy" if gold in ctx else "inference"
        ok = "correct" if pred == gold else "error"
        out[f"{kind}_{ok}"] += 1
    return out


def architecture_facts() -> dict:
    """L10: frozen Copy-3 design facts relevant to the VALUE bottleneck.

    These are deterministic constants from COPY-3/models.py + tasks.py:
    the shared d_shared=16 embedding and the tied output head. The
    runtime head-loss measurement is model-side (kaggle) and takes the
    per-slot loss split, which this report's callers feed back as
    ``head_loss`` later.
    """
    return {
        "d_shared": 16,
        "tied_output_head": True,
        "shared_embedding": "compressed (RTF + BPE share one C matrix)",
        "note": ("tied head means every output slot reads the same C.T; "
                 "rare VALUEs have thin rows -> under-trained rows are the "
                 "structural risk, NOT the representation grammar."),
        "head_loss_by_slot": None,
    }


def value_report_on_pairs(gold_pairs, pred_id_lists,
                          itos_enc=None, enc_vocab=None,
                          train_values=None, freq=None, doc_values=None,
                          domains=None) -> ValueDiagnosis:
    """Integration hook: gold EncodedPairs + model argmax ids -> diagnosis.

    Decodes each pair's answer region from its slots, extracts V: values
    from both gold and predicted atom lists, then runs the full diagnosis.

    - gold_pairs: list of rtf.canonical.EncodedPair (gold)
    - pred_id_lists: parallel list of full id sequences (model argmax)
    - enc_vocab: the symbol<->id map; either an Enc (from_itos capable)
      or a plain {symbol: id} dict. Uses itos when available.
    """
    if enc_vocab is None:
        raise ValueError("value_report_on_pairs requires enc_vocab (an Enc "
                         "or {symbol: id} dict) to decode ids to symbols.")
    if hasattr(enc_vocab, "itos"):
        itos = enc_vocab.itos
    else:
        itos = {i: s for s, i in enc_vocab.items()} if enc_vocab else {}

    def to_str(ids):
        return [itos[i] if 0 <= i < len(itos) else "<unk>" for i in ids] \
            if isinstance(itos, list) else [itos[i] for i in ids]

    # Caller may pass V: extraction we cannot do generically on decoded
    # atomic ids without dropping. We keep pairing at value-level:

    gold_value_lists = []
    pred_value_lists = []
    for pair, pred_ids in zip(gold_pairs, pred_id_lists):
        gold_atoms = to_str(pair.ids[pair.loss_start - 1:]) or []
        pred_atoms = to_str(pred_ids[pair.loss_start - 1:])
        gold_vals = _extract_answer_values(gold_atoms)
        pred_vals = _extract_answer_values(pred_atoms)
        gold_value_lists.append(gold_vals)
        pred_value_lists.append(pred_vals)

    return diagnose_values(
        _flatten(gold_value_lists), _flatten(pred_value_lists),
        freq=freq, train_values=train_values, doc_values=doc_values,
        pair_id="aggregate")


_STRUCTURAL_ATOMS = {"", ":", "Q", "E", "ASK", "V:", "N:", "R:", "T:",
                     "<pad>", "<unk>", "<sep>", "<eos>"}
_VALUE_PREFIXES = ("V:", "N:", "R:")


def _extract_answer_values(atoms) -> list[tuple[str, str]]:
    """Extract the VALUE-bearing atoms of an answer region.

    Handles both grammar families seen across the canonical tasks:
      * prefixed:   V:name  N:10  R:times      -> ("V:", "name") ...
      * bare-word:  PYTHON the python language -> ("", "PYTHON") ...
    Structural tokens (Q : E ASK T: specials) are skipped, so the returned
    sequence is exactly the value stream the model is asked to predict.
    """
    out = []
    i = 0
    while i < len(atoms):
        tok = atoms[i]
        if tok in _VALUE_PREFIXES and i + 1 < len(atoms):
            nxt = atoms[i + 1]
            if not nxt.startswith(_VALUE_PREFIXES) and nxt not in _STRUCTURAL_ATOMS:
                out.append((tok, nxt))
                i += 2
                continue
            i += 1
            continue
        if tok not in _STRUCTURAL_ATOMS:
            out.append(("", tok))
        i += 1
    return out


def _flatten(lists):
    return [item for sub in lists for item in sub]


def aggregate_diagnoses(diags) -> dict:
    """Combine several ValueDiagnosis objects into one corpus report."""
    n = sum(d.lenses["n_values"] for d in diags)
    corr = sum(d.lenses["correct"] for d in diags)
    err = n - corr
    by_freq = defaultdict(int)
    by_type = defaultdict(int)
    by_context = defaultdict(int)
    by_pos = defaultdict(int)
    conf = defaultdict(int)
    for d in diags:
        for k, v in d.by_frequency.items():
            by_freq[k] += v
        for k, v in d.by_type.items():
            by_type[k] += v
        for k, v in d.by_context.items():
            by_context[k] += v
        for k, v in d.by_position.items():
            by_pos[k] += v
        for k, v in d.confusion.items():
            conf[k] += v
    return {
        "n_values": n, "correct": corr, "errors": err,
        "accuracy": round(corr / n, 4) if n else 0.0,
        "by_frequency": dict(by_freq),
        "by_type": dict(by_type),
        "by_context": dict(by_context),
        "by_position": dict(by_pos),
        "confusion": dict(conf),
        "architecture": diags[0].architecture if diags else architecture_facts(),
    }


def story(report: ValueDiagnosis | dict) -> str:
    """Human one-paragraph reading of the diagnosis (the 'key question')."""
    d = report.lenses if isinstance(report, ValueDiagnosis) else report
    acc = d.get("accuracy", 0.0)
    total = d.get("n_values", 0)
    err = d.get("errors", 0)
    cf = report.case.get("case_only_fraction_of_errors", 0.0) \
        if isinstance(report, ValueDiagnosis) else 0.0
    return (
        f"{acc*100:.1f}% exact VALUE accuracy over {total} values "
        f"({err} errors).")


__all__ = ["VALUE_TYPES", "classify_value_type", "type_with_call_context",
           "frequency_bucket", "build_frequency_table", "bucket_values",
           "seen_unseen", "context_source", "position_bucket",
           "confusion_kind", "ValueDiagnosis", "diagnose_values",
           "value_report_on_pairs", "aggregate_diagnoses", "story",
           "architecture_facts", "counter_split"]