"""Permanent safety checks (verbatim ports of validation/schema_guard.py,
validation/collision_audit.py and validation/parameter_check.py).

Three checks guard the Copy-3 pipeline BEFORE any training happens:

  #1  schema_guard     - every procedural record row has the expected shape
  #2  collision_audit  - no two different questions encode to the SAME input
                         with DIFFERENT answers (the v3 rule; aborts)
  #3  parameter_check  - RTF vs BPE arms share identical parameter counts
                         (union vocabulary => equal Copy-3 sizes)
"""

from __future__ import annotations

import sys


def assert_row_len(row, expected: int = 6):
    """Permanent safety check #1 (v2 five-field-row bug): a row MUST have the
    expected number of fields. Raises ValueError otherwise."""
    if len(row) != expected:
        raise ValueError(
            f"row has {len(row)} fields, expected {expected}: {row}")


def guard_records(records, expected: int = 6):
    """Apply the schema guard to every procedural question row in a record
    list (records already built keep 6 fields per build_records)."""
    for r in records:
        if r["category"] in ("definition", "relation"):
            continue
        assert_row_len((r["top_tag"], r["category"], r["text_in"],
                        r["text_out"], " ".join(r["rtf_out"]),
                        _content_of(r)), expected)


def _content_of(rec):
    """Reconstruct the (prefix, value) content list from a built record's
    procedural typed input: everything between the E and ASK atoms."""
    stream = list(rec["rtf_in"])
    try:
        e_idx = stream.index("E")
    except ValueError:
        return []
    rest = stream[e_idx + 1:]
    content = []
    i = 0
    while i < len(rest) - 1:
        prefix, value = rest[i], rest[i + 1]
        if prefix in ("N:", "R:", "V:") and not value.startswith(("N:", "R:", "V:")):
            content.append((prefix, value))
            i += 2
        else:
            i += 1
    return content


# ---------------------------------------------------------------------------
# Safety check #2: input-fidelity collision audit.
# ---------------------------------------------------------------------------

COLLISION_MSG = (
    "[audit] FAILURE: identical input -> different gold answers. "
    "Aborting before training."
)


def audit_collisions(records, encode_input, encode_answer,
                     name: str = "arm", raise_on_fail: bool = True) -> int:
    """Map encoded input -> set of gold answers; count inputs with >1 answer.

    Returns the number of colliding inputs (0 == clean). When raise_on_fail
    is True (default), a collision raises SystemExit, stopping before any
    training happens.
    """
    inp2ans: dict[tuple, set] = {}
    for r in records:
        key = tuple(encode_input(r))
        inp2ans.setdefault(key, set()).add(tuple(encode_answer(r)))
    collisions = {k: v for k, v in inp2ans.items() if len(v) > 1}
    if collisions:
        msg = (f"{COLLISION_MSG} {name}: {len(collisions)} collisions")
        if raise_on_fail:
            raise SystemExit(msg)
    return len(collisions)


def audit_still_clean(records, problem_of, answer_of,
                      name: str = "canonical") -> int:
    """Run the v3 collision audit with the record extractors used at
    training time (problem_of/answer_of map a record to typed symbols)."""
    return audit_collisions(records, lambda r: problem_of(r),
                            lambda r: answer_of(r), name=name)


# ---------------------------------------------------------------------------
# Safety check #3: parameter-count verification.
# ---------------------------------------------------------------------------

def count_parameters(model) -> int:
    """Sum trainable parameters via numel() when available (torch models);
    for the standalone parity check just compare reported counts."""
    if hasattr(model, "parameters"):
        return sum(p.numel() for p in model.parameters() if p.requires_grad)
    return int(model)


def verify_parity(rtf_params: int, bpe_params: int,
                  arm_names=("RTF", "BPE"), require_equal: bool = True) -> bool:
    """Compare two arms' parameter counts; optionally require exact equality."""
    equal = rtf_params == bpe_params
    if require_equal and not equal:
        raise SystemExit(
            f"[params] FAILURE: parameter mismatch "
            f"({arm_names[0]}={rtf_params} vs {arm_names[1]}={bpe_params})")
    return equal


__all__ = ["assert_row_len", "guard_records", "audit_collisions",
           "audit_still_clean", "count_parameters", "verify_parity",
           "COLLISION_MSG", "sys"]