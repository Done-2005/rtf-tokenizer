"""Canonical Copy-3 tokenizer layer (0.1.7).

Ports of the canonical COPY-3 representation/training/validation file
set (completeness and faithfulness census pending), brought into the
package as one coherent new tokenizer:

    canonical/tags.py        -> representation/tags.py
    canonical/meanings.py    -> representation/meanings.py
    canonical/typed_atoms.py -> representation/typed_atoms.py
    canonical/serializer.py  -> representation/serializer.py
    canonical/data.py        -> benchmarks/five_domain/data.py
    canonical/encoder.py     -> training/dataset.py + training/tasks.py
    canonical/validation.py  -> validation/schema_guard.py
                                + validation/collision_audit.py
                                + validation/parameter_check.py
    canonical/registry.py    -> registry.py + register_identity.py
    canonical/tokenizer.py   -> CanonicalTokenizer (the new tokenizer)

The stream grammar is the copy-3 typed-atom stream:

    Q : T:ARITHMETIC N:10 R:TIMES N:5 E ASK ARITHMETIC
    Q : T:PYTHON V:PYTHON E ASK MEANING
    Q : T:PYTHON R:USED_FOR T:STATISTICS E ASK RELATION

with canonical specials [<pad>, <unk>, <sep>, <eos>] (<sep> present), the
Enc union vocabulary, EncodedPair(ids, loss_start, slots) pairs, the three
permanent safety checks (schema guard, collision audit, parameter-check
hook: self-comparison; independent parity not established), and the
per-kind permanent registry (TAG-/ROW-/COL-/CELL-).

Nothing here needs torch or a database; the neural architecture stays in
rtf.architecture and the Copy-3 model is trained on these pairs on Kaggle.
"""

from .tags import DOMAINS, TAG_DOMAIN, TAGS
from .meanings import CATEGORY_MEANINGS, MEANINGS
from .typed_atoms import (ASK, COL, E, Q, R, T, V, definition_answer,
                          definition_atoms, procedural_atoms, relation_atoms)
from .serializer import N_PREFIX, R_PREFIX, V_PREFIX, deserialize, serialize_plain
from .data import DEFS, PROCEDURAL, RELATIONS
from .encoder import (EOS, PAD, SEP, UNK, SPECIALS, Enc, EncodedPair,
                      build_bpe_pieces, build_encoder, build_records, make_pair)
from .validation import (assert_row_len, audit_collisions, audit_still_clean,
                         guard_records, verify_parity)
from .registry import (CELLS, COLS, ROWS, TAGS_REGISTRY,
                       audit_unique, endpoint, group_by_domain, register_cell,
                       register_col, save_json, load_json)
from .case_diag import (align, case_kind, classify, extract_values, summarize,
                        value_report, value_report_streams)
from .case_variant import (V_CASE, apply_case_meta_to_records,
                           build_case_variant_pairs, case_meta_atom,
                           case_summary, strip_case_meta, with_case_meta)
from .value_diag import (VALUE_TYPES, ValueDiagnosis, aggregate_diagnoses,
                         architecture_facts, bucket_values,
                         build_frequency_table, classify_value_type,
                         confusion_kind, context_source, counter_split,
                         diagnose_values, frequency_bucket, position_bucket,
                         seen_unseen, story, type_with_call_context,
                         value_report_on_pairs)
from .slot_diag import (ROW, SLOTS, TAG, VALUE, analyze_positions,
                        canonical_slots, chance_baselines, format_three_way,
                        largest_gap, slot_profile, slot_report_on_pairs)
from .cell_diag import (LookupMetrics, arm_streams, cell_id_for, cell_key,
                        cell_lookup_diagnostics, extract_cell_and_value,
                        format_lookup, verdict)
from .tokenizer import CanonicalTokenizer

__all__ = [
    "CanonicalTokenizer",
    "TAGS", "TAG_DOMAIN", "DOMAINS",
    "MEANINGS", "CATEGORY_MEANINGS",
    "Q", "COL", "T", "R", "V", "E", "ASK",
    "definition_atoms", "relation_atoms", "procedural_atoms", "definition_answer",
    "N_PREFIX", "R_PREFIX", "V_PREFIX", "serialize_plain", "deserialize",
    "DEFS", "RELATIONS", "PROCEDURAL",
    "PAD", "UNK", "SEP", "EOS", "SPECIALS", "Enc", "EncodedPair",
    "build_records", "build_encoder", "build_bpe_pieces", "make_pair",
    "assert_row_len", "guard_records", "audit_collisions",
    "audit_still_clean", "verify_parity",
    "TAGS_REGISTRY", "ROWS", "COLS", "CELLS",
    "register_col", "register_cell", "endpoint", "group_by_domain",
    "audit_unique", "save_json", "load_json",
    # case diagnostic (evaluation-only, additive)
    "case_kind", "classify", "align", "extract_values",
    "value_report", "value_report_streams", "summarize",
    # RTF-CASE variant (experimental arm; frozen canonical untouched)
    "V_CASE", "case_meta_atom", "with_case_meta", "strip_case_meta",
    "apply_case_meta_to_records", "build_case_variant_pairs", "case_summary",
    # VALUE Diagnosis Report (evaluation-only, additive)
    "VALUE_TYPES", "classify_value_type", "type_with_call_context",
    "frequency_bucket", "build_frequency_table", "bucket_values",
    "seen_unseen", "context_source", "position_bucket", "confusion_kind",
    "ValueDiagnosis", "diagnose_values", "value_report_on_pairs",
    "aggregate_diagnoses", "story", "architecture_facts", "counter_split",
    # Slot-level T/R/V diagnosis (evaluation-only, additive)
    "TAG", "ROW", "VALUE", "SLOTS", "canonical_slots", "analyze_positions",
    "slot_profile", "chance_baselines", "largest_gap",
    "slot_report_on_pairs", "format_three_way",
    # CELL-address diagnostics (evaluation-only, additive; NO trained variant)
    "cell_id_for", "cell_key", "arm_streams", "LookupMetrics", "verdict",
    "extract_cell_and_value", "cell_lookup_diagnostics", "format_lookup",
]