"""Permanent global registration (verbatim port of COPY-3/registry.py).

Identity layer, separate from the neural model. The rule (frozen design):

    Identity is permanent and global. Position is not identity.

- Every registered object (TAG, ROW, COL, CELL) receives the NEXT available
  global number in a single monotonic sequence for its kind.
- Numbers NEVER restart by domain, NEVER depend on hierarchy, and are NEVER
  reused. Once TAG-25 exists it belongs to exactly one tag forever.
- Domain membership is metadata, not part of the uniqueness mechanism.
- A number never changes when the model is retrained, when tokenization
  changes, or when the architecture changes.

Persistence boundary: the save/load path currently round-trips state
without schema fields or load-time validation; the permanence rule
above is the design contract, and durable persistence integrity is
specified remediation, not yet implemented.

Three distinct identity concepts (must never be conflated):

    1. Permanent registration number   TAG-7, ROW-57, COL-3, CELL-928471
    2. Scroll/position address         ROW-57 / COL-3   (coordinates)
    3. Neural tokenizer representation Enc.stoi["PYTHON"] == ephemeral int

Only layer 1 is permanent. Layer 3 is an implementation detail that may change.
"""

from __future__ import annotations

import json
from pathlib import Path

from .meanings import MEANINGS as _5D_MEANINGS  # noqa: F401


class Registry:
    """One permanent registration sequence for a kind of object.

    Assignment is idempotent by canonical key: the same real-world object
    (identified by its key) always maps to the same number, even if it is
    re-registered later or appears in several datasets.
    """

    def __init__(self, kind: str, prefix: str):
        self.kind = kind
        self.prefix = prefix            # e.g. "TAG", "ROW", "COL", "CELL"
        self._next = 1                   # next available global number
        self._by_number: dict[int, dict] = {}
        self._by_key: dict[str, int] = {}

    def register(self, key: str, **meta) -> int:
        """Return the permanent number from `key` (metadata is stored on first
        registration and never silently replaced)."""
        if key in self._by_key:
            return self._by_key[key]
        n = self._next
        self._next += 1
        self._by_number[n] = {"key": key, **meta}
        self._by_key[key] = n
        return n

    def number(self, key: str) -> int:
        return self._by_key[key]

    def key(self, n: int) -> str:
        return self._by_number[n]["key"]

    def object(self, n: int) -> dict:
        return self._by_number[n]

    def label(self, n: int) -> str:
        return f"{self.prefix}-{n:06d}"

    def __len__(self):
        return len(self._by_key)

    def __contains__(self, key: str) -> bool:
        return key in self._by_key

    def to_dict(self) -> dict:
        return {"prefix": self.prefix, "next": self._next,
                "objects": {str(n): self._by_number[n]
                            for n in sorted(self._by_number)}}

    def from_dict(self, d: dict) -> "Registry":
        """Load state into THIS registry (mutates in place), returns self."""
        self.kind = d.get("kind", d["prefix"])
        self.prefix = d["prefix"]
        self._next = 1
        self._by_key.clear()
        self._by_number.clear()
        for key, obj in sorted(d["objects"].items()):
            n = int(key)
            self._by_key[obj["key"]] = n
            self._by_number[n] = obj
            self._next = max(self._next, n + 1)
        return self


# ---------------------------------------------------------------------------
# The one permanent register (all four kinds here).
# ---------------------------------------------------------------------------

TAGS_REGISTRY = Registry("tag", "TAG")
ROWS = Registry("row", "ROW")
COLS = Registry("col", "COL")
CELLS = Registry("cell", "CELL")


def register_col(name: str) -> int:
    """Register a canonical column identity (COL-N)."""
    return COLS.register(name)


def last_number(reg: Registry) -> int:
    """The current global endpoint for a registry kind (last assigned number)."""
    return reg._next - 1


def endpoint() -> dict:
    """The current global endpoints (LAST TAG / LAST ROW / LAST COL / LAST CELL)."""
    return {
        "TAG": TAGS_REGISTRY.label(last_number(TAGS_REGISTRY))
        if last_number(TAGS_REGISTRY) else "none",
        "ROW": ROWS.label(last_number(ROWS)) if last_number(ROWS) else "none",
        "COL": COLS.label(last_number(COLS)) if last_number(COLS) else "none",
        "CELL": CELLS.label(last_number(CELLS)) if last_number(CELLS) else "none",
    }


def group_by_domain(reg: Registry) -> dict:
    """Domain-specific storage view of a registry.

    Registration is global; storage is domain-specific. Returns
    {domain: [label, ...]} in registration (arrival) order.
    """
    groups = {}
    for n in sorted(reg._by_number):
        obj = reg._by_number[n]
        dom = obj.get("domain", "?")
        groups.setdefault(dom, []).append(reg.label(n))
    return groups


def coordinate(row_number: int, col_number: int) -> str:
    """Address of a cell by permanent coordinates (position identity)."""
    return f"{ROWS.label(row_number)} / {COLS.label(col_number)}"


def register_cell(row_number: int, col_number: int, content: str) -> int:
    """Register a permanent object identity (CELL-N) for the cell at a
    coordinate, with its content as metadata."""
    return CELLS.register(f"{COLS.key(col_number)}@{ROWS.key(row_number)}",
                          row=ROWS.label(row_number),
                          col=COLS.label(col_number),
                          coordinate=coordinate(row_number, col_number),
                          content=content)


def to_json() -> dict:
    return {"tags": TAGS_REGISTRY.to_dict(), "rows": ROWS.to_dict(),
            "cols": COLS.to_dict(), "cells": CELLS.to_dict()}


def save_json(path) -> None:
    Path(path).write_text(json.dumps(to_json(), indent=2), encoding="utf-8")


def load_json(path) -> dict:
    d = json.loads(Path(path).read_text(encoding="utf-8"))
    TAGS_REGISTRY.from_dict(d["tags"])
    ROWS.from_dict(d["rows"])
    COLS.from_dict(d["cols"])
    CELLS.from_dict(d["cells"])
    return to_json()


def audit_unique() -> dict:
    """Collision audit for the permanent registry: every object kind must have
    exactly one number per real object, and no number may be reused."""
    result = {}
    for name, reg in (("TAG", TAGS_REGISTRY), ("ROW", ROWS),
                      ("COL", COLS), ("CELL", CELLS)):
        unique = len(set(reg._by_number)) == len(reg._by_number)
        monotonic = all(reg.object(n) for n in range(1, reg._next))
        keys_unique = len(set(reg._by_key)) == len(reg._by_key)
        result[name] = {"registered": len(reg), "next": reg._next,
                        "numbers_unique": unique,
                        "keys_unique": keys_unique,
                        "numbers_contiguous": monotonic}
    return result


__all__ = ["Registry", "TAGS_REGISTRY", "ROWS", "COLS", "CELLS",
           "register_col", "last_number", "endpoint", "group_by_domain",
           "coordinate", "register_cell", "to_json", "save_json", "load_json",
           "audit_unique"]