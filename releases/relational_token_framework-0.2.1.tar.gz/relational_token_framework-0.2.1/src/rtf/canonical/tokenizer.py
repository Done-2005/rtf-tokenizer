"""CanonicalTokenizer: the new Copy-3-true tokenizer (0.1.7).

Faithful port of the verified COPY-3 typed-atom pipeline as one installable
tokenizer. Streams use the canonical grammar:

    Q : T:ARITHMETIC N:10 R:TIMES N:5 E ASK ARITHMETIC
    Q : T:PYTHON V:PYTHON E ASK MEANING
    Q : T:PYTHON R:USED_FOR T:STATISTICS E ASK RELATION

Punctuation tokens Q, :, T:, R:, V:, N:, E, ASK are shared by all typed
streams; specials are [<pad>, <unk>, <sep>, <eos>] (<sep> present).

Design (matches the canonical files one-for-one):

- fit():  build_records(defs, relations, procedural) -> Enc union vocab.
- build_pairs():  constructs EncodedPairs (problem + [SEP] + answer +
  [EOS]) with loss_start and solution-region slots. The schema guard
  (row length 6) and collision audit are NOT run here; they run in
  validate() (C05/C06), where collisions abort (SystemExit) before
  any training.
- encode():   token stream -> ids. Unknown symbols map to the <unk> id
  silently (no error, count, or report); lossless only for fully
  covered streams; coverage diagnostics arrive with the DEC-01 API.
- decode():   ids -> typed symbol stream.
- A problem/answer stream pair is available via definition_atoms /
  relation_atoms / procedural_atoms and serialize_plain.
- Cross-domain is rtf.cross_domain (no invented edges); the "verified"
  label is not yet backed by an attached evidence chain.
- The identity layer is rtf.canonical.registry (TAG-/ROW-/COL-/CELL-):
  permanent by design rule; durable persistence is not yet established
  (its save/load has no schema fields or load-time validation).
"""

from __future__ import annotations

import json

from ..cross_domain import RelationshipGraph, DeterministicExecutor
from .data import DEFS, PROCEDURAL, RELATIONS
from .encoder import (EOS, PAD, SEP, UNK, Enc, EncodedPair, build_records,
                      make_pair)
from .serializer import V_PREFIX, deserialize, serialize_plain
from .tags import TAG_DOMAIN
from .typed_atoms import (ASK, COL, E, Q, definition_answer, definition_atoms,
                          procedural_atoms, relation_atoms)
from .validation import audit_collisions, guard_records, verify_parity

_N_PREFIX = "N:"


class CanonicalTokenizer:
    """Canonical Copy-3 tokenizer over typed-atom streams (DB-free)."""

    kind = "canonical"

    def __init__(self, domains=None) -> None:
        self._enc: Enc | None = None
        self._records: list[dict] = []
        self._text_fitted = False
        self.domains = list(domains or TAG_DOMAIN.values())
        self.specials = [PAD, UNK, SEP, EOS]

    # --- construction --------------------------------------------------

    def fit(self, defs=None, relations=None, procedural=None) -> "CanonicalTokenizer":
        """Build canonical records from the source tables and the union Enc."""
        defs = list(defs if defs is not None else DEFS)
        relations = list(relations if relations is not None else RELATIONS)
        procedural = list(procedural if procedural is not None else PROCEDURAL)
        self._records = build_records(defs, relations, procedural)
        guard_records(self._records)
        syms = set()
        for r in self._records:
            syms.update(r["rtf_in"])
            syms.update(r["rtf_out"])
        self._enc = Enc(syms)
        self._text_fitted = False
        return self

    def fit_texts(self, texts, languages=None) -> "CanonicalTokenizer":
        """Fit a canonical tokenizer from raw texts using the 5-domain atom
        tokenizer, building a content-preserving typed stream per text
        (content-preserving for covered inputs; uncovered symbols map to
        <unk> silently, see encode()).

        Each text becomes a procedural record (tag detected per domain) with
        the full typed stream as its problem and the SAME typed stream as its
        answer container via definition-style triples. OOV text values are
        preserved as V:/N: typed atoms (v3 rule), so identical inputs can
        never carry different answers.
        """
        from ..tokenization.domains import TAGS as CAMPAIGN_TAGS
        from ..tokenization.domains import detect_domain, tokenize_text

        symbols: set[str] = set()
        records = []
        for index, text in enumerate(texts):
            lang_hint = languages if isinstance(languages, str) else None
            if isinstance(languages, (list, tuple)):
                lang_hint = languages[index] if index < len(languages) else None
            lang, atoms = tokenize_text(str(text), lang_hint)
            tag = CAMPAIGN_TAGS.get(lang, "PYTHON")
            content = []
            for concept, value in atoms:
                if concept in ("INTEGER_LITERAL", "FLOAT_LITERAL"):
                    content.append((_N_PREFIX, value))
                else:
                    content.append((V_PREFIX, value))
            stream = procedural_atoms(tag, lang, content)
            records.append({"id": f"TXT_{index}", "domain": tag, "cross": False,
                            "category": "value", "top_tag": tag,
                            "text_in": str(text), "rtf_in": stream,
                            "text_out": str(text), "rtf_out": list(stream)})
            symbols.update(stream)
        self._records = records
        self._enc = Enc(sorted(symbols))
        return self

    # --- vocab ---------------------------------------------------------

    @property
    def vocab_size(self) -> int:
        if self._enc is None:
            raise ValueError("tokenizer is not fitted")
        return self._enc.vocab_size

    @property
    def records(self) -> list[dict]:
        return list(self._records)

    def vocab(self) -> dict[str, int]:
        if self._enc is None:
            raise ValueError("tokenizer is not fitted")
        return dict(self._enc.stoi)

    @property
    def stoi(self) -> dict[str, int]:
        if self._enc is None:
            raise ValueError("tokenizer is not fitted")
        return self._enc.stoi

    @property
    def itos(self) -> list[str]:
        if self._enc is None:
            raise ValueError("tokenizer is not fitted")
        return list(self._enc.itos)

    def token_to_id(self, token: str) -> int:
        if self._enc is None:
            raise ValueError("tokenizer is not fitted")
        return self._enc.stoi.get(token, self._enc.stoi[UNK])

    def id_to_token(self, token_id: int) -> str:
        if self._enc is None:
            raise ValueError("tokenizer is not fitted")
        if 0 <= token_id < len(self._enc.itos):
            return self._enc.itos[token_id]
        return UNK

    # --- canonical typed streams (vector = list of symbol strings) -----

    def definition_stream(self, tag: str) -> list[str]:
        return definition_atoms(tag)

    def relation_stream(self, subj: str, rel: str, obj: str) -> list[str]:
        return relation_atoms(subj, rel, obj)

    def procedural_stream(self, tag: str, category: str,
                          content) -> list[str]:
        return procedural_atoms(tag, category, content)

    def definition_answer_stream(self, tag: str) -> list[str]:
        return definition_answer(tag)

    def serialize(self, question: str, tag: str, category: str) -> list[str]:
        """Plain question -> typed stream (canonical serializer)."""
        return serialize_plain(question, tag, category)

    def deserialize(self, atoms: list[str]) -> str:
        """Typed stream -> readable text."""
        return deserialize(atoms)

    # --- int encoding --------------------------------------------------

    def encode(self, stream) -> list[int]:
        """Typed symbol stream -> ids. Unknown symbols map to the <unk> id
        silently (no error, count, or report); <eos> appended."""
        if self._enc is None:
            raise ValueError("tokenizer is not fitted")
        unk = self._enc.stoi[UNK]
        eos = self._enc.stoi[EOS]
        return [self._enc.stoi.get(t, unk) for t in stream] + [eos]

    def encode_text(self, text: str, language: str | None = None) -> list[int]:
        """Encode a raw text into typed atoms.

        Requires a fitted tokenizer. Every atom's value encodes as a V:
        atom; numeric-literal N: routing exists only in ``fit_texts``
        (the two paths are representation-mismatched, pending
        reconciliation). Uncovered symbols map to the <unk> id silently
        (no error, count, or report); lossless only for fully covered
        streams. To get a flood-free vocab over raw text, fit on those
        texts first with ``fit_texts`` (which builds the Enc from the
        texts' own typed atoms).
        """
        if self._enc is None:
            raise ValueError("tokenizer is not fitted")
        from ..tokenization.domains import TAGS as CAMPAIGN_TAGS
        from ..tokenization.domains import detect_domain, tokenize_text

        lang = language or detect_domain(text)
        _, atoms = tokenize_text(text, lang)
        content = [(V_PREFIX, v) for _c, v in atoms]
        tag = CAMPAIGN_TAGS.get(lang, "PYTHON")
        stream = procedural_atoms(tag, lang, content)
        return self.encode(stream)

    def encode_question(self, question: str, tag: str, category: str) -> list[int]:
        """Plain question -> typed stream -> ids (canonical serializer)."""
        return self.encode(serialize_plain(question, tag, category))

    # --- pairs ---------------------------------------------------------

    def make_pair(self, problem, answer, pair_id: str = "p",
                  solution_domain: str = "direct") -> EncodedPair:
        """EncodedPair: ids = problem + [SEP] + answer + [EOS]."""
        if self._enc is None:
            raise ValueError("tokenizer is not fitted")
        return make_pair(self._enc, problem, answer, pair_id, solution_domain)

    def build_pairs(self):
        """EncodedPairs for every fitted record (solution region loss)."""
        pairs = []
        for r in self._records:
            pairs.append(make_pair(self._enc, r["rtf_in"], r["rtf_out"],
                                   pair_id=r["id"],
                                   solution_domain=r["domain"]))
        return pairs

    # --- decoding ------------------------------------------------------

    def decode(self, ids) -> list[str]:
        if self._enc is None:
            raise ValueError("tokenizer is not fitted")
        return [self._enc.itos[i] if 0 <= i < len(self._enc.itos) else UNK
                for i in ids]

    def decode_triples(self, ids) -> list[tuple[str, str, str]]:
        """Decode a typed stream back to (prefix, value, kind) triples.

        Split the canonical stream on its E/ASK boundaries: every (prefix,
        value) content pair becomes (prefix, value, 'PROCEDURAL_CONTENT');
        T: pivots and the ASK category are reported as structural atoms.
        """
        syms = [s for s in self.decode(ids) if s not in (PAD, EOS)]
        triples: list[tuple[str, str, str]] = []
        i = 0
        while i < len(syms):
            s = syms[i]
            if s in (Q, COL, E, ASK):
                i += 1
                continue
            if s == "MEANING":
                triples.append((s, "", "CATEGORY"))
                i += 1
                continue
            if s == "RELATION":
                triples.append((s, "", "CATEGORY"))
                i += 1
                continue
            if s.startswith("T:"):
                triples.append((s[:2], s[2:], "TAG"))
                i += 1
                continue
            if s.startswith(("N:", "R:", "V:")):
                prefix, value = s[:2], s[2:]
                triples.append((prefix, value, "CONTENT"))
                i += 1
                continue
            # bare token: keep verbatim as an answer atom
            triples.append(("", s, "ANSWER"))
            i += 1
        return triples

    # --- cross-domain (verified function, no invented edges) -----------

    def relationships(self, tag: str):
        from ..cross_domain import RelationshipGraph
        return RelationshipGraph().outgoing(tag)

    def cross_domain(self, subj: str, rel=None, obj=None):
        from ..cross_domain import DeterministicExecutor
        return DeterministicExecutor().check(
            subj=subj,
            rel=str(rel).upper() if rel is not None else None,
            obj=obj)

    def respond_relation(self, subj: str, rel=None, obj=None) -> list[str]:
        from ..cross_domain import DeterministicExecutor
        return DeterministicExecutor().respond(
            subj=subj,
            rel=str(rel).upper() if rel is not None else None,
            obj=obj)

    # --- validation / safety checks ------------------------------------

    def validate(self) -> list[dict]:
        """Run the canonical permanent safety checks over the fitted state.

        Returns [{"code", "status", "detail"}]; status 'PASS'/'FAIL'.
        """
        findings: list[dict] = []
        if self._enc is None:
            return [{"code": "C00", "status": "FAIL",
                     "detail": "not fitted"}]

        present = {s for s in self.specials if s in self._enc.stoi}
        findings.append({
            "code": "C01", "status": "PASS" if present == set(self.specials)
            else "FAIL",
            "detail": f"canonical specials present (incl <sep>): "
                      f"{sorted(present)}"})

        contiguous = all(self._enc.stoi[s] == i and self._enc.itos[i] == s
                         for i, s in enumerate(self._enc.itos))
        findings.append({
            "code": "C02", "status": "PASS" if contiguous else "FAIL",
            "detail": f"Enc ids contiguous: {contiguous}"})

        bijective = len(self._enc.stoi) == len(self._enc.itos)
        findings.append({
            "code": "C03", "status": "PASS" if bijective else "FAIL",
            "detail": f"stoi/itos bijective: {bijective}"})

        # grammar: canonical streams round-trip through decode_triples
        probe = [
            self.definition_stream("PYTHON"),
            self.relation_stream("PYTHON", "USED_FOR", "STATISTICS"),
            self.procedural_stream("ARITHMETIC", "arithmetic",
                                   [("N:", "10"), ("R:", "TIMES"),
                                    ("N:", "5")]),
        ]
        grammar_ok = all(
            len(self.decode_triples(self.encode(stream))) >= 3
            for stream in probe)
        findings.append({
            "code": "C04", "status": "PASS" if grammar_ok else "FAIL",
            "detail": "typed-atom stream grammar round-trips"})

        # schema guard: every procedural record keeps 6-field shape
        try:
            guard_records(self._records)
            findings.append({"code": "C05", "status": "PASS",
                             "detail": "schema_guard: rows length 6"})
        except ValueError as exc:
            findings.append({"code": "C05", "status": "FAIL",
                             "detail": f"schema_guard: {exc}"})

        # collision audit: identical input -> different answers is fatal
        try:
            audit_collisions(self._records,
                             lambda r: r["rtf_in"],
                             lambda r: r["rtf_out"],
                             "canonical")
            findings.append({"code": "C06", "status": "PASS",
                             "detail": "collision_audit: 0 collisions"})
        except SystemExit as exc:
            findings.append({"code": "C06", "status": "FAIL",
                             "detail": str(exc)})

        # parameter parity hook (RTF vs BPE arms on the union vocab)
        equal = verify_parity(self.vocab_size, self.vocab_size,
                              require_equal=True)
        findings.append({
            "code": "C07", "status": "PASS" if equal else "FAIL",
            "detail": f"parameter_check equal params: {equal}"})
        return findings

    # --- persistence ---------------------------------------------------

    def save(self, path) -> str:
        if self._enc is None:
            raise ValueError("tokenizer is not fitted")
        payload = {
            "kind": self.kind, "domains": self.domains,
            "itos": self._enc.itos,
            "records": [{k: v for k, v in r.items()} for r in self._records],
        }
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False)
        return str(path)

    @classmethod
    def load(cls, path) -> "CanonicalTokenizer":
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        tok = cls(domains=data.get("domains"))
        tok._records = [dict(r) for r in data.get("records", [])]
        tok._enc = Enc.from_itos(data["itos"])
        tok._text_fitted = False
        return tok


__all__ = ["CanonicalTokenizer"]