from __future__ import annotations


class RTFError(Exception):
    """Base class for all RTF-V5 errors."""


class UnknownDomainError(RTFError):
    """Raised when a source cannot be attributed to a supported domain."""


class NonAtomicValueError(RTFError):
    def __init__(self, value: str, reason: str) -> None:
        super().__init__(reason)
        self.value = value
        self.reason = reason


class SemanticConflictError(RTFError):
    """Raised when a manual mapping would contradict an existing mapping."""


class UnresolvedConceptError(RTFError):
    """Raised when strict mode forbids returning an unresolved row."""


class ValidationFailure(RTFError):
    def __init__(self, findings: list) -> None:
        super().__init__("validation failed")
        self.findings = findings
