from __future__ import annotations

TAG_WIDTH = 6
ROW_WIDTH = 6
VALUE_WIDTH = 6
CELL_WIDTH = 6
ELEMENT_WIDTH = 6
DOCUMENT_WIDTH = 4
OCCURRENCE_WIDTH = 6


def format_tag_code(tag_id: int) -> str:
    return f"TAG_{tag_id:0{TAG_WIDTH}d}"


def format_row_code(row_id: int) -> str:
    return f"ROW_{row_id:0{ROW_WIDTH}d}"


def format_value_code(value_id: int) -> str:
    return f"VAL_{value_id:0{VALUE_WIDTH}d}"


def format_cell_code(cell_id: int) -> str:
    return f"CELL_{cell_id:0{CELL_WIDTH}d}"


def format_element_code(element_id: int) -> str:
    return f"STRUCT_{element_id:0{ELEMENT_WIDTH}d}"
