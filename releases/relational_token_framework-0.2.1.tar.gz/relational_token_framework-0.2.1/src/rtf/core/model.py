"""Shared data model for RTF-V5."""

from __future__ import annotations

from dataclasses import dataclass, field

SCHEMA_VERSION = "5.3.0"

PARSER_VERSION = "1.0.0"

# Lexical provenance of an extracted atom. This is a fact about the SOURCE
# TEXT, established by the lexer, not a semantic judgement: CODE means the atom
# was read from executable code, COMMENT means it was read from a comment
# region. Ingestion, not the parser, decides what to do about a COMMENT atom.
CODE_ORIGIN = "CODE"
COMMENT_ORIGIN = "COMMENT"
# STRING means the atom was read from a string literal. Tracked, NOT enforced:
# a string literal is legitimate content routed to its own address, so nothing
# is refused on this basis. It is recorded so occurrence-level metrics can
# separate string-origin from code-origin instead of reporting both as CODE,
# and so COMMENT continues to mean exactly one thing - "ingestion may refuse
# this" - rather than "the lexer found it somewhere non-executable".
STRING_ORIGIN = "STRING"


@dataclass
class RTFConfig:
    """Engine configuration. Defaults implement the no-fabrication policy."""

    auto_row_creation: bool = False
    matrix_default_marker: str = "EMPTY"  # marker shown for intersections with no facts
    include_delimiters: bool = True
    similarity_threshold: float = 0.95

    @classmethod
    def from_json(cls, path) -> "RTFConfig":
        import json
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in data.items() if k in known})


@dataclass
class Extraction:
    """One atomic extraction proposed by a parser.

    concept: canonical universal concept name proposed by the parser
             (a PARSER_RULE proposal; the semantic layer still adjudicates it).
    value:   the atomic source-level literal.
    line/col: 1-based source position when the parser can provide it.
    provenance: CODE or COMMENT - where the atom was read from, lexically.
             A COMMENT atom is still extracted (never silently dropped) so the
             refusal can be audited later; it is simply not program structure.
    """

    concept: str
    value: str
    line: int | None = None
    col: int | None = None
    provenance: str = CODE_ORIGIN


@dataclass
class StructureNode:
    """A higher-level structural element proposed by a parser.

    children are nested nodes; leaf_values index into the parser's flat
    extraction list (by position), so structure references atoms without
    duplicating them.
    """

    kind: str                      # CONDITIONAL_EXPRESSION, LOOP_STRUCTURE, ...
    role: str = "ROOT"             # role inside its parent
    label: str = ""
    leaf_indices: list[int] = field(default_factory=list)
    children: list["StructureNode"] = field(default_factory=list)


@dataclass
class Rejection:
    raw: str
    reason: str
    line: int | None = None
    col: int | None = None
    provenance: str = CODE_ORIGIN


@dataclass
class ParseResult:
    extractions: list[Extraction] = field(default_factory=list)
    rejected: list[Rejection] = field(default_factory=list)
    structures: list[StructureNode] = field(default_factory=list)


@dataclass
class IngestionReport:
    document_id: int | None = None
    tag_code: str | None = None
    language: str | None = None
    duplicate_document: bool = False
    cells_created: int = 0
    cells_duplicate: int = 0
    values_created: int = 0
    occurrences_recorded: int = 0
    unresolved: list[tuple[str, str]] = field(default_factory=list)
    rejections: list[Rejection] = field(default_factory=list)
    structures_created: int = 0
    # Atoms the parser identified as comment-origin and ingestion deliberately
    # refused. Distinct from `unresolved`: those could not be mapped, these
    # were understood and excluded on purpose.
    comment_excluded: int = 0
    comment_excluded_samples: list[tuple[str, str]] = field(default_factory=list)
