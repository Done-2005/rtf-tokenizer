from __future__ import annotations

import sqlite3


class SchemaMigrationRefused(RuntimeError):
    """Raised when a registry needs a schema migration the caller forbade.

    Distinct from a migration failure: nothing was attempted, nothing was
    damaged, and the fix is to state the registry's status correctly rather
    than to retry.
    """


# The occurrence table is declared separately because schema migration has to
# rebuild it. SQLite cannot ALTER a CHECK constraint, so adding the
# COMMENT_EXCLUDED status and the provenance column means create-copy-drop-rename.
# The table name is a template parameter so that migration can build the
# replacement table under a temporary name without textually renaming columns.
#
# `provenance` is a LEXICAL fact about the source text (CODE / COMMENT), decided
# by the parser. `status` is a SEMANTIC admission decision made by ingestion.
# They are deliberately separate axes: a COMMENT atom is known and deliberately
# refused (COMMENT_EXCLUDED), which is not the same claim as UNRESOLVED
# ("could not establish a mapping"). Conflating them would hide the difference
# between a filter that worked and a filter that failed.
OCCURRENCE_DDL_TEMPLATE = """
CREATE TABLE IF NOT EXISTS {table} (
    occurrence_id INTEGER PRIMARY KEY AUTOINCREMENT,
    document_id INTEGER NOT NULL REFERENCES document(document_id),
    position INTEGER NOT NULL,
    tag_id INTEGER NOT NULL REFERENCES tag_registry(tag_id),
    row_id INTEGER REFERENCES row_registry(row_id),
    value_id INTEGER REFERENCES value_registry(value_id),
    concept TEXT,
    raw_value TEXT,
    status TEXT NOT NULL CHECK (status IN
        ('MAPPED', 'UNRESOLVED', 'DELIMITER', 'REJECTED', 'COMMENT_EXCLUDED')),
    mapping_method TEXT CHECK (mapping_method IN
        ('EXACT_CANONICAL','EXPLICIT_ALIAS','DOMAIN_RULE','PARSER_RULE',
         'MANUAL_MAPPING','UNRESOLVED','CONFLICT')),
    cell_id INTEGER REFERENCES cell_registry(cell_id),
    line INTEGER,
    col INTEGER,
    provenance TEXT NOT NULL DEFAULT 'CODE' CHECK (provenance IN
        ('CODE', 'COMMENT', 'STRING')),
    UNIQUE (document_id, position)
);
"""

OCCURRENCE_DDL = OCCURRENCE_DDL_TEMPLATE.format(table="occurrence")
_MIGRATION_TEMP_TABLE = "occurrence_pre_provenance"

SCHEMA_DDL = """
CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tag_registry (
    tag_id INTEGER PRIMARY KEY,
    tag_code TEXT NOT NULL UNIQUE,
    domain TEXT NOT NULL,
    local_name TEXT NOT NULL,
    qualified_name TEXT NOT NULL COLLATE NOCASE UNIQUE,
    description TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (domain, local_name)
);

CREATE TABLE IF NOT EXISTS row_registry (
    row_id INTEGER PRIMARY KEY,
    row_code TEXT NOT NULL UNIQUE,
    canonical_name TEXT NOT NULL COLLATE NOCASE UNIQUE,
    definition TEXT NOT NULL,
    origin TEXT NOT NULL DEFAULT 'SEED',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS value_registry (
    value_id INTEGER PRIMARY KEY,
    value_code TEXT NOT NULL UNIQUE,
    value_string TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- CELL = TAG x ROW x DISCRIMINATOR -> VALUE. One semantic row may hold many
-- atomic values.
--
-- `discriminator` is a reading-verified BINDING ROLE (Step 7B): the role a
-- token plays in the source, not the meaning of its characters. It refines cell
-- identity because (TAG, ROW, VALUE) is not unique in practice -- twenty-two
-- distinct local bindings resolve to one (TAG, ROW, VALUE) triple -- so the
-- triple cannot address a cell. It refines identity WITHOUT inventing
-- uniqueness: per-occurrence 1/n multiplicity is retained.
--
-- The column is NULLABLE on purpose, and the NULL is a claim, not a gap. A role
-- is populated only where the manual reading verified one. NULL means "no
-- verified binding role", which covers every non-VARIABLE_BINDING row and the
-- five VARIABLE_BINDING values that are function references rather than
-- bindings (apply, dim, is.null, mode, recursive). A role is never guessed, so
-- the vocabulary is closed: any non-NULL value must be one of the four.
CREATE TABLE IF NOT EXISTS cell_registry (
    cell_id INTEGER PRIMARY KEY,
    cell_code TEXT,
    tag_id INTEGER NOT NULL REFERENCES tag_registry(tag_id),
    row_id INTEGER NOT NULL REFERENCES row_registry(row_id),
    discriminator TEXT CHECK (discriminator IN (
        'LOCAL_BINDING', 'FORMAL_PARAM', 'ITERATION_BINDING', 'LAMBDA_PARAM')),
    value_id INTEGER NOT NULL REFERENCES value_registry(value_id),
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (tag_id, row_id, discriminator, value_id)
);

-- Documents and ordered occurrences. Registries are sets; occurrences keep
-- order and repetition (spec section 16).
CREATE TABLE IF NOT EXISTS document (
    document_id INTEGER PRIMARY KEY,
    source_name TEXT NOT NULL,
    language TEXT NOT NULL,
    content_sha256 TEXT NOT NULL,
    char_length INTEGER NOT NULL,
    parser_version TEXT NOT NULL,
    config_version TEXT NOT NULL,
    ingested_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Documents and ordered occurrences. Registries are sets; occurrences keep
-- order and repetition. The occurrence table itself is declared in
-- OCCURRENCE_DDL, and is created/migrated by connect() before the indexes in
-- SCHEMA_INDEX_DDL, because SQLite cannot ALTER its CHECK constraint.

-- Higher-level structural elements (spec sections 8-13, 23).
CREATE TABLE IF NOT EXISTS structural_element (
    element_id INTEGER PRIMARY KEY,
    element_code TEXT,
    document_id INTEGER NOT NULL REFERENCES document(document_id),
    kind TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'ROOT',
    parent_id INTEGER REFERENCES structural_element(element_id),
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS structural_member (
    member_id INTEGER PRIMARY KEY AUTOINCREMENT,
    element_id INTEGER NOT NULL REFERENCES structural_element(element_id),
    position INTEGER NOT NULL,
    role TEXT NOT NULL,
    child_element_id INTEGER REFERENCES structural_element(element_id),
    child_occurrence_id INTEGER REFERENCES occurrence(occurrence_id),
    CHECK (child_element_id IS NOT NULL OR child_occurrence_id IS NOT NULL),
    CHECK (child_element_id IS NULL OR child_occurrence_id IS NULL)
);

-- Semantic mapping ledger (spec section 14). Append-only audit of decisions.
CREATE TABLE IF NOT EXISTS semantic_mapping (
    mapping_id INTEGER PRIMARY KEY AUTOINCREMENT,
    variant TEXT NOT NULL COLLATE NOCASE,
    row_id INTEGER NOT NULL REFERENCES row_registry(row_id),
    method TEXT NOT NULL CHECK (method IN
        ('EXACT_CANONICAL','EXPLICIT_ALIAS','DOMAIN_RULE','PARSER_RULE','MANUAL_MAPPING')),
    detail TEXT NOT NULL DEFAULT '',
    decided_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (variant, row_id, method)
);

CREATE TABLE IF NOT EXISTS mapping_conflict (
    conflict_id INTEGER PRIMARY KEY AUTOINCREMENT,
    variant TEXT NOT NULL COLLATE NOCASE,
    attempted_row_id INTEGER NOT NULL REFERENCES row_registry(row_id),
    existing_row_id INTEGER NOT NULL REFERENCES row_registry(row_id),
    detected_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Matrix annotations distinguish EMPTY (concept not applicable in this domain)
-- from UNKNOWN (system does not currently know) (spec sections 18-19).
CREATE TABLE IF NOT EXISTS matrix_annotation (
    tag_id INTEGER NOT NULL REFERENCES tag_registry(tag_id),
    row_id INTEGER NOT NULL REFERENCES row_registry(row_id),
    status TEXT NOT NULL CHECK (status IN ('EMPTY', 'UNKNOWN')),
    note TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (tag_id, row_id)
);
"""

CELL_DISCRIMINATORS = (
    'LOCAL_BINDING',
    'FORMAL_PARAM',
    'ITERATION_BINDING',
    'LAMBDA_PARAM',
)

SCHEMA_INDEX_DDL = """
CREATE INDEX IF NOT EXISTS idx_cell_tag ON cell_registry(tag_id);
CREATE INDEX IF NOT EXISTS idx_cell_row ON cell_registry(row_id);
CREATE INDEX IF NOT EXISTS idx_cell_value ON cell_registry(value_id);
CREATE INDEX IF NOT EXISTS idx_cell_tag_row_disc ON cell_registry(tag_id, row_id, discriminator);
-- SQLite treats NULLs as DISTINCT inside a UNIQUE constraint, so the table-level
-- UNIQUE above does NOT deduplicate the NULL-discriminator cells on its own.
-- Without this index a value could be inserted twice into the same (tag, row)
-- with no discriminator, silently undoing registry deduplication. '' is a safe
-- stand-in: the CHECK constraint means '' can never be a real role.
CREATE UNIQUE INDEX IF NOT EXISTS idx_cell_identity ON cell_registry(
    tag_id, row_id, COALESCE(discriminator, ''), value_id);
CREATE INDEX IF NOT EXISTS idx_elem_doc ON structural_element(document_id);
CREATE INDEX IF NOT EXISTS idx_member_elem ON structural_element(element_id);
"""

_OCCURRENCE_INDEX_DDL = """
CREATE INDEX IF NOT EXISTS idx_occ_doc_pos ON occurrence(document_id, position);
CREATE INDEX IF NOT EXISTS idx_occ_value ON occurrence(value_id);
CREATE INDEX IF NOT EXISTS idx_occ_cell ON occurrence(cell_id);
"""


def _occurrence_needs_migration(conn: sqlite3.Connection) -> bool:
    """True when the on-disk occurrence table cannot record what the model can.

    Two distinct gaps, both of which make a legitimate insert fail rather than
    silently lose data:

    1. Pre-provenance tables have no `provenance` column and no
       `COMMENT_EXCLUDED` status at all.
    2. A table written by the Layer-1 code has both, but its CHECK constraint
       still admits only ('CODE', 'COMMENT'). Such a table looks current by
       column inspection while rejecting `STRING` on insert, so the constraint
       text is checked too.
    """
    row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='occurrence'"
    ).fetchone()
    if row is None or not row[0]:
        return False
    ddl = row[0]
    columns = {r[1] for r in conn.execute("PRAGMA table_info(occurrence)")}
    if "provenance" not in columns or "COMMENT_EXCLUDED" not in ddl:
        return True
    # The column exists, but a Layer-1-era CHECK still admits only
    # ('CODE', 'COMMENT') and would reject STRING on insert. Read from the
    # live table DDL rather than the template, so a hand-edited registry is
    # reported honestly instead of assumed current.
    return "'STRING'" not in ddl.upper()


def _migrate_occurrence(conn: sqlite3.Connection) -> None:
    """Rebuild `occurrence` to add provenance + COMMENT_EXCLUDED, in place.

    Create-copy-drop-rename, the order the SQLite docs recommend, because a
    plain DROP of a table referenced by structural_member would either fail or
    (with foreign keys deferred) leave a dangling reference. occurrence_id is
    carried across verbatim, so every existing structural_member link still
    resolves to the same occurrence it did before.

    This changes only the admission vocabulary. cell_registry, and therefore
    the (TAG, ROW, VALUE) identity, is not touched.
    """
    existing = [r[1] for r in conn.execute("PRAGMA table_info(occurrence)")]
    target = list(existing)
    if "provenance" not in target:
        # Pre-Layer-1 rows carry no provenance, and every one of them was read
        # as code. Defaulting to CODE is the honest backfill, not a guess: the
        # old schema had no way to record a comment atom at all.
        target.append("provenance")
    collist = ", ".join(target)
    selectlist = ", ".join(
        col if col in existing else "'CODE'" for col in target)
    # No ALTER ... RENAME on the *old* table: SQLite would rewrite the foreign
    # key text in structural_member to point at the renamed table.
    temp = _MIGRATION_TEMP_TABLE
    conn.execute(f"DROP TABLE IF EXISTS {temp}")
    conn.execute(OCCURRENCE_DDL_TEMPLATE.format(table=temp))
    conn.execute(f"INSERT INTO {temp} ({collist}) "
                 f"SELECT {selectlist} FROM occurrence")
    conn.execute("DROP TABLE occurrence")
    conn.execute(f"ALTER TABLE {temp} RENAME TO occurrence")
    broken = conn.execute("PRAGMA foreign_key_check").fetchall()
    if broken:
        raise sqlite3.IntegrityError(
            f"occurrence migration left {len(broken)} broken reference(s): "
            f"{broken[:5]}")


def _cell_needs_discriminator(conn: sqlite3.Connection) -> bool:
    """True when the on-disk cell_registry predates the binding-role column."""
    row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='cell_registry'"
    ).fetchone()
    if row is None or not row[0]:
        return False
    columns = {r[1] for r in conn.execute("PRAGMA table_info(cell_registry)")}
    return "discriminator" not in columns


def _add_discriminator_column(conn: sqlite3.Connection) -> None:
    """Add `discriminator` to an existing cell_registry without inventing roles.

    ALTER TABLE ADD COLUMN is enough here precisely because the column is
    nullable: every pre-5.3 row lands on NULL, which is the honest reading "no
    verified binding role". No row is dropped, no row_id moves, and no role is
    backfilled -- the role table is a reading-verified fact about the source and
    cannot be recovered from the database. Re-ingesting the source into a scratch
    registry is what populates real roles.
    """
    conn.execute(
        "ALTER TABLE cell_registry ADD COLUMN discriminator TEXT "
        "CHECK (discriminator IN "
        "('LOCAL_BINDING', 'FORMAL_PARAM', 'ITERATION_BINDING', 'LAMBDA_PARAM'))"
    )


def connect(db_path: str, allow_migration: bool = True) -> sqlite3.Connection:
    """Open a registry, creating or migrating its schema as needed.

    `allow_migration` must be False for a durable registry. A migration rewrites
    the `occurrence` table or alters `cell_registry`, which are the only
    operations in this package that can change the physical layout of
    accumulated state. The caller states whether the file is disposable; this
    function does not guess, and it raises rather than migrating a registry the
    caller has declared off-limits.
    """
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(SCHEMA_DDL)
    # cell_registry gains its column before anything indexes it.
    if _cell_needs_discriminator(conn):
        if not allow_migration:
            conn.close()
            raise SchemaMigrationRefused(
                f"{db_path} has a pre-5.3 cell_registry (no binding-role "
                f"discriminator), but migration was refused for this registry. "
                f"Re-ingest the source into a fresh scratch registry, and leave "
                f"the original alone."
            )
        _add_discriminator_column(conn)
    # occurrence is created or rebuilt before anything indexes or references it.
    if _occurrence_needs_migration(conn):
        if not allow_migration:
            raise SchemaMigrationRefused(
                f"{db_path} needs an occurrence migration (it cannot record the "
                f"current provenance vocabulary), but migration was refused for "
                f"this registry. Migrate a copy if you need to verify the "
                f"upgrade, and leave the original alone."
            )
        # Required for the DROP of a table another table references.
        conn.execute("PRAGMA foreign_keys = OFF")
        try:
            _migrate_occurrence(conn)
        finally:
            conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(OCCURRENCE_DDL)
    conn.executescript(SCHEMA_INDEX_DDL)
    conn.executescript(_OCCURRENCE_INDEX_DDL)
    conn.execute(
        "INSERT INTO meta(key, value) VALUES ('schema_version', ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        ("5.3.0",),
    )
    conn.commit()
    return conn
