"""Full-database serialization (spec section 29/34: persistence + reproducibility)."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path

_TABLES = [
    "meta", "tag_registry", "row_registry", "value_registry", "cell_registry",
    "document", "occurrence", "structural_element", "structural_member",
    "semantic_mapping", "mapping_conflict", "matrix_annotation",
]


def dump_database(conn: sqlite3.Connection) -> dict:
    data: dict = {}
    for table in _TABLES:
        columns = [r[1] for r in conn.execute(f"PRAGMA table_info({table})")]
        rows = conn.execute(f"SELECT * FROM {table}").fetchall()
        data[table] = [dict(zip(columns, row)) for row in rows]
    return data


def export_json(conn: sqlite3.Connection, path) -> str:
    payload = json.dumps(dump_database(conn), indent=2, default=str)
    path = Path(path)
    path.write_text(payload, encoding="utf-8")
    return str(path)


def export_xlsx(matrix, path) -> str:
    from openpyxl import Workbook

    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "RTF-Matrix"
    headers = ["CONCEPT"] + [t["qualified_name"] for t in matrix.tag_columns]
    sheet.append(headers)
    for row in matrix.concept_rows:
        line = [f"{row['row_code']} {row['canonical_name']}"]
        for tag in matrix.tag_columns:
            line.append(matrix.cell_display(row["row_id"], tag["tag_id"]))
        sheet.append(line)
    path = Path(path)
    workbook.save(path)
    return str(path)
