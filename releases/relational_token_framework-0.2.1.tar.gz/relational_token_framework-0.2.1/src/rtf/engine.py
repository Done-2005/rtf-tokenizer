"""RTF-V5 Representation Engine.

Orchestrates the full data-entry pipeline (spec section 26):

    RAW INPUT -> domain -> TAG -> parse -> atomic values -> ROW resolution
    -> VALUE registration -> CELL creation -> ordered occurrences
    -> higher-level structural elements -> matrix view -> RTF tokens

Every inserted fact carries provenance (document, position, line, col,
parser version, mapping method). Registries stay deduplicated; occurrences
preserve order and repetition.
"""
from __future__ import annotations

import sqlite3

from .ast import ElementBuilder
from .cells import CellBuilder, CellOutcome
from .core.errors import NonAtomicValueError
from .core.model import (
    CODE_ORIGIN,
    COMMENT_ORIGIN,
    PARSER_VERSION,
    IngestionReport,
    ParseResult,
    Rejection,
    RTFConfig,
    SCHEMA_VERSION,
)
from .core.schema import connect
from .matrix import MatrixEngine
from .parsing import DEFAULT_LOCAL_NAMES, DOMAIN_QUALIFIERS, detect_domain, get_parser
from .registries import RowRegistry, TagRegistry, ValueRegistry
from .semantics import SemanticMapper
from .semantics import concepts as C
from .sequences import SequenceStore
from .structures import StructureStore
from .validation import Validator

# Only this row's cells carry a binding role. Every other row stores NULL.
_VARIABLE_BINDING = "VARIABLE_BINDING"


class RepresentationEngine:
    def __init__(self, db_path: str, config: RTFConfig | None = None) -> None:
        self.config = config or RTFConfig()
        self._resolvers: dict[str, object] = {}
        self._row_names: dict[int, str | None] = {}
        self.conn: sqlite3.Connection = connect(db_path)
        self.tags = TagRegistry(self.conn)
        self.rows = RowRegistry(self.conn)
        self.values = ValueRegistry(self.conn)
        self.cells = CellBuilder(self.conn, self.values)
        self.sequences = SequenceStore(self.conn)
        self.structures_store = StructureStore(self.conn)
        self.elements = ElementBuilder(self.conn, self.structures_store)
        self.mapper = SemanticMapper(self.conn, self.rows, self.config)
        self.matrix_engine = MatrixEngine(self.conn, self.config)
        self.validator = Validator(self.conn)

    def _row_concept(self, row_id: int) -> str | None:
        """Canonical name of a row, memoised.

        The discriminator is scoped by row, and the row is addressed by id while
        the vocabulary names it by concept, so the two have to be translated.
        """
        if row_id not in self._row_names:
            found = self.conn.execute(
                "SELECT canonical_name FROM row_registry WHERE row_id = ?", (row_id,)
            ).fetchone()
            self._row_names[row_id] = found[0] if found else None
        return self._row_names[row_id]

    def _role_resolver(self, source_name: str | None):
        """Reading-verified binding roles for this source, or None if unverified.

        The table is a manual reading record, not an inference, so a source with
        no table simply yields None and every discriminator stays NULL. That is
        the honest outcome, and it is why a missing table degrades to the
        pre-5.3 identity instead of raising or guessing.
        """
        from .roles import RoleResolver

        key = source_name or ""
        if key not in self._resolvers:
            self._resolvers[key] = RoleResolver.for_source(key)
        return self._resolvers[key]

    # ------------------------------------------------------------------
    # ingestion
    # ------------------------------------------------------------------

    def _record(self, doc_id, position, tag_id, row_id, value_id, extraction,
                status, method, cell_id, provenance):
        """Persist one atom, carrying the parser's lexical provenance through.

        Centralised because provenance is a property of the ATOM, not of the
        branch that happened to handle it: a call site that forgets to forward
        `extraction.provenance` silently relabels a comment atom as CODE, which
        is exactly the failure Layer 1 exists to prevent.
        """
        return self.sequences.record_occurrence(
            doc_id, position, tag_id, row_id, value_id, extraction.concept,
            extraction.value, status, method, cell_id,
            extraction.line, extraction.col, provenance)

    def ingest(self, source: str, language: str | None = None,
               source_name: str | None = None) -> IngestionReport:
        language = language or detect_domain(source)
        parser = get_parser(language)
        domain = DOMAIN_QUALIFIERS[language]
        local_name = DEFAULT_LOCAL_NAMES[language]
        tag_id, _created_tag = self.tags.get_or_register(
            domain, local_name, description=f"{language} source domain")

        report = IngestionReport(language=language)
        doc_id, is_new = self.sequences.register_document(
            source_name or f"{local_name.lower()}:{source[:32]!r}",
            language, source, PARSER_VERSION, SCHEMA_VERSION)
        report.document_id = doc_id
        if not is_new:
            report.duplicate_document = True
            return report

        parsed: ParseResult = parser.parse(source)
        parsed = self._apply_delimiter_policy(parsed)

        index_to_occurrence: dict[int, int] = {}
        for position, extraction in enumerate(parsed.extractions):
            row_id: int | None = None
            method: str | None = None
            cell_id: int | None = None
            status = "UNRESOLVED"
            value_id: int | None = None

            # Layer 1 admission control. The parser has already established
            # LEXICALLY that this atom came from a comment. Refusing it is a
            # semantic decision, and it belongs here, not in the tokenizer.
            #
            # Deliberately NOT "UNRESOLVED": that claims we could not establish
            # a mapping. We established exactly what it is and excluded it on
            # purpose. Recording it as UNRESOLVED would make a working filter
            # indistinguishable from a broken one, and would pollute the
            # unresolved list with text nobody asked us to map.
            #
            # Also deliberately no value registration: value_registry is the
            # semantic corpus, and comment text is not program knowledge. The
            # raw text is still preserved in raw_value, so the refusal stays
            # fully auditable and reversible.
            if extraction.provenance == COMMENT_ORIGIN:
                occ_id = self._record(
                    doc_id, position, tag_id, None, None, extraction,
                    "COMMENT_EXCLUDED", None, None, COMMENT_ORIGIN)
                index_to_occurrence[position] = occ_id
                report.comment_excluded += 1
                if len(report.comment_excluded_samples) < 20:
                    report.comment_excluded_samples.append(
                        (extraction.concept, extraction.value))
                continue

            try:
                value_id, value_created = self.values.get_or_register(extraction.value)
                if value_created:
                    report.values_created += 1
            except Exception as exc:  # noqa: BLE001 - record honestly, never fabricate
                occ_id = self._record(
                    doc_id, position, tag_id, None, None, extraction,
                    "REJECTED", None, None, extraction.provenance)
                index_to_occurrence[position] = occ_id
                report.rejections.append(
                    Rejection(extraction.value, str(exc), extraction.line, extraction.col))
                continue

            resolver = self._role_resolver(source_name)

            if extraction.concept == "DELIMITER":
                resolution = self.mapper.resolve("DELIMITER", language)
                if resolution.row_id is not None:
                    row_id = resolution.row_id
                    method = resolution.method
                    # A delimiter is not a binding, so it never carries a
                    # discriminator: NULL, not a guessed role.
                    try:
                        outcome = self.cells.build(
                            tag_id, row_id, None, extraction.value)
                        cell_id = outcome.cell_id
                        status = "DELIMITER"
                    except NonAtomicValueError as exc:
                        occ_id = self._record(
                            doc_id, position, tag_id, row_id, value_id,
                            extraction, "REJECTED", None, None, extraction.provenance)
                        index_to_occurrence[position] = occ_id
                        report.rejections.append(
                            Rejection(extraction.value, str(exc),
                                      extraction.line, extraction.col))
                        continue
                    if outcome.status == "created":
                        report.cells_created += 1
                    else:
                        report.cells_duplicate += 1
            else:
                resolution = self.mapper.resolve(extraction.concept, language)
                if resolution.row_id is not None:
                    row_id = resolution.row_id
                    method = resolution.method
                    # The binding role is only meaningful for VARIABLE_BINDING
                    # cells, and only where the manual reading verified one.
                    # Everything else -- other rows, and the five VB values that
                    # are function references -- stays NULL rather than guessed.
                    discriminator = None
                    if self._row_concept(row_id) == _VARIABLE_BINDING:
                        discriminator = resolver.resolve(
                            source_name or "", extraction.value, extraction.line)
                    try:
                        outcome = self.cells.build(
                            tag_id, row_id, discriminator, extraction.value)
                        cell_id = outcome.cell_id
                        status = "MAPPED"
                    except NonAtomicValueError as exc:
                        occ_id = self._record(
                            doc_id, position, tag_id, row_id, value_id,
                            extraction, "REJECTED", None, None, extraction.provenance)
                        index_to_occurrence[position] = occ_id
                        report.rejections.append(
                            Rejection(extraction.value, str(exc),
                                      extraction.line, extraction.col))
                        continue
                    if outcome.status == "created":
                        report.cells_created += 1
                    else:
                        report.cells_duplicate += 1
                else:
                    report.unresolved.append((extraction.concept, extraction.value))

            # Record occurrence for all non-comment cases
            occ_id = self._record(
                doc_id, position, tag_id, row_id, value_id, extraction,
                status, method, cell_id, extraction.provenance)
            index_to_occurrence[position] = occ_id

        report.occurrences_recorded = len(parsed.extractions)
        report.rejections.extend(parsed.rejected)

        report.structures_created = self.elements.build_from_parse(
            doc_id, parsed, index_to_occurrence)

        self.conn.commit()
        report.tag_code = self.tags.get_by_qualified_name(f"{domain}::{local_name}")["tag_code"]
        return report

    # ------------------------------------------------------------------
    # config-driven representation policy
    # ------------------------------------------------------------------

    def _apply_delimiter_policy(self, parsed: ParseResult) -> ParseResult:
        """Honor include_delimiters=False by removing DELIMITER atoms.

        Structure leaf indices are remapped onto the filtered stream so the
        higher-level elements keep referencing exactly the surviving atoms.
        Positions stay contiguous because occurrence positions are assigned
        after filtering (validation F006).
        """
        if self.config.include_delimiters:
            return parsed
        kept_indices = [i for i, e in enumerate(parsed.extractions)
                        if e.concept != C.DELIMITER]
        remap = {old: new for new, old in enumerate(kept_indices)}

        def prune(node) -> None:
            node.leaf_indices = [remap[i] for i in node.leaf_indices if i in remap]
            for child in node.children:
                prune(child)

        for root in parsed.structures:
            prune(root)
        parsed.extractions = [parsed.extractions[i] for i in kept_indices]
        return parsed

    # ------------------------------------------------------------------
    # views and exports
    # ------------------------------------------------------------------

    def build_matrix(self):
        return self.matrix_engine.build()

    def export_json(self, path) -> str:
        from .serialization import export_json

        return export_json(self.conn, path)

    def export_matrix_xlsx(self, path) -> str:
        from .serialization import export_xlsx

        return export_xlsx(self.build_matrix(), path)

    def validate(self):
        findings = self.validator.run()
        for finding in findings:
            print(finding)
        return findings

    def close(self) -> None:
        self.conn.commit()
        self.conn.close()


__all__ = ["RepresentationEngine"]