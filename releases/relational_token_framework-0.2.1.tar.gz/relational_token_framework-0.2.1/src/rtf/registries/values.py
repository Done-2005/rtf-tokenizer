from __future__ import annotations

from ..core.codes import format_value_code


class ValueRegistry:
    """Atomic value registry. Globally deduplicated by exact string identity."""

    def __init__(self, conn) -> None:
        self._conn = conn

    def get_or_register(self, literal: str) -> tuple[int, bool]:
        row = self._conn.execute(
            "SELECT value_id FROM value_registry WHERE value_string = ?", (literal,)
        ).fetchone()
        if row is not None:
            return int(row[0]), False
        value_id = int(
            self._conn.execute("SELECT COALESCE(MAX(value_id), 0) + 1 FROM value_registry").fetchone()[0]
        )
        self._conn.execute(
            "INSERT INTO value_registry(value_id, value_code, value_string) VALUES (?, ?, ?)",
            (value_id, format_value_code(value_id), literal),
        )
        return value_id, True

    def get_string(self, value_id: int) -> str | None:
        row = self._conn.execute(
            "SELECT value_string FROM value_registry WHERE value_id = ?", (value_id,)
        ).fetchone()
        return row[0] if row is not None else None

    def find_by_string(self, literal: str) -> int | None:
        row = self._conn.execute(
            "SELECT value_id FROM value_registry WHERE value_string = ?", (literal,)
        ).fetchone()
        return int(row[0]) if row is not None else None

    def count(self) -> int:
        return int(self._conn.execute("SELECT COUNT(*) FROM value_registry").fetchone()[0])
