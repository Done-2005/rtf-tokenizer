from __future__ import annotations

from ..core.codes import format_tag_code


class TagRegistry:
    """Domain registry. Identity = (domain, local_name); display = DOMAIN::NAME.

    Permanent, globally sequential ids; repeated registration reuses the
    existing permanent id (spec sections 3 and 21).
    """

    def __init__(self, conn) -> None:
        self._conn = conn

    def get_or_register(self, domain: str, local_name: str, description: str = "") -> tuple[int, bool]:
        qualified = f"{domain}::{local_name}"
        row = self._conn.execute(
            "SELECT tag_id FROM tag_registry WHERE qualified_name = ?", (qualified,)
        ).fetchone()
        if row is not None:
            return int(row[0]), False
        tag_id = int(
            self._conn.execute("SELECT COALESCE(MAX(tag_id), 0) + 1 FROM tag_registry").fetchone()[0]
        )
        self._conn.execute(
            "INSERT INTO tag_registry(tag_id, tag_code, domain, local_name, qualified_name, description) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (tag_id, format_tag_code(tag_id), domain, local_name, qualified, description),
        )
        return tag_id, True

    def get_by_qualified_name(self, qualified_name: str):
        row = self._conn.execute(
            "SELECT tag_id, tag_code, domain, local_name, qualified_name, description "
            "FROM tag_registry WHERE qualified_name = ?",
            (qualified_name,),
        ).fetchone()
        if row is None:
            return None
        return {
            "tag_id": int(row[0]),
            "tag_code": row[1],
            "domain": row[2],
            "local_name": row[3],
            "qualified_name": row[4],
            "description": row[5],
        }

    def all_tags(self) -> list[dict]:
        rows = self._conn.execute(
            "SELECT tag_id, tag_code, domain, local_name, qualified_name FROM tag_registry ORDER BY tag_id"
        ).fetchall()
        return [
            {
                "tag_id": int(r[0]),
                "tag_code": r[1],
                "domain": r[2],
                "local_name": r[3],
                "qualified_name": r[4],
            }
            for r in rows
        ]
