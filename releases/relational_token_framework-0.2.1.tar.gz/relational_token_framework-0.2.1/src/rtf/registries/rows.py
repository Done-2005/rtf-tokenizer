from __future__ import annotations

from ..core.codes import format_row_code
from ..semantics.concepts import SEED_CONCEPTS


class RowRegistry:
    """Universal concept registry.

    ROW ids are permanent, sequential and GLOBAL: they never reset for a new
    domain (spec sections 4 and 21). Rows are created only from the seed list,
    an explicit auto-creation configuration, or a manual decision - never as a
    side effect of encountering an unknown surface token.
    """

    def __init__(self, conn) -> None:
        self._conn = conn
        self._ensure_seeds()

    def _ensure_seeds(self) -> None:
        for index, (name, definition) in enumerate(SEED_CONCEPTS, start=1):
            self._conn.execute(
                "INSERT OR IGNORE INTO row_registry(row_id, row_code, canonical_name, definition, origin) "
                "VALUES (?, ?, ?, ?, 'SEED')",
                (index, format_row_code(index), name, definition),
            )
        self._conn.commit()

    def find_exact(self, canonical_name: str) -> int | None:
        row = self._conn.execute(
            "SELECT row_id FROM row_registry WHERE canonical_name = ?", (canonical_name,)
        ).fetchone()
        return int(row[0]) if row is not None else None

    def create(self, canonical_name: str, definition: str, origin: str = "AUTO") -> int:
        existing = self.find_exact(canonical_name)
        if existing is not None:
            return existing
        row_id = int(
            self._conn.execute("SELECT COALESCE(MAX(row_id), 0) + 1 FROM row_registry").fetchone()[0]
        )
        self._conn.execute(
            "INSERT INTO row_registry(row_id, row_code, canonical_name, definition, origin) "
            "VALUES (?, ?, ?, ?, ?)",
            (row_id, format_row_code(row_id), canonical_name, definition, origin),
        )
        return row_id

    def get(self, row_id: int):
        row = self._conn.execute(
            "SELECT row_id, row_code, canonical_name, definition, origin FROM row_registry WHERE row_id = ?",
            (row_id,),
        ).fetchone()
        if row is None:
            return None
        return {
            "row_id": int(row[0]),
            "row_code": row[1],
            "canonical_name": row[2],
            "definition": row[3],
            "origin": row[4],
        }

    def all_rows(self) -> list[dict]:
        rows = self._conn.execute(
            "SELECT row_id, row_code, canonical_name, origin FROM row_registry ORDER BY row_id"
        ).fetchall()
        return [
            {"row_id": int(r[0]), "row_code": r[1], "canonical_name": r[2], "origin": r[3]}
            for r in rows
        ]

    def count(self) -> int:
        return int(self._conn.execute("SELECT COUNT(*) FROM row_registry").fetchone()[0])

    def get_or_register(self, canonical_name: str) -> int:
        """Find existing row or create a new one with AUTO origin."""
        existing = self.find_exact(canonical_name)
        if existing is not None:
            return existing
        return self.create(canonical_name, "", "AUTO")
