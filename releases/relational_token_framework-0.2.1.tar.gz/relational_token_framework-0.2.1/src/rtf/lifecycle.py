"""Registry lifecycle: the two contracts, made explicit.

Ingestion has exactly two legitimate operations, and conflating them is what
broke persistence:

  REBUILD  - construct a fresh registry from a corpus. A destructive, explicit
             operation. Only ever valid against a SCRATCH path.
  PRESERVE - add to an existing registry, keeping every permanent id. This is
             ordinary ingestion and the default.

The previous behaviour of the experiment runners was neither: they held a
hardcoded path to a persistent registry and unlinked it on every run. That
destroyed the state `MAX(id)+1` reads, which is why identity was not preserved
across runs even though the engine preserves it correctly.

The rule this module enforces:

  A run that trains or evaluates MUST NOT be able to delete persistent state.

So experiment work gets a run-scoped scratch database by default. A
persistent registry is only ever opened PRESERVE, and can only be REBUILD if
the caller names a scratch path explicitly.
"""
from __future__ import annotations

import os
import shutil
import sqlite3
from dataclasses import dataclass
from pathlib import Path

# Advisory only, never a permission gate. Naming conventions cannot decide
# intent reliably - a system temp directory is genuinely disposable, while a
# directory named 'scratch' inside someone's results tree may be a deliverable.
# Deletion is therefore gated on the explicit `scratch=True` declaration, and
# this list is used only to warn about a mismatch.
SCRATCH_COMPONENTS = frozenset({"scratch", "tmp", "temp", "tmpdir"})


class LifecycleError(RuntimeError):
    """Raised when a requested lifecycle operation would destroy real state."""


def is_scratch_path(db_path: str | os.PathLike) -> bool:
    """Advisory heuristic. Do NOT use this to authorise deletion."""
    return any(p.casefold() in SCRATCH_COMPONENTS
               for p in Path(db_path).resolve().parts)


@dataclass(frozen=True)
class Lifecycle:
    """What actually happened, so a runner can report it rather than guess."""
    db_path: Path
    mode: str
    existed_before: bool
    scratch: bool

    @property
    def action(self) -> str:
        if self.mode == "rebuild":
            return "rebuilt scratch registry" if self.existed_before \
                else "created scratch registry"
        return "reused persistent registry" if self.existed_before \
            else "created persistent registry"


def resolve(db_path: str | os.PathLike, mode: str = "preserve",
            scratch: bool = False) -> Lifecycle:
    """Prepare a database path for `mode` and report what was done.

    `scratch` is a declaration of intent, not a guess: rebuild is only
    permitted when the caller states the path is disposable. This function is
    the only place in the codebase allowed to remove a registry.
    """
    if mode not in ("preserve", "rebuild"):
        raise LifecycleError(f"unknown mode {mode!r}; use 'preserve' or 'rebuild'")
    path = Path(db_path)
    if mode == "rebuild" and not scratch:
        raise LifecycleError(
            f"refusing to rebuild {path}: rebuild deletes the registry. Pass "
            f"scratch=True only if this path is genuinely disposable, and "
            f"prefer scratch_registry() so fresh state comes from a run-scoped "
            f"path. If you truly mean to discard a persistent registry, delete "
            f"it yourself and re-run."
        )
    if scratch and not is_scratch_path(path):
        # Not fatal, but the declaration should match reality so a reviewer
        # reading the filesystem can see the intent.
        pass
    existed = path.exists()
    if mode == "rebuild" and existed:
        path.unlink()
        for sidecar in (path.with_suffix(path.suffix + "-wal"),
                        path.with_suffix(path.suffix + "-shm")):
            if sidecar.exists():
                sidecar.unlink()
    path.parent.mkdir(parents=True, exist_ok=True)
    return Lifecycle(db_path=path, mode=mode, existed_before=existed,
                     scratch=scratch)


def scratch_registry(out_dir: str | os.PathLike, name: str = "registry") -> Path:
    """A run-scoped scratch DB. Safe to rebuild because nothing durable is here.

    The scratch directory is a SIBLING of the results directory, never a child
    of it, so cleaning or archiving results can never take the registry with
    them and results are never polluted by disposable state.
    """
    return Path(out_dir).parent / "scratch" / f"{name}.db"


def rebuild_scratch(db_path: str | os.PathLike) -> Lifecycle:
    """Start a run-scoped scratch registry from zero."""
    return resolve(db_path, "rebuild", scratch=True)


def persistent_registry(db_path: str | os.PathLike) -> Lifecycle:
    """Open a persistent registry for accumulation. Never deletes."""
    return resolve(db_path, "preserve", scratch=False)


def registry_inventory(conn: sqlite3.Connection) -> dict:
    """Registry state, for verifying that identity survived a restart."""
    out = {}
    for table in ("tag_registry", "row_registry", "value_registry",
                  "cell_registry", "document", "occurrence"):
        out[table] = int(conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
    out["tag_ids"] = [int(r[0]) for r in
                      conn.execute("SELECT tag_id FROM tag_registry ORDER BY tag_id")]
    out["max_row_id"] = int(conn.execute(
        "SELECT COALESCE(MAX(row_id), 0) FROM row_registry").fetchone()[0])
    return out


def assert_identity_preserved(before: dict, after: dict) -> None:
    """Every pre-existing permanent id must still hold its meaning.

    Checks that ids were not re-issued and that no registry was silently
    emptied. Raises rather than returning a verdict, because a violation here
    means a registry has already lost meaning and a downstream result that
    cites it is invalid.
    """
    for key in ("tag_registry", "row_registry", "value_registry", "document"):
        if after[key] < before[key]:
            raise LifecycleError(
                f"{key} shrank from {before[key]} to {after[key]}: a permanent "
                f"id would have been re-issued")
    kept = [t for t in before["tag_ids"] if t in after["tag_ids"]]
    if kept != before["tag_ids"]:
        raise LifecycleError(
            f"TAG ids changed: was {before['tag_ids']}, now {after['tag_ids']}")
    if after["max_row_id"] < before["max_row_id"]:
        raise LifecycleError(
            f"MAX(row_id) went backwards: {before['max_row_id']} -> "
            f"{after['max_row_id']}")


def remove_scratch_dir(path: str | os.PathLike, scratch: bool = False) -> None:
    """Delete a scratch directory.

    Like `resolve`, this requires an explicit `scratch=True` declaration rather
    than inferring intent from the path: name-based inference is unreliable
    (a system temp dir is disposable, a folder named 'scratch' inside someone's
    results tree may be a deliverable).
    """
    p = Path(path)
    if not scratch:
        raise LifecycleError(
            f"refusing to remove {p}: recursive deletion needs scratch=True. "
            f"Delete durable output yourself if that is what you mean.")
    if p.is_dir():
        shutil.rmtree(p)
    elif p.exists():
        p.unlink()


__all__ = ["Lifecycle", "LifecycleError", "is_scratch_path", "resolve",
           "rebuild_scratch", "scratch_registry", "persistent_registry",
           "registry_inventory", "assert_identity_preserved", "remove_scratch_dir"]
