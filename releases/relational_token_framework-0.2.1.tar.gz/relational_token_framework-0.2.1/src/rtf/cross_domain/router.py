"""Confidence / action routing (ported from
CURRENT/COPY-3/cross_domain/router.py).

Explicit, inspectable decode-phase routing. The typed stream always carries
confidence and action so routing stays visible and auditable, never implicit:

    RELATION FOUND -> HIGH / MEDIUM / LOW -> EXECUTE / CLARIFY / REJECT
"""

from __future__ import annotations

CONFIDENCES = ("HIGH", "MEDIUM", "LOW")
ACTIONS = ("EXECUTE", "CLARIFY", "REJECT")


def route(confidence: str = "HIGH", action: str = "EXECUTE"):
    if confidence not in CONFIDENCES:
        raise ValueError(f"confidence must be one of {CONFIDENCES}")
    if action not in ACTIONS:
        raise ValueError(f"action must be one of {ACTIONS}")
    return ["CONF", confidence, "ACTION", action]


def relation_route(subj: str, rel: str, obj: str,
                   confidence: str = "HIGH", action: str = "EXECUTE"):
    return [subj, rel, obj] + route(confidence, action)


__all__ = ["CONFIDENCES", "ACTIONS", "route", "relation_route"]