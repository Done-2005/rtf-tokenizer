"""RTF validation layer: deterministic gold-free post-prediction checks.

Implements the "NN + RTF validation" layer proposed for the 10M study.
It holds NO test answers; every gate is built from (a) the training
streams (legitimate prior knowledge) and (b) the current window (the
surrounding structured stream), and recovers candidates only when the
current window uniquely identifies them.

Gates (applied in order, first failure REJECTs):
  G1 registry : (ROW, VALUE) pair must occur in the training streams.
  G2 grammar  : classify_value_type(VALUE) must be among the types that
                ROW ever carried in the training streams.
  G3 stream   : if the candidate fails G1/G2, CLARIFY by scanning the
                current window for registered (ROW, VALUE) candidates;
                emit the unique survivor as the corrected VALUE.

Verdicts: ACCEPT (keep neural pred), REJECT (pred failed G1/G2), and for
REJECT cases the stream-recovered candidate (None if ambiguous/absent).

The follow-on evaluator reports THREE numbers, kept separate:
  nn_acc           - neural argmax accuracy (unvalidated)
  nn_val_acc       - accuracy after ACCEPT/stream-recover
  validation_delta - (nn_val_acc - nn_acc): validator's contribution
plus the per-gate rejection tallies. This keeps "what the model learned"
separate from "what the deterministic layer can recover" - the scientific
rule established for the 10M experiment (no gold lookup).
"""
from __future__ import annotations

from collections import Counter
from pathlib import Path

from rtf.canonical.value_diag import classify_value_type

CTX = 160  # whole-window context for G3 recovery


def build_validator(struct_train_per_lang) -> "RTFValidator":
    """struct_train_per_lang: {lang: [(row_code, value), ...]} train pairs."""
    pair_counts: Counter = Counter()
    row_types: dict[str, set] = {}
    for lang, pairs in struct_train_per_lang.items():
        for row, value in pairs:
            pair_counts[(row, value)] += 1
            row_types.setdefault(row, set()).add(classify_value_type(value))
    return RTFValidator(
        registered_pairs=pair_counts,
        row_type_scope=row_types,
    )


class RTFValidator:
    """No test answers. Only training-stream knowledge + current window."""

    def __init__(self, registered_pairs, row_type_scope):
        self.registered = registered_pairs
        self.row_types = row_type_scope

    def verify(self, row: str, value: str) -> tuple[bool, str]:
        """return (accepted, reason). No window dependency here."""
        if (row, value) not in self.registered:
            return False, "G1_registry: (ROW,VALUE) unseen in train"
        vt = classify_value_type(value)
        if vt not in self.row_types.get(row, set()):
            return False, f"G2_grammar: {vt} not allowed under ROW"
        return True, "G12_pass"

    def recover(self, row: str, window_values_pairs) -> str | None:
        """CLARIFY: unique registered (ROW, VALUE) candidate in window."""
        cands = [v for (r, v) in window_values_pairs
                 if r == row and (row, v) in self.registered]
        uniq = list(dict.fromkeys(cands))
        return uniq[0] if len(uniq) == 1 else None

    def apply(self, row: str, pred_value: str,
              window_values_pairs) -> tuple[str, str | None]:
        """Return (verdict, corrected_value).

        verdict in {ACCEPT, REJECT}; corrected_value set on REJECT+recover.
        """
        ok, _reason = self.verify(row, pred_value)
        if ok:
            return "ACCEPT", None
        rec = self.recover(row, window_values_pairs)
        return "REJECT", rec


def evaluate(model, struct_idx, struct_rev, validator, streams_split,
             train_pairs) -> dict:
    """Replay teacher-forced pass and split the scorecard.

    streams_split: {lang: (train_stream, test_stream)} symbol lists.
    Returns nn/val deltas + verdict tallies (dumps N examples).
    """
    from experiments.cross_domain.run_value_diag import (
        windows_for, teacher_forced)
    import torch  # noqa: F401

    nn_ok = nn_n = val_ok = 0
    verds = Counter()
    gate_why = Counter()
    examples = []
    for lang, (train_s, test_s) in streams_split.items():
        wins = windows_for(test_s, struct_idx)
        for win in wins:
            pred_at, _ = teacher_forced(model, win)
            window_pairs = []
            cur_row = "<none>"
            for i, gid in enumerate(win):
                sym = struct_rev.get(gid, "<unk>")
                if sym.startswith("R:"):
                    cur_row = sym
                elif sym.startswith("V:"):
                    window_pairs.append((cur_row, sym[2:]))
            cur_row = "<none>"  # reset; row context re-derived per position
            for pos, gid in enumerate(win):
                gs = struct_rev.get(gid, "<unk>")
                if gs.startswith("R:"):
                    cur_row = gs
                    continue
                if not gs.startswith("V:"):
                    continue
                row_sym = cur_row
                gold = gs[2:]
                pred_sym = struct_rev.get(pred_at[pos], "<unk>")
                pred = pred_sym[2:] if pred_sym.startswith(("V:", "R:", "T:")) \
                    else pred_sym
                nn_n += 1
                ok_now = (pred == gold)
                if ok_now:
                    nn_ok += 1
                    val_ok += 1
                    verds["nn_correct"] += 1
                    continue
                verdict, corr = validator.apply(
                    row_sym, pred, window_pairs)
                verds[verdict] += 1
                final = corr if corr is not None else pred
                if final == gold:
                    val_ok += 1
                    gate_why["recovered_by_stream"] += 1
                if len(examples) < 8 and verdict == "REJECT":
                    examples.append((lang, gs, pred_sym, row_sym,
                                     verdict, corr, gold,
                                     final == gold))
    nn_acc = 100.0 * nn_ok / max(nn_n, 1)
    val_acc = 100.0 * val_ok / max(nn_n, 1)
    return {
        "nn_n": nn_n, "nn_ok": nn_ok, "nn_acc": round(nn_acc, 2),
        "val_ok": val_ok, "val_acc": round(val_acc, 2),
        "validation_delta": round(val_acc - nn_acc, 2),
        "verdicts": dict(verds), "gate_why": dict(gate_why),
        "examples": examples, "train_pairs_per_lang": {
            lang: len(tps) for lang, tps in train_pairs.items()},
    }


__all__ = ["RTFValidator", "build_validator", "evaluate", "classify_value_type"]