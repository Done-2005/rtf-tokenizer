"""Cross-domain relationship system (ported from CURRENT/COPY-3/cross_domain).

Separate from the neural architecture: typed relationships between
independent main tags, explicit confidence/action routing, and a
deterministic verifier. Distinct from rtf.crossdomain (the V5 read-only
registry lookup): this module works over the DECLARED canonical tag graph.
"""

from .deterministic_executor import DeterministicExecutor, Verdict
from .graph import RelationshipGraph, build_graph
from .relationships import (
    RELATIONS,
    REL_TO_WORDS,
    answers,
    is_cross_domain,
    rel_to_words,
)
from .router import ACTIONS, CONFIDENCES, relation_route, route
from .tags import DOMAINS, TAGS, TAG_DOMAIN

__all__ = [
    "TAGS", "TAG_DOMAIN", "DOMAINS",
    "RELATIONS", "REL_TO_WORDS", "is_cross_domain", "rel_to_words",
    "answers",
    "RelationshipGraph", "build_graph",
    "CONFIDENCES", "ACTIONS", "route", "relation_route",
    "Verdict", "DeterministicExecutor",
]