"""Cross-Domain relationship function (verbatim data + logic from the
verified benchmark; ported from CURRENT/COPY-3/cross_domain/relationships.py).

Cross-Domain is SEPARATE from the neural architecture: a relationship
function whose job is to identify and emit typed relationships between
independent main tags. It is NOT a sub-tag hierarchy, NOT RTF-BIO, and
NOT another transformer.
"""

from __future__ import annotations

from .tags import TAG_DOMAIN

RELATIONS = [
    ("PYTHON", "RELATED_TO", "MATHEMATICS"),
    ("PYTHON", "USED_FOR", "STATISTICS"),
    ("JAVA", "RELATED_TO", "MATHEMATICS"),
    ("RUST", "USED_FOR", "STATISTICS"),
    ("MATHEMATICS", "SUPPORTS", "STATISTICS"),
    ("STATISTICS", "USES", "MATHEMATICS"),
    ("PYTHON", "HAS", "PYTHON_FUNCTIONS"),
    ("PYTHON", "HAS", "PYTHON_SOLUTIONS"),
    ("JAVA", "HAS", "JAVA_METHODS"),
    ("RUST", "HAS", "RUST_OWNERSHIP"),
    ("MATHEMATICS", "HAS", "ARITHMETIC"),
    ("STATISTICS", "HAS", "MEAN"),
]

REL_TO_WORDS = {
    "RELATED_TO": "is related to",
    "USED_FOR": "is used for",
    "SUPPORTS": "supports",
    "USES": "uses",
    "HAS": "includes",
}


def is_cross_domain(subj: str, obj: str) -> bool:
    return TAG_DOMAIN[subj] != TAG_DOMAIN[obj]


def rel_to_words(rel: str) -> str:
    return REL_TO_WORDS[rel]


def answers(subj: str, rel: str, obj: str):
    return [subj, rel, obj, "CONF", "HIGH", "ACTION", "EXECUTE"]


__all__ = ["RELATIONS", "REL_TO_WORDS", "is_cross_domain", "rel_to_words",
           "answers"]