"""Independent main tags (verbatim data from the verified benchmark).

Ported from CURRENT/COPY-3/representation/tags.py. The 23 canonical tags
are INDEPENDENT main tags; the underscore is part of the name and does NOT
imply hierarchy. TAG_DOMAIN maps each tag to its domain group for
relationship classification (Cross-Domain vs intra-domain).
"""

from __future__ import annotations

TAGS = [
    "PYTHON", "PYTHON_FUNCTIONS", "PYTHON_ARCHITECTURE",
    "PYTHON_PROBLEMS", "PYTHON_SOLUTIONS",
    "JAVA", "JAVA_OBJECTS", "JAVA_METHODS", "JAVA_PROBLEMS", "JAVA_SOLUTIONS",
    "RUST", "RUST_MEMORY", "RUST_OWNERSHIP", "RUST_PROBLEMS", "RUST_SOLUTIONS",
    "MATHEMATICS", "ALGEBRA", "CALCULUS", "ARITHMETIC",
    "STATISTICS", "PROBABILITY", "REGRESSION", "MEAN",
]

TAG_DOMAIN = {
    "PYTHON": "PYTHON", "PYTHON_FUNCTIONS": "PYTHON",
    "PYTHON_ARCHITECTURE": "PYTHON", "PYTHON_PROBLEMS": "PYTHON",
    "PYTHON_SOLUTIONS": "PYTHON",
    "JAVA": "JAVA", "JAVA_OBJECTS": "JAVA", "JAVA_METHODS": "JAVA",
    "JAVA_PROBLEMS": "JAVA", "JAVA_SOLUTIONS": "JAVA",
    "RUST": "RUST", "RUST_MEMORY": "RUST", "RUST_OWNERSHIP": "RUST",
    "RUST_PROBLEMS": "RUST", "RUST_SOLUTIONS": "RUST",
    "MATHEMATICS": "MATHEMATICS", "ALGEBRA": "MATHEMATICS",
    "CALCULUS": "MATHEMATICS", "ARITHMETIC": "MATHEMATICS",
    "STATISTICS": "STATISTICS", "PROBABILITY": "STATISTICS",
    "REGRESSION": "STATISTICS", "MEAN": "STATISTICS",
}

DOMAINS = ["PYTHON", "JAVA", "RUST", "MATHEMATICS", "STATISTICS"]

__all__ = ["TAGS", "TAG_DOMAIN", "DOMAINS"]