"""Deterministic relationship-checking / rejection executor.

Ported from CURRENT/COPY-3/cross_domain/deterministic_executor.py (the
sys.path hack removed; package-relative import instead).

A VERIFIED execution layer over the declared relationship graph. It does
NOT replace the neural model; it VERIFIES candidate relationships and can
only reject for reasons grounded in the declared graph. It holds NO test
answers: an undeclared edge is NONE->REJECT because it is not declared.

    EXISTS    -> CONF HIGH   -> ACTION EXECUTE
    AMBIGUOUS -> CONF MEDIUM -> ACTION CLARIFY
    NONE      -> CONF LOW    -> ACTION REJECT
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .relationships import RELATIONS


@dataclass
class Verdict:
    state: str
    confidence: str
    action: str
    matches: list[tuple[str, str, str]] = field(default_factory=list)
    reason: str = ""


class DeterministicExecutor:
    STATE_MAP = {
        "EXISTS": ("HIGH", "EXECUTE"),
        "AMBIGUOUS": ("MEDIUM", "CLARIFY"),
        "NONE": ("LOW", "REJECT"),
    }

    def __init__(self, relations=RELATIONS):
        self.relations = list(relations)
        self.src_edges: dict[str, list[tuple[str, str, str]]] = {}
        self.edge_set: set[tuple[str, str, str]] = set(self.relations)
        for (s, r, o) in self.relations:
            self.src_edges.setdefault(s, []).append((s, r, o))

    def check(self, subj=None, rel=None, obj=None) -> Verdict:
        if subj is not None and subj not in self.src_edges:
            return Verdict("NONE", *self.STATE_MAP["NONE"], [],
                           f"no declared edges from {subj}")

        if obj is not None and subj is not None and rel is not None:
            if (subj, rel, obj) in self.edge_set:
                return Verdict("EXISTS", *self.STATE_MAP["EXISTS"],
                               [(subj, rel, obj)],
                               f"{subj} -{rel}-> {obj} declared")
            return Verdict("NONE", *self.STATE_MAP["NONE"],
                           [], f"{subj} -{rel}-> {obj} NOT declared")

        if obj is not None and subj is not None:
            matches = [e for e in self.src_edges.get(subj, []) if e[2] == obj]
            if len(matches) == 1:
                return Verdict("EXISTS", *self.STATE_MAP["EXISTS"], matches,
                               f"{subj} -> {obj} has one declared relation")
            if len(matches) > 1:
                return Verdict("AMBIGUOUS", *self.STATE_MAP["AMBIGUOUS"],
                               matches, f"{subj} -> {obj} has multiple relations")
            return Verdict("NONE", *self.STATE_MAP["NONE"], [],
                           f"{subj} -> {obj} NOT declared")

        if rel is not None and subj is not None:
            matches = [e for e in self.src_edges.get(subj, []) if e[1] == rel]
            if len(matches) == 1:
                return Verdict("EXISTS", *self.STATE_MAP["EXISTS"], matches,
                               f"{subj} -{rel}-> has one target")
            if len(matches) > 1:
                return Verdict("AMBIGUOUS", *self.STATE_MAP["AMBIGUOUS"],
                               matches, f"{subj} -{rel}-> has multiple targets")
            return Verdict("NONE", *self.STATE_MAP["NONE"], [],
                           f"no {subj} -{rel}-> edge declared")

        if subj is not None:
            matches = list(self.src_edges.get(subj, []))
            if len(matches) == 1:
                return Verdict("EXISTS", *self.STATE_MAP["EXISTS"], matches,
                               f"{subj} has one declared edge")
            if len(matches) > 1:
                return Verdict("AMBIGUOUS", *self.STATE_MAP["AMBIGUOUS"],
                               matches, f"{subj} has multiple declared edges")
            return Verdict("NONE", *self.STATE_MAP["NONE"], [],
                           f"{subj} has no declared edges")

        return Verdict("NONE", *self.STATE_MAP["NONE"], [],
                       "no subject provided to verify")

    def respond(self, subj=None, rel=None, obj=None) -> list[str]:
        v = self.check(subj, rel, obj)
        if v.state == "EXISTS":
            s, r, o = v.matches[0]
            return [s, r, o, "CONF", "HIGH", "ACTION", "EXECUTE"]
        if v.state == "AMBIGUOUS":
            cand = []
            for (s, r, o) in v.matches:
                cand += [s, r, o]
            return ["STATE", "AMBIGUOUS", "CONF", "MEDIUM", "ACTION", "CLARIFY",
                    "CANDIDATES"] + cand
        return ["STATE", "NONE", "CONF", "LOW", "ACTION", "REJECT"]


__all__ = ["Verdict", "DeterministicExecutor"]