"""Relationship graph over independent main tags.

Ported from CURRENT/COPY-3/cross_domain/graph.py. A derived convenience
view over the declared relationships: adjacency and query helpers. It does
NOT imply a tag hierarchy.
"""

from __future__ import annotations

from .relationships import RELATIONS


def build_graph():
    graph: dict[str, list[tuple[str, str]]] = {}
    for subj, rel, obj in RELATIONS:
        graph.setdefault(subj, []).append((rel, obj))
    return graph


class RelationshipGraph:
    def __init__(self, relations=RELATIONS):
        self.forward = build_graph()
        self._all = list(relations)

    def outgoing(self, tag: str):
        return self.forward.get(tag, [])

    def has_relation(self, subj: str, rel: str, obj: str) -> bool:
        return (subj, rel, obj) in self._all

    def related(self, subj: str, obj: str) -> str | None:
        for rel, o in self.forward.get(subj, []):
            if o == obj:
                return rel
        return None


__all__ = ["build_graph", "RelationshipGraph"]