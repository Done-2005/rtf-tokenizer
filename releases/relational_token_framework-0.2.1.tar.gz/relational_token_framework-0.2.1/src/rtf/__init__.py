"""Relational Token Framework: your method as an installable package.

Tokenizer + representation + method (stdlib only). The Copy-3 neural
architecture lives in `rtf.architecture` and needs the torch extra:
`pip install relational-token-framework[torch]`.
"""

from ._version import __version__
from .core.model import (
    SCHEMA_VERSION,
    Extraction,
    IngestionReport,
    ParseResult,
    Rejection,
    RTFConfig,
)
from .engine import RepresentationEngine
from .method import EXT_LANGUAGES, RTF
from .representation import WINDOW, Window, build_streams, chunk, split
from .tokenization import (
    CombinedTokenizer,
    ConventionalTokenizer,
    StructuralTokenizer,
    StructuredTokenizer,
    combine_address,
    decompose_address,
)
from .tokenization.domains import (
    DOMAINS,
    EXTS,
    TAGS,
    detect_domain,
    normalise,
    tokenize_text,
    tool_call_atoms,
)
from .tokenizer import KINDS, RTFTokenizer
from .registration import KINDS_OF_ID, Registration
from .canonical import CanonicalTokenizer

__all__ = [
    "__version__",
    "RTF",
    "RTFTokenizer",
    "CanonicalTokenizer",
    "KINDS",
    "RepresentationEngine",
    "RTFConfig",
    "SCHEMA_VERSION",
    "Extraction",
    "ParseResult",
    "IngestionReport",
    "Rejection",
    "EXT_LANGUAGES",
    "Window",
    "WINDOW",
    "build_streams",
    "chunk",
    "split",
    "CombinedTokenizer",
    "ConventionalTokenizer",
    "StructuralTokenizer",
    "StructuredTokenizer",
    "combine_address",
    "decompose_address",
    "DOMAINS",
    "EXTS",
    "TAGS",
    "detect_domain",
    "normalise",
    "tokenize_text",
    "tool_call_atoms",
    "Registration",
    "KINDS_OF_ID",
]