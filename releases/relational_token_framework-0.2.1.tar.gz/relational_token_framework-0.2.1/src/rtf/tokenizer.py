"""Portable RTF tokenizer with vocabulary save/load (0.1.6).

Wraps the four research tokenizers behind one interface and snapshots the
fitted vocabulary into plain dicts, so a fitted tokenizer travels to
Kaggle (or anywhere) as JSON and decodes without a database connection.

0.1.6 additions (Copy-3 campaign, five domains: python/java/math/tool/
english):

- kind='atoms': DB-free [T,R,V] tokenizer over the five campaign
  domains (tokenize_text/detect_domain from
  rtf.tokenization.domains). Content-preserving for covered inputs;
  uncovered symbols map to <unk> silently at the id level, and
  inter-token whitespace is layout (see README "Unicode policy").
  fit_texts(), encode_text(text, language), encode_tool_call(),
  fit_tool_examples().
- vocab(), token_to_id(), id_to_token() accessors.
- validate(): structural/schema guards V01-V05.
- relationships(): cross-domain relationship view (delegates to the
  verified rtf.cross_domain graph; no invented edges).

The permanent identity layer (global monotonic TAG/ROW/VALUE/CELL ids,
persisted separately) lives in rtf.registration.Registration.

Encoding DB-backed documents still needs the live corpus connection the
vocab was fitted from.
"""

from __future__ import annotations

import json

from .tokenization import (
    CombinedTokenizer,
    ConventionalTokenizer,
    StructuralTokenizer,
    StructuredTokenizer,
)
from .tokenization.domains import TAGS, detect_domain, tokenize_text, tool_call_atoms
from .tokenization.tokens import EOS, PAD, UNK

KINDS = ("atoms", "structured", "combined", "structural", "char")

_BACKED_KINDS = {"structured": StructuredTokenizer,
                 "combined": CombinedTokenizer,
                 "structural": StructuralTokenizer}

# Campaign domain name -> canonical independent main tag (SPEC_COPY3).
_CANONICAL_TAG_ALIASES = {
    "python": "PYTHON",
    "java": "JAVA",
    "rust": "RUST",
    "r": "R",
    "math": "MATHEMATICS",
    "mathematics": "MATHEMATICS",
    "statistics": "STATISTICS",
    "sql": "SQL",
}


class RTFTokenizer:
    def __init__(self, kind: str = "structured", conn=None,
                 domains=None) -> None:
        if kind not in KINDS:
            raise ValueError(f"kind must be one of {KINDS}")
        self._kind = kind
        self._conn = conn
        self._inner = None
        self.domains = list(domains or [d for d in ("python", "java", "math",
                                                    "tool", "english")])
        self.stoi: dict[str, int] = {}
        self.itos: list[str] = []

    @property
    def kind(self) -> str:
        return self._kind

    @property
    def vocab_size(self) -> int:
        return len(self.itos)

    def vocab(self) -> dict[str, int]:
        """Immutable snapshot of the token->id vocabulary."""
        if not self.itos:
            raise ValueError("tokenizer is not fitted")
        return dict(self.stoi)

    def token_to_id(self, token: str) -> int:
        if not self.itos:
            raise ValueError("tokenizer is not fitted")
        return self.stoi.get(token, self.stoi[UNK])

    def id_to_token(self, token_id: int) -> str:
        if not self.itos:
            raise ValueError("tokenizer is not fitted")
        if 0 <= token_id < len(self.itos):
            return self.itos[token_id]
        return UNK

    # --- fitting -----------------------------------------------------

    def fit(self, conn=None) -> "RTFTokenizer":
        conn = conn or self._conn
        if self._kind in ("char", "atoms"):
            raise ValueError(f"{self._kind} kind uses fit_texts(), not fit()")
        if conn is None:
            raise ValueError("fit() needs a corpus connection")
        self._conn = conn
        self._inner = _BACKED_KINDS[self._kind](conn).fit_from_db()
        self.stoi = dict(self._inner._stoi)
        self.itos = list(self._inner._itos)
        return self

    def fit_texts(self, texts, languages=None) -> "RTFTokenizer":
        """Fit a vocabulary from raw texts (no DB).

        - kind='char':   character vocabulary over the strings.
        - kind='atoms':  [T,R,V] vocabulary over the five campaign
          domains.  Each item may be a str (language optional per item or
          a single value) or a function-call dict -> tool atoms.

        Other kinds need a corpus connection via fit().
        """
        if self._kind == "char":
            self._inner = ConventionalTokenizer().fit(list(texts))
            self.stoi = dict(self._inner._stoi)
            self.itos = list(self._inner._itos)
            return self
        if self._kind != "atoms":
            raise ValueError("fit_texts() is only for kind='char'/'atoms'")

        symbols: list[str] = [PAD, UNK, EOS]
        seen: set[str] = set(symbols)

        def add(symbol: str) -> None:
            if symbol not in seen:
                seen.add(symbol)
                symbols.append(symbol)

        for index, item in enumerate(texts):
            if isinstance(item, dict):
                lang, atoms = "tool", [(c, v)
                                       for _t, c, v in tool_call_atoms(item)]
            else:
                lang_hint = languages
                if isinstance(languages, (list, tuple)):
                    lang_hint = languages[index] if index < len(languages) else None
                lang, atoms = tokenize_text(item, lang_hint)
                if lang not in self.domains:
                    lang = "english"
            add(f"T:{TAGS[lang]}")
            for concept, value in atoms:
                add(f"R:{concept}")
                add(f"V:{value}")
        self.itos = symbols
        self.stoi = {s: i for i, s in enumerate(symbols)}
        return self

    def fit_tool_examples(self, examples) -> "RTFTokenizer":
        """Add function-call specs to the atoms vocabulary."""
        if self._kind != "atoms":
            raise ValueError("fit_tool_examples() is only for kind='atoms'")
        if not self.itos:
            self.stoi = {}
            self.itos = []
            return self.fit_texts(examples)
        symbols: list[str] = list(self.itos)
        seen: set[str] = set(symbols)

        def add(symbol: str) -> None:
            if symbol not in seen:
                seen.add(symbol)
                symbols.append(symbol)

        for call in examples:
            add("T:TOOL_CALL")
            for _t, concept, value in tool_call_atoms(call):
                add(f"R:{concept}")
                add(f"V:{value}")
        self.itos = symbols
        self.stoi = {s: i for i, s in enumerate(symbols)}
        return self

    # --- encoding ----------------------------------------------------

    def encode_document(self, document_id: int) -> list[int]:
        if self._inner is None:
            raise ValueError("tokenizer is not fitted")
        if self._kind in ("char", "atoms"):
            raise ValueError(
                f"{self._kind} kind uses encode_text(), not documents")
        return self._inner.encode_document(document_id)

    def encode_text(self, text: str, language: str | None = None) -> list[int]:
        if not self.itos:
            raise ValueError("tokenizer is not fitted")
        if self._kind == "char":
            return self._inner.encode(text)
        if self._kind != "atoms":
            raise ValueError(
                "encode_text() is only for kind='char'/'atoms'")
        if isinstance(text, dict):
            # DTK-001: tool_call_atoms returns (tag, concept, value) triples,
            # while this encoder consumes (concept, value) pairs. Normalise
            # the shape exactly as fit_texts() does.
            lang, atoms = "tool", [(concept, value)
                                   for _t, concept, value in tool_call_atoms(text)]
        else:
            lang, atoms = tokenize_text(text, language)
            if lang not in self.domains:
                lang = "english"
        unk = self.stoi.get(UNK, 0)
        out = [self.stoi.get(f"T:{TAGS[lang]}", unk)]
        for concept, value in atoms:
            out.append(self.stoi.get(f"R:{concept}", unk))
            out.append(self.stoi.get(f"V:{value}", unk))
        out.append(self.stoi.get(EOS, unk))
        return out

    def encode_tool_call(self, fn_call) -> list[int]:
        """Encode a function-call spec (dict or list of dicts) to ids."""
        if not self.itos:
            raise ValueError("tokenizer is not fitted")
        if self._kind != "atoms":
            raise ValueError(
                "encode_tool_call() is only for kind='atoms'")
        unk = self.stoi.get(UNK, 0)
        out = [self.stoi.get("T:TOOL_CALL", unk)]
        for _t, concept, value in tool_call_atoms(fn_call):
            out.append(self.stoi.get(f"R:{concept}", unk))
            out.append(self.stoi.get(f"V:{value}", unk))
        out.append(self.stoi.get(EOS, unk))
        return out

    # --- decoding ----------------------------------------------------

    def decode(self, ids: list[int]) -> list[str]:
        if not self.itos:
            raise ValueError("tokenizer is not fitted")
        return [self.itos[i] if 0 <= i < len(self.itos) else UNK
                for i in ids]

    def decode_atoms(self, ids: list[int]) -> list[tuple]:
        if self._kind not in ("atoms", "structured", "structural"):
            raise ValueError(
                "decode_atoms() needs kind='atoms'/'structured'/'structural'")
        if self._kind == "atoms":
            return self._pair_decode_atoms(ids)
        atoms: list[tuple] = []
        current: list | None = None
        for symbol in self.decode(ids):
            if symbol in (PAD, UNK, EOS) or symbol.startswith("STRUCT_"):
                continue
            if symbol.startswith("T:"):
                if current is not None:
                    atoms.append(tuple(current))
                current = [symbol[2:], None, None]
            elif symbol.startswith("R:") and current is not None:
                current[1] = symbol[2:]
            elif symbol.startswith("V:") and current is not None:
                current[2] = symbol[2:]
        if current is not None:
            atoms.append(tuple(current))
        return atoms

    def _pair_decode_atoms(self, ids: list[int]) -> list[tuple]:
        """Pair (R:, V:) symbols after the single T: head (kaggle layout)."""
        grouped: list[tuple] = []
        syms = [s for s in self.decode(ids) if s not in (PAD, EOS)]
        start = next((i for i, s in enumerate(syms)
                      if s.startswith("T:")), None)
        if start is None:
            return grouped
        tag = syms[start][2:]
        rest = syms[start + 1:]
        for i in range(0, len(rest) - 1, 2):
            row_sym, val_sym = rest[i], rest[i + 1]
            row = row_sym[2:] if row_sym.startswith("R:") else None
            value = val_sym[2:] if val_sym.startswith("V:") else None
            grouped.append((tag, row, value))
        if len(rest) % 2 == 1:
            row_sym = rest[-1]
            row = row_sym[2:] if row_sym.startswith("R:") else None
            grouped.append((tag, row, None))
        return grouped

    # --- schema guards ----------------------------------------------

    def validate(self) -> list[dict]:
        """Structural/schema guards over the fitted vocabulary.

        Returns a list of {"code", "status", "detail"} records
        (status 'PASS' or 'FAIL').
        """
        findings: list[dict] = []
        specials = ("<pad>", "<unk>", "<eos>")

        present = {s for s in specials if s in self.stoi and s in self.itos}
        findings.append({
            "code": "V01", "status": "PASS" if len(present) == 3 else "FAIL",
            "detail": f"specials present: {sorted(present)}"})

        contiguous = all(self.stoi[s] == i and self.itos[i] == s
                         for i, s in enumerate(self.itos))
        findings.append({
            "code": "V02", "status": "PASS" if contiguous else "FAIL",
            "detail": f"ids contiguous 0..{len(self.itos) - 1}: {contiguous}"})

        bijective = len(self.stoi) == len(self.itos)
        findings.append({
            "code": "V03", "status": "PASS" if bijective else "FAIL",
            "detail": f"stoi/itos bijective: {bijective}"})

        if self._kind == "atoms":
            bad = [s for s in self.itos
                   if not (s.startswith(("T:", "R:", "V:"))
                           or s in specials)]
            findings.append({
                "code": "V04", "status": "PASS" if not bad else "FAIL",
                "detail": f"atoms symbols parseable: {bad[:5]}"})

        good = 0
        for s in (self.itos[3:4] if len(self.itos) > 3 else []):
            if 0 <= self.stoi[s] < len(self.itos) and self.itos[self.stoi[s]] == s:
                good += 1
        findings.append({
            "code": "V05",
            "status": "PASS" if len(self.itos) <= 3 or good == 1 else "FAIL",
            "detail": f"reverse-map sample ok: {good}"})
        return findings

    # --- cross-domain -----------------------------------------------

    def _resolve_canonical(self, tag: str) -> str:
        """Map a 5-domain stem or canonical tag name to a canonical main tag.

        The canonical Cross-Domain graph (SPEC_COPY3 component 5) operates
        on the independent canonical main tags (PYTHON, JAVA, MATHEMATICS,
        STATISTICS, RUST, ...).  Campaign stems such as 'math' resolve to
        their canonical tag so the declared relationship graph applies.
        Unknown names pass straight through (the executor then reports
        NONE; nothing is ever invented).
        """
        stem = tag.strip().lower()
        if stem in _CANONICAL_TAG_ALIASES:
            return _CANONICAL_TAG_ALIASES[stem]
        return tag

    def relationships(self, tag: str):
        """Outgoing declared relationships for a main tag.

        Accepts canonical tags ('PYTHON', 'MATHEMATICS', ...) or campaign
        stems ('python', 'math', ...). Delegates to the verified
        rtf.cross_domain graph; unknown tags return [] (nothing invented).
        """
        from rtf.cross_domain import RelationshipGraph
        return RelationshipGraph().outgoing(self._resolve_canonical(tag))

    def cross_domain(self, subj: str, rel=None, obj=None):
        """Verified cross-domain verdict for a candidate relationship.

        Resolves subj/obj to canonical main tags and returns the
        DeterministicExecutor Verdict (SPEC_COPY3 components 5-8):

            EXISTS   -> confidence HIGH  -> action EXECUTE
            AMBIGUOUS-> confidence MEDIUM-> action CLARIFY
            NONE     -> confidence LOW   -> action REJECT

        'rel' is normalised to uppercase.
        """
        from rtf.cross_domain import DeterministicExecutor
        resolved_subj = self._resolve_canonical(subj)
        resolved_obj = self._resolve_canonical(obj) if obj is not None else None
        if rel is not None:
            rel = str(rel).upper()
        return DeterministicExecutor().check(subj=resolved_subj, rel=rel,
                                             obj=resolved_obj)

    def respond_relation(self, subj: str, rel=None, obj=None) -> list[str]:
        """Canonical token stream for a relationship verdict.

        Matches the benchmark answer format, e.g.
        [PYTHON, USED_FOR, STATISTICS, CONF, HIGH, ACTION, EXECUTE].
        """
        from rtf.cross_domain import DeterministicExecutor
        resolved_subj = self._resolve_canonical(subj)
        resolved_obj = self._resolve_canonical(obj) if obj is not None else None
        if rel is not None:
            rel = str(rel).upper()
        return DeterministicExecutor().respond(subj=resolved_subj, rel=rel,
                                                obj=resolved_obj)

    # --- persistence -------------------------------------------------

    def save(self, path) -> str:
        with open(path, "w", encoding="utf-8") as handle:
            json.dump({"kind": self._kind, "stoi": self.stoi,
                       "itos": self.itos, "domains": self.domains},
                      handle, ensure_ascii=False)
        return str(path)

    @classmethod
    def load(cls, path) -> "RTFTokenizer":
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        tok = cls(kind=data["kind"], domains=data.get("domains"))
        tok.stoi = dict(data["stoi"])
        tok.itos = list(data["itos"])
        return tok


__all__ = ["RTFTokenizer", "KINDS"]