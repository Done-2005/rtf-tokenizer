# relational-token-framework (RTF) 0.2.0

The **Relational Token Framework** as an installable package: the
tokenizer, the TAG/ROW/VALUE/CELL representation, the method
(TAG → parse → ROW → VALUE → CELL → occurrences → structures), and
the Copy-3 architecture.

```bash
pip install relational-token-framework          # tokenizer + representation + method (stdlib only)
pip install "relational-token-framework[torch]" # + Copy-3 architecture
```

The stdlib-only and torch-extra claims on the install lines above are
backed by the wheel `METADATA` (`Requires-Dist`: torch declared only
under the `[torch]` extra) and the implementation import surface:
`rtf.architecture` handles torch conditionally, without requiring it
for module import. A function-scoped torch import also exists in
`rtf/cross_domain/validator.py` (`evaluate()`); see the recorded
limitation. These are installation and module-import claims; executing
the noted function path requires torch.

This is the tokenizer package of the two-package split (user decision
U-NAME-A, 2026-11-15). The independent benchmark toolkit ships
separately as [`rtf-bench`](https://pypi.org/project/rtf-bench/) (local
artifact until any registry release is separately authorized).

## 30-second start

```python
from rtf import RTF

m = RTF()  # runtime schema 5.3.0 (rtf.core.model.SCHEMA_VERSION), in-memory
m.add_text("def add(a, b):\n    return a + b", language="python")
m.add_text("Photosynthesis converts sunlight into energy.", language="text")
m.add_file("main.py")   # language auto-detected
m.add_dir("corpus/")    # ingest a directory tree

tok = m.fit_tokenizer("structured")   # or "combined" / "structural" / "char"
ids = tok.encode_document(1)
print(tok.decode(ids)[:6])            # ['T:TAG_000001', 'R:ROW_000023', ...]
print(tok.decode_atoms(ids)[:2])      # [('TAG_000001', 'ROW_000023', 'def'), ...]

tok.save("vocab.json")
tok2 = RTFTokenizer.load("vocab.json")   # travels as plain JSON
```

DB-free text path (no corpus connection needed):

```python
from rtf import RTFTokenizer

tok = RTFTokenizer(kind="atoms").fit_texts(
    ["def add(a, b): return a + b", "The cat sat.", "10 + 32 = 42"],
    ["python", "english", "math"])
ids = tok.encode_text("a = 2 + 3", "python")
tok.decode_atoms(ids)   # [('PYTHON', 'VARIABLE_BINDING', 'a'), ...]
```

Canonical Copy-3 typed-atom grammar (0.1.7 lineage, DB-free):

```python
from rtf import CanonicalTokenizer

ct = CanonicalTokenizer().fit()
stream = ct.serialize("What is 10 times 5?", "ARITHMETIC", "arithmetic")
# ['Q', ':', 'T:', 'ARITHMETIC', 'E', 'N:', '10', 'N:', '5',
#  'R:', 'TIMES', 'ASK', 'ARITHMETIC']
ids = ct.encode(stream)                    # unknown symbols map to <unk> silently (no error, count, or report); <eos>-terminated
pair = ct.make_pair(problem, answer)       # problem + [SEP] + answer + [EOS]
```

## Tokenizer kinds

| kind           | fit                | encode                 | notes                                   |
| -------------- | ------------------ | ---------------------- | --------------------------------------- |
| `char`         | `fit_texts(texts)` | `encode_text(text)`    | char-level; exact round-trip for fitted text |
| `atoms`        | `fit_texts(...)`   | `encode_text` / `encode_tool_call` | [T,R,V] typed atoms, five domains |
| `structured`   | `fit(conn)`        | `encode_document(id)`  | DB-backed registry symbols              |
| `combined`     | `fit(conn)`        | `encode_document(id)`  | structured + value stream               |
| `structural`   | `fit(conn)`        | `encode_document(id)`  | typed-atom triples from documents       |

Five campaign domains for `atoms`: `python`, `java`, `math`, `tool`
(function calling), `english`. Tool calls are structured specs:

```python
tok.encode_tool_call({"function": "get_weather",
                      "arguments": {"city": "Chennai"}})
# T:TOOL_CALL R:FUNCTION_NAME V:get_weather
# T:TOOL_CALL R:ARGUMENT_NAME  V:city
# T:TOOL_CALL R:ARGUMENT_VALUE V:Chennai
```

## Unicode policy (normalization and preservation limits)

No Unicode normalization (NFC, NFKC, or any other scheme) happens
anywhere in the tokenizer path: composed (`café`) and decomposed
(`cafe + combining accent`) forms remain **distinct token sequences**.
When the fitted vocabulary covers a symbol, every non-whitespace
character (including emoji, astral-plane and ZWJ sequences, CJK,
Arabic RTL text, and combining marks) survives as an atom value;
uncovered symbols map to `<unk>` at the id level, and the original
value is not recoverable from the ids (see Failure behavior below).
`kind='char'` reconstructs fitted text exactly (whitespace included);
`kind='atoms'` preserves the ordered token sequence (inter-token
whitespace is normalized to layout, not content; characters are never
normalized). Normalization can only ever appear as an explicit opt-in
feature in a future release (user decision U-UNI, 2026-11-15).

## Failure behavior

- Unfitted tokenizers fail closed (`ValueError`) on every entry point.
- Unknown characters/symbols map to `<unk>` at the id level, and the
  original value is not recoverable from the ids (audit finding B01;
  remediation specified, not yet implemented). Nothing is dropped or
  invented at the atom level.
- Unknown language codes fall back deterministically to the `english`
  domain (documented behavior; see CHANGELOG 0.2.0 findings).
- Malformed tool specs (non-dict) render as a degenerate
  `T:TOOL_CALL … <eos>` stream (documented behavior).
- Empty/whitespace-only inputs produce the documented degenerate
  stream (`T… <eos>`).
- Truncated or corrupt `save()`/`load()` files fail closed only at
  the JSON-parsing layer (`JSONDecodeError`). A file that parses as
  JSON is loaded as-is: `load()` assigns the fields directly and
  performs no integrity validation; schema fields and load-time
  validation are specified remediation, not yet implemented. The
  Registration monotonic guard never lets ids be reused after loading.

## The registries and the permanent identity layer

Two identity concepts, never conflated:

1. **Permanent registration** — global, monotonic, never restarted or
   reused:

   ```python
   from rtf import Registration

   reg = Registration()
   reg.tag_id("PYTHON")            # 1
   reg.row_id("INTEGER_LITERAL")   # 2  (one shared counter)
   reg.value_id("x")               # 3
   reg.cell("PYTHON", "INTEGER_LITERAL", "x")   # (1, 2, 3, cell_id)
   reg.save("reg.json"); reg2 = Registration.load("reg.json")
   ```

   The permanence rule is the registry layer's design guarantee. The
   `save()`/`load()` persistence path currently round-trips state
   without schema fields or load-time integrity validation;
   persistence integrity is the specified next-version remediation,
   not yet implemented in this release.

2. **The learned tokenizer vocabulary** — ephemeral, per-corpus,
   unrelated to permanent ids.

Per-kind canonical registries (TAG-/ROW-/COL-/CELL- prefixed labels):

```python
from rtf.canonical.registry import Registry

rows = Registry("row", "ROW")
n = rows.register("INTEGER_LITERAL", domain="PYTHON")
rows.label(n)          # 'ROW-000001' (idempotent by key)
```

### `RowRegistry.get_or_register(canonical_name)`

The canonical rows registry (0.1.8 lineage) additionally provides
**find-or-create**: it returns the existing row id for
`canonical_name`, or creates a new row with origin `AUTO` and an empty
definition when none exists. Registered rows are never renumbered, so
the operation is safe to call from ingest paths (implementation:
`rtf.registries.rows.RowRegistry.get_or_register`):

```python
from rtf.registries import RowRegistry

rr = RowRegistry(conn)                       # conn from rtf.core.schema
row_id = rr.get_or_register("NEW_CONCEPT")   # AUTO origin, "" definition
assert rr.get_or_register("NEW_CONCEPT") == row_id
```

## Validation

`tok.validate()` runs the portable guards V01–V05 (specials present;
contiguous ids; stoi/itos bijective; typed-atom symbols parseable;
reverse-map sample). `ct.validate()` runs the canonical guards C01–C07
(specials incl. `<sep>`; contiguity; bijection; grammar round-trip;
schema guard row length 6; input→answer collision audit;
parameter-check hook: self-comparison; independent parity not
established). Collisions abort (`SystemExit`) before any training.

## The Copy-3 architecture

`rtf.architecture` uses the optional torch extra. The tokenizer,
registries, method and validation modules can be imported without
third-party dependencies (wheel `METADATA`: `Requires-Dist`).
However, `rtf/cross_domain/validator.py` (`evaluate()`) attempts a
function-scoped torch import; that execution path requires torch.

## Scope and no-claims statement

RTF provides typed, structured tokenization for supported text and
domain representations, with reconstruction guarantees dependent on
tokenizer kind, vocabulary coverage, input type and serialization
behavior (the approved external description wording). It preserves and
exposes structure within those limits. It makes no claims of model
discovery, reasoning, or superiority, and none may be derived from it.
Research claims about structural discovery are handled by the
separately preregistered R1/R2 programmes, not by this package.

## Version history

- 0.2.0 — two-package split (tokenizer package; benchmark moves to the
  independent `rtf-bench` distribution). Version module aligned with
  distribution metadata. `get_or_register` documented. Unicode policy
  frozen as preserve-exact (U-UNI). See `CHANGELOG.md`.
- 0.1.7 — canonical Copy-3 tokenizer generation (`CanonicalTokenizer`,
  per-kind registries, five diagnostic demos).
- 0.1.6 — portable [T,R,V] tokenizer (`atoms` kind), tool-call
  rendering, `Registration` identity layer, cross-domain graph,
  guards V01–V05.
- Earlier history (0.1.5 and prior) lives in the research programme
  records.
